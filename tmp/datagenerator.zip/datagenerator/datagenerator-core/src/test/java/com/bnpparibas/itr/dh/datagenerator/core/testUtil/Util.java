/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.testUtil;

import com.bnpparibas.itr.dh.datagenerator.core.context.ExecutionContext;
import com.bnpparibas.itr.dh.datagenerator.core.generator.EventGenerator;
import com.bnpparibas.itr.dh.datagenerator.core.model.Config;
import com.bnpparibas.itr.dh.datagenerator.core.parser.ConfParser;
import io.confluent.kafka.serializers.KafkaAvroDeserializer;
import org.apache.avro.Schema;
import org.apache.avro.generic.GenericRecord;
import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream;
import org.apache.commons.compress.utils.IOUtils;
import org.apache.commons.io.FileUtils;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.*;

public class Util {
    private static final Logger logger = LoggerFactory.getLogger(Util.class);

    public static final ExecutionContext CONTEXT = new ExecutionContext();
    /**
     * This method returns the schema from the schema json file in the resource folder
     *
     * @param schemaName the name of the file in resources
     * @return avro schema
     * @throws IOException
     */
    public static Schema getResourceAsSchema(String schemaName) throws IOException, URISyntaxException {
        URL resource = Util.class.getClassLoader().getResource(schemaName);
        Schema schema = new Schema.Parser().parse(new File(resource.toURI()));
        logger.debug("The schema is {}", schema);
        return schema;
    }

    /**
     * This method returns a generic record based on the given schema
     *
     * @param schemaName the schema name in resources/schemas
     * @return random generic record
     * @throws IOException, URISyntaxException
     */
    public static GenericRecord buildGenericRecord(String schemaName) throws IOException, URISyntaxException {
        Schema schema = Util.getResourceAsSchema(schemaName);
        EventGenerator eventGenerator = new EventGenerator(CONTEXT, schema);
        return eventGenerator.generate();
    }

    /**
     * @param config
     * @return
     */
    public static List<GenericRecord> consumeEvents(Config config) {
        List<GenericRecord> actual = new ArrayList<>();
        Properties consumerConfig = new Properties();
        consumerConfig.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, config.getKafkaProps().getBootstrapServers());
        consumerConfig.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        consumerConfig.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, KafkaAvroDeserializer.class);
        consumerConfig.put("schema.registry.url", config.getKafkaProps().getSchemaRegistry());

        KafkaConsumer<String, GenericRecord> consumer = new KafkaConsumer<>(consumerConfig);
        TopicPartition partition = new TopicPartition(config.getKafkaProps().getTopicName(), 0);
        consumer.assign(Arrays.asList(partition));
        consumer.seek(partition, 0);

        ConsumerRecords<String, GenericRecord> records = consumer.poll(100);

        Iterator<ConsumerRecord<String, GenericRecord>> iterator = records.records(config.getKafkaProps().getTopicName()).iterator();
        while (iterator.hasNext()) {
            actual.add(iterator.next().value());
        }
        consumer.close();
        return actual;
    }

    /**
     * This method returns, from the resources folder, the file which name is
     * the given parameter
     *
     * @param fileName the file name in resources
     * @return the resource file
     * @throws URISyntaxException
     */
    public static File getResource(String fileName) throws URISyntaxException {
        URL resource = Util.class.getClassLoader().getResource(fileName);
        return new File(resource.toURI());
    }

    public static List<Config> getResourceAsConfigs(String filename) throws IOException, URISyntaxException {
        List<Config> configs = new ArrayList<>();
        ConfParser confParser = new ConfParser();
        File config = getResource(filename);
        String jsonString =  FileUtils.readFileToString(config, Charset.defaultCharset());
        return confParser.deserialize(jsonString);
    }

    /*
        Decompression method
        copied from https://memorynotfound.com/java-tar-example-compress-decompress-tar-tar-gz-files/

     */
    public static void decompress(String in, File out) throws IOException {
        try (TarArchiveInputStream fin = new TarArchiveInputStream(new GzipCompressorInputStream(new FileInputStream(in)))){
            TarArchiveEntry entry;
            while ((entry = fin.getNextTarEntry()) != null) {
                if (entry.isDirectory()) {
                    continue;
                }
                File curfile = new File(out, entry.getName());
                File parent = curfile.getParentFile();
                if (!parent.exists()) {
                    parent.mkdirs();
                }
                IOUtils.copy(fin, new FileOutputStream(curfile));
            }
        }
    }


}