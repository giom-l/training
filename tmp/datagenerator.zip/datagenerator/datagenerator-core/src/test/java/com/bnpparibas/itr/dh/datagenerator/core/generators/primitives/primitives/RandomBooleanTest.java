/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.generators.primitives.primitives;

import com.bnpparibas.itr.dh.datagenerator.core.context.ExecutionContext;
import com.bnpparibas.itr.dh.datagenerator.core.generators.primitives.primitives.BooleanGenerator;
import com.bnpparibas.itr.dh.datagenerator.core.model.Config;
import org.apache.avro.Schema;
import org.apache.commons.lang3.StringUtils;
import org.junit.Test;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

public class RandomBooleanTest {

    public static final String ACTIVE_FIELD = "active";
    Config config = mock(Config.class);
    ExecutionContext context = new ExecutionContext(config);

    @Test
    public void generate_should_generate_a_random_booleans(){
        // GIVEN
        Schema.Field field = new Schema.Field(ACTIVE_FIELD, Schema.create(Schema.Type.BOOLEAN), StringUtils.EMPTY, Boolean.FALSE);
        // WHEN
        Optional<Object> actual = new BooleanGenerator(context, field).generate();
        // THEN
        assertThat(actual).get().isIn(Boolean.FALSE, Boolean.TRUE);
    }
}