/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.generators.complexes;

import com.bnpparibas.itr.dh.datagenerator.core.context.ExecutionContext;
import com.bnpparibas.itr.dh.datagenerator.core.generators.complexes.RecordGenerator;
import com.bnpparibas.itr.dh.datagenerator.core.model.Config;
import com.bnpparibas.itr.dh.datagenerator.core.model.KafkaProps;
import org.apache.avro.Schema;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static org.apache.commons.lang3.StringUtils.EMPTY;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class RecordGeneratorTest {
    private static final String EVENT_RECORD_NAME = "event";
    private static final Schema UNION_TYPE = Schema.createUnion(Schema.create(Schema.Type.NULL), Schema.create(Schema.Type.STRING));
    private static final String NAME_FIELD = "name";
    private static final Schema.Field FIELD_NAME = new Schema.Field(NAME_FIELD, UNION_TYPE, EMPTY, EMPTY);
    private static final String FIRST_NAME_FIELD = "firstname";
    private static final Schema.Field FIELD_FIRST_NAME = new Schema.Field(FIRST_NAME_FIELD, UNION_TYPE, EMPTY, EMPTY);
    private static final List<Schema.Field> FIELDS = Arrays.asList(FIELD_NAME, FIELD_FIRST_NAME);
    private static final Schema EVENT_RECORD = Schema.createRecord(EVENT_RECORD_NAME, EMPTY, EMPTY, Boolean.FALSE, FIELDS);
    private static final String PERSON_FIELD = "person";
    private static final int EVENTS_SIZE = 10;

    RecordGenerator recordGenerator = new RecordGenerator();
    Config config = mock(Config.class);
    ExecutionContext context = new ExecutionContext(config);

    @Before
    public void setup(){
        KafkaProps kafkaProps = mock(KafkaProps.class);
        when(config.getKafkaProps()).thenReturn(kafkaProps);
        when(kafkaProps.getNumberOfEvents()).thenReturn(EVENTS_SIZE);
    }

    @Test
    public void generate_should_return_a_map_of_lists_of_strings(){
        // GIVEN
        Schema.Field field = new Schema.Field(PERSON_FIELD, EVENT_RECORD, EMPTY, EMPTY);
        // WHEN
        Map<String, Object> actual = recordGenerator.generate(context, field, EVENTS_SIZE);
        // THEN
        assertThat(actual).containsOnlyKeys(FIRST_NAME_FIELD, NAME_FIELD);
    }
}