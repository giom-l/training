/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
///**
// * Copyright © BNP PARIBAS - All rights reserved.
// */
package com.bnpparibas.itr.dh.datagenerator.core.sink;

import com.bnpparibas.itr.dh.datagenerator.core.context.ExecutionContext;
import com.bnpparibas.itr.dh.datagenerator.core.model.CassandraProps;
import com.bnpparibas.itr.dh.datagenerator.core.model.Config;
import com.bnpparibas.itr.dh.datagenerator.core.parser.ConfParser;
import com.bnpparibas.itr.dh.datagenerator.core.testUtil.Util;
import com.bnpparibas.itr.dh.datagenerator.core.utils.Const;
import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Session;
import org.apache.avro.Schema;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;
import org.apache.thrift.transport.TTransportException;
import org.cassandraunit.utils.EmbeddedCassandraServerHelper;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import tech.allegro.schema.json2avro.converter.JsonAvroConverter;

import java.io.IOException;
import java.net.URISyntaxException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;

import static com.bnpparibas.itr.dh.datagenerator.core.testUtil.Util.getResource;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class CassandraSinkTest {
    private static CassandraSink cassandraSink;
    private static GenericRecord genericRecord;
    private static Config config;

    private Cluster cluster;
    private Session session;

    private JsonAvroConverter converter;
    private String cassandraContactPoint = "localhost";
    private int cassandraPort = 9142;


    /**
     * Initiate the CassandraSink configuration
     *
     * @throws IOException
     */
    @Before

    public void setUp() throws IOException, URISyntaxException, CertificateException, NoSuchAlgorithmException, KeyStoreException, KeyManagementException, TTransportException {
        Schema schema = Util.getResourceAsSchema("schemas/schemaCassandra.json");
        genericRecord = new GenericData.Record(schema);
        cassandraSink = new CassandraSink();
        ConfParser confParser = new ConfParser();
        converter = new JsonAvroConverter();
        config = confParser.deserialize(getResource("config/cassandra.json")).get(0);

        /*create a fake cassandra cluster and connect to it
            Set largeR timeout (default 10000L) in order to avoid crashes on slower machines */
        EmbeddedCassandraServerHelper.startEmbeddedCassandra("cassandra.yaml", 300000L);
        cluster = Cluster.builder()
                .addContactPoints(cassandraContactPoint)
                .withPort(cassandraPort)
                .withCredentials(config.getCassandraProps().getUserName(), config.getCassandraProps().getPassword())
                .build();
        session = cluster.connect();

        /* mock the configuration to contact fake cluster instead of real one*/
        Config mockConfig = mock(Config.class);
        CassandraProps cassandraPropsMock = mock(CassandraProps.class);

        /*define where the needed information should come (local variables or real file*/
        when(mockConfig.getCassandraProps()).thenReturn(cassandraPropsMock);
        when(cassandraPropsMock.getContactPoints()).thenReturn(cassandraContactPoint);
        when(cassandraPropsMock.getPort()).thenReturn(cassandraPort);
        when(cassandraPropsMock.getNumberOfEvents()).thenReturn(config.getCassandraProps().getNumberOfEvents());
        when(cassandraPropsMock.getKeyspace()).thenReturn(config.getCassandraProps().getKeyspace());
        when(cassandraPropsMock.getTableName()).thenReturn(config.getCassandraProps().getTableName());
        when(cassandraPropsMock.getNumberOfEvents()).thenReturn(config.getCassandraProps().getNumberOfEvents());
        when(cassandraPropsMock.getUserName()).thenReturn(config.getCassandraProps().getUserName());
        when(cassandraPropsMock.getPassword()).thenReturn(config.getCassandraProps().getPassword());

        //init Cassandra cluster
        initCassandra4Test(config.getCassandraProps().getKeyspace(), config.getCassandraProps().getTableName());

        /*init cassandra sink with fake cluster*/
        cassandraSink.init(new ExecutionContext(), mockConfig);
    }

    /**
     * Test the process function that insert into cassandra data base the records
     *
     * @throws IOException
     */
    @Test
    public void processed_data_should_be_preserved_after_writing() throws IOException{
        //GIVEN a new generic record
        int expectedId = 15;
        String expectedDatenais = "2018-11-27";
        String expectedName = "Indiana";
        String expectedFirstname = "Joel";
        genericRecord.put("id", expectedId);
        genericRecord.put("datenais", expectedDatenais);
        genericRecord.put("nom", expectedName);
        genericRecord.put("prenom", expectedFirstname);
        //remove all whitespace from json value to not depend on the conversion method
        String expectedJson = new String(converter.convertToJson(genericRecord), Const.DEFAULT_CHARSET).replaceAll("\\s+", "");

        //WHEN
        cassandraSink.process(genericRecord);

        //THEN
        String actualJson = getFirstSelectedRowAsJson(expectedId);
        Assert.assertEquals(expectedJson, actualJson);
    }

    private void initCassandra4Test(String keyspace, String table) {
        //initialize keyspace and table
        String keyspaceReq = "CREATE KEYSPACE " + keyspace + " WITH replication = {'class': 'SimpleStrategy' , 'replication_factor': '1' }";
        String tableReq = "CREATE TABLE " + keyspace + "." + table + " (id int, datenais date, nom text, prenom text,PRIMARY KEY (id))";
        session.execute(keyspaceReq);
        session.execute(tableReq);
    }

    private String getFirstSelectedRowAsJson(int id) {
        String cqlStatement = "select JSON * "
                + "from " + config.getCassandraProps().getKeyspace() + "." + config.getCassandraProps().getTableName()
                + " where id=" + Integer.toString(id) + " ;";
        ResultSet rs = session.execute(cqlStatement);
        //return the whitespaces removed json value of the first row
        return rs.one().getString("[json]").replaceAll("\\s+", "");
    }

    /**
     * close the Cassandra  producer
     */
    @After
    public void tearDown() throws Exception {
        cassandraSink.close();
        EmbeddedCassandraServerHelper.cleanEmbeddedCassandra();
    }
}

