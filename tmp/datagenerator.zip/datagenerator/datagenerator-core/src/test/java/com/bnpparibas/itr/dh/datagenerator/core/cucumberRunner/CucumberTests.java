/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.cucumberRunner;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        format = {
                "pretty",
                "html:target/cucumber-html-report",
                "json:target/cucumber.json"
        },
        features="src/test/resources/features/",
        glue="com.bnpparibas.itr.dh.datagenerator.core"
)

public class CucumberTests {
}

