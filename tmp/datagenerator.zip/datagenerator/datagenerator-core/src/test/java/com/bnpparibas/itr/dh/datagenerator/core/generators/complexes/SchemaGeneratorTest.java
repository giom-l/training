/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.generators.complexes;

import com.bnpparibas.itr.dh.datagenerator.core.context.ExecutionContext;
import com.bnpparibas.itr.dh.datagenerator.core.generators.complexes.SchemaGenerator;
import com.bnpparibas.itr.dh.datagenerator.core.model.Config;
import com.bnpparibas.itr.dh.datagenerator.core.model.UserDictionary;
import org.apache.avro.Schema;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class SchemaGeneratorTest {
    private static final int EVENTS_SIZE = 10;

    private static final String EVENT_TYPE_NAME = "eventTypeName";
    private static final String NEW_CREDIT_REQUESTED = "NewCreditRequested";
    private static final String BRAND = "only_brand";
    private static final String HELLO_BANK = "helloBank";

    String fileFrontalOutput = getClass().getClassLoader().getResource("schemas/andy_schema_FrontalOutput.json").getPath();
    String fileBookingRequest = getClass().getClassLoader().getResource("schemas/andy_schema_BookingRequest.json").getPath();
    Config config = mock(Config.class);
    ExecutionContext context = new ExecutionContext(config);

    @Before
    public void setup() {
        UserDictionary eventTypeUserDictionary = mock(UserDictionary.class);
        UserDictionary brandUserDictionary = mock(UserDictionary.class);
        when(config.getUserDictionaries()).thenReturn(Arrays.asList(eventTypeUserDictionary, brandUserDictionary));

        when(eventTypeUserDictionary.getName()).thenReturn(EVENT_TYPE_NAME);
        when(eventTypeUserDictionary.getValues()).thenReturn(Collections.singletonList(NEW_CREDIT_REQUESTED));

        when(brandUserDictionary.getName()).thenReturn(BRAND);
        when(brandUserDictionary.getValues()).thenReturn(Collections.singletonList(HELLO_BANK));
    }

    @Test
    public void generate_should_generate_records_with_andy_FrontalOutput_schema() throws IOException {
        // GIVEN
        Schema andySchema = new Schema.Parser().parse(new File(fileFrontalOutput));
        // WHEN
        Map<String, Object> actual = SchemaGenerator.generate(context, andySchema, EVENTS_SIZE);
        // THEN
        assertThat(actual).isNotEmpty();
    }

    @Test
    public void generate_should_generate_records_with_andy_BookingRequest_schema() throws IOException {
        // GIVEN
        Schema andySchema = new Schema.Parser().parse(new File(fileBookingRequest));
        // WHEN
        Map<String, Object> actual = SchemaGenerator.generate(context, andySchema, EVENTS_SIZE);
        // THEN
        assertThat(actual).isNotEmpty();
    }

    @Test
    public void generate_should_generate_records_with_event_type_from_dictionary() throws IOException {
        // GIVEN
        Schema andySchema = new Schema.Parser().parse(new File(fileBookingRequest));
        // WHEN
        Map<String, Object> actual = SchemaGenerator.generate(context, andySchema, EVENTS_SIZE);
        // THEN
        assertThat(actual)
                .extracting("header")
                .extracting("functional")
                .extracting("eventType")
                .extracting(EVENT_TYPE_NAME).asList().containsExactly(Collections.nCopies(EVENTS_SIZE, NEW_CREDIT_REQUESTED));
    }

    @Test
    public void generate_should_generate_records_with_alias_brand_from_dictionary() throws IOException {
        // GIVEN
        Schema andySchema = new Schema.Parser().parse(new File(fileBookingRequest));
        // WHEN
        Map<String, Object> actual = SchemaGenerator.generate(context, andySchema, EVENTS_SIZE);
        // THEN
        assertThat(actual)
                .extracting("header")
                .extracting("functional")
                .extracting("eventLocalization")
                .extracting("brand").asList().containsExactly(Collections.nCopies(EVENTS_SIZE, HELLO_BANK));
    }
}