/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.generator.provider;

import com.bnpparibas.itr.dh.datagenerator.core.context.ExecutionContext;
import com.bnpparibas.itr.dh.datagenerator.core.model.UserDictionary;
import com.bnpparibas.itr.dh.datagenerator.core.utils.Const;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.bnpparibas.itr.dh.datagenerator.core.utils.Const.COMMA;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class DictionaryGeneratorTest {

    private static final String CITY_FIELD = "city";
    private static final String NAME_FIELD = "last-name";
    private static final String[] CITIES = { "Quito", "Fes" };
    private static final String DICO_FILE_PATH = "dictionary";
    private static String[] names;
    private DictionaryGenerator dictionaryGenerator = new DictionaryGenerator();

    @BeforeClass
    public static void setupClass() throws IOException {
        String dictoPath = DictionaryGeneratorTest.class.getClassLoader().getResource(DICO_FILE_PATH).getPath();
        List<String> lines = FileUtils.readLines(new File(dictoPath, NAME_FIELD), Charset.defaultCharset());
        names = lines.stream().map(line -> line.split(COMMA)).map(Arrays::asList).reduce((firstList, secondList) -> {
            firstList = new ArrayList<>(firstList);
            firstList.addAll(secondList);
            return firstList;
        }).orElseGet(ArrayList::new).toArray(new String[] {});
    }

    @Before
    public void setup() {
        ExecutionContext context = new ExecutionContext();
        UserDictionary userDictionary = mock(UserDictionary.class);
        when(userDictionary.getName()).thenReturn(CITY_FIELD);
        when(userDictionary.getValues()).thenReturn(Arrays.asList(CITIES));
        context.addProperty(Const.USER_DICO, Arrays.asList(userDictionary));
        dictionaryGenerator.init(context, null);
    }

    @Test
    public void nextValue_should_return_a_value_from_the_user_dictionary() {
        // GIVEN
        String fieldName = CITY_FIELD;
        // WHEN
        String result = dictionaryGenerator.nextValue(fieldName, fieldName);
        // THEN
        assertThat(CITIES, hasItemInArray(result));
    }

    @Test
    public void nextValue_should_return_a_value_from_the_user_dictionary_if_the_doc_is_present() {
        // GIVEN
        String doc = CITY_FIELD;
        // WHEN
        String result = dictionaryGenerator.nextValue(doc, StringUtils.EMPTY);
        // THEN
        assertThat(CITIES, hasItemInArray(result));
    }

    @Test
    public void nextValue_should_return_a_value_from_the_user_dictionary_if_the_fieldname_is_present() {
        // GIVEN
        String fieldName = CITY_FIELD;
        // WHEN
        String result = dictionaryGenerator.nextValue(StringUtils.EMPTY, fieldName);
        // THEN
        assertThat(CITIES, hasItemInArray(result));
    }

    @Test
    public void nextValue_should_return_a_value_from_the_static_dictionary_if_no_user_dictionary() {
        // GIVEN
        String fieldName = NAME_FIELD;
        // WHEN
        String result = dictionaryGenerator.nextValue(fieldName, fieldName);
        // THEN
        assertThat(names, hasItemInArray(result));
    }

    @Test
    public void nextValue_should_return_a_random_value_if_no_dictionary() {
        // GIVEN
        String fieldName = "lastname";
        // WHEN
        String result = dictionaryGenerator.nextValue(fieldName, fieldName);
        // THEN
        assertThat(result, is(notNullValue()));
    }
}
