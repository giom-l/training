/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.sink;

import com.bnpparibas.itr.dh.datagenerator.core.context.ExecutionContext;
import org.apache.commons.io.FilenameUtils;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class ArchiveSinkTest {

    @Rule
    public TemporaryFolder folder = new TemporaryFolder();

    private ArchiveSink archiveSink = new ArchiveSink(new ExecutionContext());

    @Test(expected = NullPointerException.class)
    public void compressFilesTestNull() throws IOException{
        archiveSink.compressFiles(null, null, null);
    }

    @Test
    public void compressFilesTest() throws IOException {
        File tmpFolder = folder.newFolder("targetFolder", "tmpFolder");
        File targetFolder = tmpFolder.getParentFile();

        archiveSink.compressFiles(targetFolder, tmpFolder, "archive");
        Files.walk(targetFolder.toPath())
                .filter(Files::isRegularFile)
                .map(Path::toString)
                .forEach((s) -> Assert.assertEquals(FilenameUtils.getExtension(s), "gz"));
    }
}