/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.generators.primitives.dictionary;


import com.bnpparibas.itr.dh.datagenerator.core.context.ExecutionContext;
import com.bnpparibas.itr.dh.datagenerator.core.generators.primitives.dictionary.UserDictionaryGenerator;
import com.bnpparibas.itr.dh.datagenerator.core.model.Config;
import com.bnpparibas.itr.dh.datagenerator.core.model.UserDictionary;
import org.apache.avro.Schema;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static com.bnpparibas.itr.dh.datagenerator.core.utils.Const.COMMA;
import static com.bnpparibas.itr.dh.datagenerator.core.utils.Const.UNIQUE_VALUE;
import static org.mockito.Mockito.mock;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

public class UserDictionaryGeneratorTest {
    private static final String DICTIONARY_DIR = "dictionary";
    private static final String CITY_FIELD_NAME = "city";
    private static final String NAME_FIELD_NAME = "name";
    private static final List<Object> NAME_USER_DICTIONARY_VALUES = Arrays.asList("LHERMENIER", "MATHIEU", "BEZZANOU");
    private Config config = mock(Config.class);
    private ExecutionContext context = new ExecutionContext(config);
    private List<Object> cityStaticDictionaryValues;

    @Before
    public void setup() {
        UserDictionary nameUserDictionary = mock(UserDictionary.class);
        when(nameUserDictionary.getName()).thenReturn(NAME_FIELD_NAME);
        when(nameUserDictionary.getValues()).thenReturn(NAME_USER_DICTIONARY_VALUES);

        when(config.getUserDictionaries()).thenReturn(Collections.singletonList(nameUserDictionary));

        cityStaticDictionaryValues = getStaticDictionary(CITY_FIELD_NAME);
    }

    @Test
    public void generate_should_return_a_value_from_static_dictionary() {
        // GIVEN
        Schema.Field field = new Schema.Field(CITY_FIELD_NAME, Schema.create(Schema.Type.STRING), StringUtils.EMPTY, StringUtils.EMPTY);
        field.addAlias(CITY_FIELD_NAME);
        // WHEN
        Optional<Object> actual = new UserDictionaryGenerator(context, field).generate();
        // THEN
        assertThat(actual).isPresent().get().isIn(cityStaticDictionaryValues);
    }

    @Test
    public void generate_should_return_a_value_from_user_dictionary() {
        // GIVEN
        Schema.Field field = new Schema.Field(NAME_FIELD_NAME, Schema.create(Schema.Type.STRING), StringUtils.EMPTY, StringUtils.EMPTY);
        field.addAlias(NAME_FIELD_NAME);
        // WHEN
        Optional<Object> actual = new UserDictionaryGenerator(context, field).generate();
        // THEN
        assertThat(actual).isPresent().get().isIn(NAME_USER_DICTIONARY_VALUES);
    }

    @Test
    public void generate_should_return_a_unique_values_from_user_dictionary_when_field_is_unique() {
        // GIVEN
        Schema.Field field = new Schema.Field(NAME_FIELD_NAME, Schema.create(Schema.Type.STRING), StringUtils.EMPTY, StringUtils.EMPTY);
        field.addAlias(NAME_FIELD_NAME);
        field.addAlias(UNIQUE_VALUE);
        UserDictionaryGenerator userDictionaryGenerator = new UserDictionaryGenerator(context, field);
        // WHEN
        List<Object> actual = IntStream.range(0, 2)
                .mapToObj(index -> userDictionaryGenerator.generate())
                .filter(Optional::isPresent)
                .map(Optional::get)
                .collect(Collectors.toList());
        HashSet<Object> expected = new HashSet<>(actual);
        // THEN
        assertThat(actual).containsExactlyInAnyOrderElementsOf(expected);
    }

    @Test
    public void generate_should_return_a_unique_values_from_static_dictionary_when_field_is_unique() {
        // GIVEN
        Schema.Field field = new Schema.Field(CITY_FIELD_NAME, Schema.create(Schema.Type.STRING), StringUtils.EMPTY, StringUtils.EMPTY);
        field.addAlias(CITY_FIELD_NAME);
        field.addAlias(UNIQUE_VALUE);
        UserDictionaryGenerator userDictionaryGenerator = new UserDictionaryGenerator(context, field);
        // WHEN
        List<Object> actual = IntStream.range(0, 10)
                .mapToObj(index -> userDictionaryGenerator.generate())
                .filter(Optional::isPresent)
                .map(Optional::get)
                .collect(Collectors.toList());
        HashSet<Object> expected = new HashSet<>(actual);
        // THEN
        assertThat(actual).containsExactlyInAnyOrderElementsOf(expected);
    }

    private List<Object> getStaticDictionary(String alias) {
        try {
            URL dicResource = getClass().getClassLoader().getResource(DICTIONARY_DIR);
            if (dicResource != null) {
                String dictionaryDir = dicResource.getPath();
                File[] files = new File(dictionaryDir).listFiles();
                if (files != null) {
                    return Arrays.stream(files)
                            .filter(file -> file.getName().equals(alias))
                            .findFirst().map(this::fileToValues)
                            .orElse(new ArrayList<>());
                }
            }
        } catch (Throwable throwable) {
        }
        return new ArrayList<>();
    }

    private List<Object> fileToValues(File file) {
        List<Object> result = new ArrayList<>();
        try {
            result = FileUtils.readLines(file, Charset.defaultCharset())
                    .stream()
                    .map(line -> Arrays.asList(line.split(COMMA)))
                    .flatMap(Collection::stream)
                    .collect(Collectors.toList());
        } catch (IOException e) {
        }
        return result;
    }
}