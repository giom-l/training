/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.generators.complexes;


import com.bnpparibas.itr.dh.datagenerator.core.context.ExecutionContext;
import com.bnpparibas.itr.dh.datagenerator.core.generators.complexes.ArrayGenerator;
import com.bnpparibas.itr.dh.datagenerator.core.model.Config;
import org.apache.avro.Schema;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import static org.apache.avro.Schema.Type.DOUBLE;
import static org.apache.commons.lang3.StringUtils.EMPTY;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

public class ArrayGeneratorTest {
    private static final String NAME_FIELD_NAME = "name";
    private static final String PRICE_FIELD_NAME = "price";
    private static final Schema NULLABLE_STRING_SCHEMA = Schema.createUnion(Schema.create(Schema.Type.NULL), Schema.create(Schema.Type.STRING));
    private static final Schema.Field NAME_FIELD = new Schema.Field(NAME_FIELD_NAME, NULLABLE_STRING_SCHEMA, EMPTY, EMPTY);
    private static final Schema.Field PRICE_FIELD = new Schema.Field(PRICE_FIELD_NAME, Schema.create(DOUBLE), EMPTY, EMPTY);
    private static final Schema ARRAY_SCHEMA = Schema.createArray(Schema.createRecord(Arrays.asList(NAME_FIELD, PRICE_FIELD)));
    private static final int VALUES_SIZE = 10;
    private static final String PRODUCTS_FIELD_NAME = "products";

    ArrayGenerator arrayGenerator = new ArrayGenerator();
    Config config = mock(Config.class);
    ExecutionContext context = new ExecutionContext(config);

    @Test
    public void generate_should_return_a_list_of_10() {
        // GIVEN
        Schema.Field field = new Schema.Field(PRODUCTS_FIELD_NAME, ARRAY_SCHEMA, EMPTY, EMPTY);
        // WHEN
        Object actual = arrayGenerator.generate(context, field, VALUES_SIZE);
        // THEN
        assertThat(actual).asList().hasSize(VALUES_SIZE);
    }

    @Test
    public void generate_should_return_a_list_of_price_lists() {
        // GIVEN
        Schema.Field field = new Schema.Field(PRODUCTS_FIELD_NAME, ARRAY_SCHEMA, EMPTY, EMPTY);
        // WHEN
        Object actual = arrayGenerator.generate(context, field, VALUES_SIZE);
        // THEN
        assertThat(actual).asList().extracting(PRICE_FIELD_NAME).asList().hasOnlyElementsOfType(List.class);
    }
}