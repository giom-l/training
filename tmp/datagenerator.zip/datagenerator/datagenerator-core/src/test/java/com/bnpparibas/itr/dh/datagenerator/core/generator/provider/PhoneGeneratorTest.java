/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.generator.provider;

import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.junit.Test;

import static com.bnpparibas.itr.dh.datagenerator.core.utils.Const.PHONE_REGEX;

public class PhoneGeneratorTest {

    private PhoneGenerator phoneGenerator = new PhoneGenerator();

    @Test
    public void testNextValuePhone() {
        String phoneNumber = phoneGenerator.nextValue(StringUtils.EMPTY, StringUtils.EMPTY);
        Assert.assertTrue(phoneNumber.matches(PHONE_REGEX));
    }
}

