/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.processors;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.Appender;
import com.bnpparibas.itr.dh.datagenerator.core.context.ExecutionContext;
import com.bnpparibas.itr.dh.datagenerator.core.exceptions.GeneratorCheckException;
import com.bnpparibas.itr.dh.datagenerator.core.model.Config;
import com.bnpparibas.itr.dh.datagenerator.core.testUtil.Util;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.internal.verification.AtLeast;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.URISyntaxException;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class MandatoryFieldsCheckTest {

    private static final String NO_OUTPUT_CONFIG_JSON = "mandatoryFieldsCheck/no_output_config.json";

    private static final String CSV_MISSING_REQUIRED_CSV_PROPS_CONF = "mandatoryFieldsCheck/csv_missing_csvProps.json";
    private static final String CSV_MISSING_REQUIRED_TARGETDIR_CONF = "mandatoryFieldsCheck/csv_missing_targetDir.json";
    private static final String CSV_MISSING_REQUIRED_ARCHIVENAME_CONF = "mandatoryFieldsCheck/csv_missing_archiveName.json";
    private static final String CSV_MISSING_REQUIRED_FILENAME_CONF = "mandatoryFieldsCheck/csv_missing_fileName.json";
    private static final String CSV_MISSING_REQUIRED_NUMBEROFLINES_CONF = "mandatoryFieldsCheck/csv_missing_numberOfLines.json";
    private static final String CSV_MISSING_REQUIRED_NUMBEROFFILES_CONF = "mandatoryFieldsCheck/csv_missing_numberOfFiles.json";
    private static final String CSV_MINIMAL_CONF = "mandatoryFieldsCheck/csv_minimal.json";

    private static final String USERDICT_MISSING_NAME_CONF = "mandatoryFieldsCheck/userDict_missing_name.json";
    private static final String USERDICT_MISSING_VALUES_CONF = "mandatoryFieldsCheck/userDict_missing_values.json";

    private static final String KAFKA_MISSING_REQUIRED_KAFKA_PROPS_CONF = "mandatoryFieldsCheck/kafka_missing_kafkaProps.json";
    private static final String KAFKA_MISSING_REQUIRED_BOOTSTRAPSERVERS_CONF = "mandatoryFieldsCheck/kafka_missing_bootstrapServers.json";
    private static final String KAFKA_MISSING_REQUIRED_NUMBEROFEVENTS_CONF = "mandatoryFieldsCheck/kafka_missing_numberOfEvents.json";
    private static final String KAFKA_MISSING_REQUIRED_SCHEMAREGISTRY_CONF = "mandatoryFieldsCheck/kafka_missing_schemaRegistry.json";
    private static final String KAFKA_MISSING_REQUIRED_TOPICNAME_CONF = "mandatoryFieldsCheck/kafka_missing_topicName.json";
    private static final String KAFKA_MISSING_REQUIRED_SSLKEYPASSWORD_CONF = "mandatoryFieldsCheck/kafka_missing_sslKeyPassword.json";
    private static final String KAFKA_MISSING_REQUIRED_SSLKEYSTORELOCATION_CONF = "mandatoryFieldsCheck/kafka_missing_sslKeyStoreLocation.json";
    private static final String KAFKA_MISSING_REQUIRED_SSLKEYSTOREPASSWORD_CONF = "mandatoryFieldsCheck/kafka_missing_sslKeyStorePassword.json";
    private static final String KAFKA_MISSING_REQUIRED_SSLSRKEYSTORELOCATION_CONF = "mandatoryFieldsCheck/kafka_missing_sslSRKeyStoreLocation.json";
    private static final String KAFKA_MISSING_REQUIRED_SSLSRKEYSTOREPASSWORD_CONF = "mandatoryFieldsCheck/kafka_missing_sslSRKeyStorePassword.json";
    private static final String KAFKA_MISSING_REQUIRED_SSLTRUSTSTORELOCATION_CONF = "mandatoryFieldsCheck/kafka_missing_sslTrustStoreLocation.json";
    private static final String KAFKA_MISSING_REQUIRED_SSLTRUSTSTOREPASSWORD_CONF = "mandatoryFieldsCheck/kafka_missing_sslTrustStorePassword.json";
    private static final String KAFKA_MINIMAL_CONF = "mandatoryFieldsCheck/kafka_minimal.json";

    private static final String CASSANDRA_MISSING_REQUIRED_CASSANDRA_PROPS_CONF = "mandatoryFieldsCheck/cassandra_missing_cassandraProps.json";
    private static final String CASSANDRA_MISSING_REQUIRED_CONTACTPOINTS_CONF = "mandatoryFieldsCheck/cassandra_missing_contactPoints.json";
    private static final String CASSANDRA_MISSING_REQUIRED_PORT_CONF = "mandatoryFieldsCheck/cassandra_missing_port.json";
    private static final String CASSANDRA_MISSING_REQUIRED_KEYSPACE_CONF = "mandatoryFieldsCheck/cassandra_missing_keyspace.json";
    private static final String CASSANDRA_MISSING_REQUIRED_USERNAME_CONF = "mandatoryFieldsCheck/cassandra_missing_username.json";
    private static final String CASSANDRA_MISSING_REQUIRED_PASSWORD_CONF = "mandatoryFieldsCheck/cassandra_missing_password.json";
    private static final String CASSANDRA_MISSING_REQUIRED_TABLENAME_CONF = "mandatoryFieldsCheck/cassandra_missing_tablename.json";
    private static final String CASSANDRA_MISSING_REQUIRED_NUMBEROFEVENTS_CONF = "mandatoryFieldsCheck/cassandra_missing_numberOfEvents.json";
    private static final String CASSANDRA_MISSING_REQUIRED_SECURITYPROPS_CONF = "mandatoryFieldsCheck/cassandra_missing_securityProps.json";
    private static final String CASSANDRA_MISSING_REQUIRED_JKSPASSWORD_CONF = "mandatoryFieldsCheck/cassandra_missing_jksPassword.json";
    private static final String CASSANDRA_MISSING_REQUIRED_JKSPATH_CONF = "mandatoryFieldsCheck/cassandra_missing_jksPath.json";
    private static final String CASSANDRA_MINIMAL_CONF = "mandatoryFieldsCheck/cassandra_minimal.json";

    private static final String API_MISSING_REQUIRED_API_PROPS_CONF = "mandatoryFieldsCheck/api_missing_apiProps.json";
    private static final String API_MISSING_REQUIRED_URL_CONF = "mandatoryFieldsCheck/api_missing_url.json";
    private static final String API_MISSING_REQUIRED_NUMBEROFEVENTS_CONF = "mandatoryFieldsCheck/api_missing_numberOfEvents.json";
    private static final String API_MINIMAL_CONF = "mandatoryFieldsCheck/api_minimal.json";


    private static MandatoryFieldsCheck check;
    private static final int AT_LEAST_ONCE = 1;
    private static final AtLeast AT_LEAST_ONCE_MODE = new AtLeast(AT_LEAST_ONCE);
    private static String expectedMsg;
    private static ExecutionContext context;


    @Mock
    private Appender<ILoggingEvent> appender;

    @Captor
    private ArgumentCaptor<ILoggingEvent> captor;

    @Before
    public void setup() {
        check = new MandatoryFieldsCheck();
        Object actualObj = this;
        MockitoAnnotations.initMocks(actualObj);

        ch.qos.logback.classic.Logger rootLogger = (ch.qos.logback.classic.Logger) LoggerFactory.getLogger("ROOT");
        rootLogger.addAppender(appender);

        when(appender.getName()).thenReturn("simple_logger_mock");
        when(appender.isStarted()).thenReturn(true);

        initExecutionContext();
    }

    private void initExecutionContext() {
        context = new ExecutionContext();
        context.setCorrelationId("correlationId");
        context.setParentCorrelationId("correlationId");
        context.setRootCorrelationId("correlationId");
    }

    @Test(expected = GeneratorCheckException.class)
    public void config_missing_userDict_name_should_raise_GeneratorCheckException() throws IOException, GeneratorCheckException, URISyntaxException {
        //given
        Config conf = Util.getResourceAsConfigs(USERDICT_MISSING_NAME_CONF).get(0);
        //when
        check.check(conf, context);
        //then raise exception
    }

    @Test(expected = GeneratorCheckException.class)
    public void config_missing_userDict_values_should_raise_GeneratorCheckException() throws IOException, GeneratorCheckException, URISyntaxException {
        //given
        Config conf = Util.getResourceAsConfigs(USERDICT_MISSING_VALUES_CONF).get(0);
        //when
        check.check(conf, context);
        //then raise exception
    }

    @Test(expected = GeneratorCheckException.class)
    public void config_missing_output_should_raise_GeneratorCheckException() throws IOException, GeneratorCheckException, URISyntaxException {
        //given
        Config conf = Util.getResourceAsConfigs(NO_OUTPUT_CONFIG_JSON).get(0);
        //when
        check.check(conf, context);
        //then raise exception
    }

    @Test(expected = GeneratorCheckException.class)
    public void csv_config_missing_csv_props_should_raise_GeneratorCheckException() throws IOException, GeneratorCheckException, URISyntaxException {
        //given
        Config conf = Util.getResourceAsConfigs(CSV_MISSING_REQUIRED_CSV_PROPS_CONF).get(0);
        //when
        try {
            check.check(conf, context);
        } catch (GeneratorCheckException gce) {
            expectedMsg = "MandatoryFieldCheck : [csvProps.targetDir ,csvProps.fileName ,csvProps.numberOfLines ,csvProps.numberOfFiles] missing";
            assertThat(gce.getMessage(), is(expectedMsg));
            throw gce;
        }
    }

    @Test(expected = GeneratorCheckException.class)
    public void csv_config_missing_targetDir_should_raise_GeneratorCheckException() throws IOException, GeneratorCheckException, URISyntaxException {
        //given
        Config conf = Util.getResourceAsConfigs(CSV_MISSING_REQUIRED_TARGETDIR_CONF).get(0);
        //when
        try {
            check.check(conf, context);
        } catch (GeneratorCheckException gce) {
            expectedMsg = "MandatoryFieldCheck : [csvProps.targetDir] missing";
            assertThat(gce.getMessage(), is(expectedMsg));
            throw gce;
        }
    }

    @Test(expected = GeneratorCheckException.class)
    public void csv_config_missing_fileName_should_raise_GeneratorCheckException() throws IOException, GeneratorCheckException, URISyntaxException {
        //given
        Config conf = Util.getResourceAsConfigs(CSV_MISSING_REQUIRED_FILENAME_CONF).get(0);
        //when
        try {
            check.check(conf, context);
        } catch (GeneratorCheckException gce) {
            expectedMsg = "MandatoryFieldCheck : [csvProps.fileName] missing";
            assertThat(gce.getMessage(), is(expectedMsg));
            throw gce;
        }
    }

    @Test(expected = GeneratorCheckException.class)
    public void csv_config_missing_numberOfLines_should_raise_GeneratorCheckException() throws IOException, GeneratorCheckException, URISyntaxException {
        //given
        Config conf = Util.getResourceAsConfigs(CSV_MISSING_REQUIRED_NUMBEROFLINES_CONF).get(0);
        //when
        try {
            check.check(conf, context);
        } catch (GeneratorCheckException gce) {
            expectedMsg = "MandatoryFieldCheck : [csvProps.numberOfLines] missing";
            assertThat(gce.getMessage(), is(expectedMsg));
            throw gce;
        }
    }

    @Test(expected = GeneratorCheckException.class)
    public void csv_config_missing_numberOfFiles_should_raise_GeneratorCheckException() throws IOException, GeneratorCheckException, URISyntaxException {
        //given
        Config conf = Util.getResourceAsConfigs(CSV_MISSING_REQUIRED_NUMBEROFFILES_CONF).get(0);
        //when
        try {
            check.check(conf, context);
        } catch (GeneratorCheckException gce) {
            expectedMsg = "MandatoryFieldCheck : [csvProps.numberOfFiles] missing";
            assertThat(gce.getMessage(), is(expectedMsg));
            throw gce;
        }
    }

    @Test(expected = GeneratorCheckException.class)
    public void csv_config_missing_archiveName_should_raise_GeneratorCheckException() throws IOException, GeneratorCheckException, URISyntaxException {
        //given
        Config conf = Util.getResourceAsConfigs(CSV_MISSING_REQUIRED_ARCHIVENAME_CONF).get(0);
        //when
        try {
            check.check(conf, context);
        } catch (GeneratorCheckException gce) {
            expectedMsg = "MandatoryFieldCheck : [csvProps.archiveName] missing";
            assertThat(gce.getMessage(), is(expectedMsg));
            throw gce;
        }
    }

    @Test
    public void csv_minimal_config_should_not_throw_exception() throws IOException, GeneratorCheckException, URISyntaxException {
        //given
        Config conf = Util.getResourceAsConfigs(CSV_MINIMAL_CONF).get(0);
        //when
        check.check(conf, context);
        //then
        verify(appender, AT_LEAST_ONCE_MODE).doAppend(captor.capture());
        ILoggingEvent value = captor.getValue();
        assertThat(value.getLevel(), not(is(Level.ERROR)));
    }

    @Test(expected = GeneratorCheckException.class)
    public void kafka_config_missing_kafka_props_should_raise_GeneratorCheckException() throws IOException, GeneratorCheckException, URISyntaxException {
        //given
        Config conf = Util.getResourceAsConfigs(KAFKA_MISSING_REQUIRED_KAFKA_PROPS_CONF).get(0);
        //when
        try {
            check.check(conf, context);
        } catch (GeneratorCheckException gce) {
            expectedMsg = "MandatoryFieldCheck : [kafkaProps.bootstrapServers ,kafkaProps.schemaRegistry ,kafkaProps.topicName ,kafkaProps.numberOfEvents] missing";
            assertThat(gce.getMessage(), is(expectedMsg));
            throw gce;
        }
    }

    @Test
    public void kafka_minimal_config_should_not_throw_exception() throws IOException, GeneratorCheckException, URISyntaxException {
        //given
        Config conf = Util.getResourceAsConfigs(KAFKA_MINIMAL_CONF).get(0);
        //when
        check.check(conf, context);
        //then
        verify(appender, AT_LEAST_ONCE_MODE).doAppend(captor.capture());
        ILoggingEvent value = captor.getValue();
        assertThat(value.getLevel(), not(is(Level.ERROR)));
    }

    @Test(expected = GeneratorCheckException.class)
    public void kafka_config_missing_bootstrapServers_should_raise_GeneratorCheckException() throws IOException, GeneratorCheckException, URISyntaxException {
        //given
        Config conf = Util.getResourceAsConfigs(KAFKA_MISSING_REQUIRED_BOOTSTRAPSERVERS_CONF).get(0);
        //when
        try {
            check.check(conf, context);
        } catch (GeneratorCheckException gce) {
            expectedMsg = "MandatoryFieldCheck : [kafkaProps.bootstrapServers] missing";
            assertThat(gce.getMessage(), is(expectedMsg));
            throw gce;
        }
    }

    @Test(expected = GeneratorCheckException.class)
    public void kafka_config_missing_numberOfEvents_should_raise_GeneratorCheckException() throws IOException, GeneratorCheckException, URISyntaxException {
        //given
        Config conf = Util.getResourceAsConfigs(KAFKA_MISSING_REQUIRED_NUMBEROFEVENTS_CONF).get(0);
        //when
        try {
            check.check(conf, context);
        } catch (GeneratorCheckException gce) {
            expectedMsg = "MandatoryFieldCheck : [kafkaProps.numberOfEvents] missing";
            assertThat(gce.getMessage(), is(expectedMsg));
            throw gce;
        }
    }

    @Test(expected = GeneratorCheckException.class)
    public void kafka_config_missing_schemaRegistry_should_raise_GeneratorCheckException() throws IOException, GeneratorCheckException, URISyntaxException {
        //given
        Config conf = Util.getResourceAsConfigs(KAFKA_MISSING_REQUIRED_SCHEMAREGISTRY_CONF).get(0);
        //when
        try {
            check.check(conf, context);
        } catch (GeneratorCheckException gce) {
            expectedMsg = "MandatoryFieldCheck : [kafkaProps.schemaRegistry] missing";
            assertThat(gce.getMessage(), is(expectedMsg));
            throw gce;
        }
    }

    @Test(expected = GeneratorCheckException.class)
    public void kafka_config_missing_topicName_should_raise_GeneratorCheckException() throws IOException, GeneratorCheckException, URISyntaxException {
        //given
        Config conf = Util.getResourceAsConfigs(KAFKA_MISSING_REQUIRED_TOPICNAME_CONF).get(0);
        //when
        try {
            check.check(conf, context);
        } catch (GeneratorCheckException gce) {
            expectedMsg = "MandatoryFieldCheck : [kafkaProps.topicName] missing";
            assertThat(gce.getMessage(), is(expectedMsg));
            throw gce;
        }
    }

    @Test(expected = GeneratorCheckException.class)
    public void kafka_config_missing_sslKeyPassword_should_raise_GeneratorCheckException() throws IOException, GeneratorCheckException, URISyntaxException {
        //given
        Config conf = Util.getResourceAsConfigs(KAFKA_MISSING_REQUIRED_SSLKEYPASSWORD_CONF).get(0);
        //when
        try {
            check.check(conf, context);
        } catch (GeneratorCheckException gce) {
            expectedMsg = "MandatoryFieldCheck : [kafkaProps.securityProps.sslKeyPassword] missing";
            assertThat(gce.getMessage(), is(expectedMsg));
            throw gce;
        }
    }

    @Test(expected = GeneratorCheckException.class)
    public void kafka_config_missing_sslKeyStoreLocation_should_raise_GeneratorCheckException() throws IOException, GeneratorCheckException, URISyntaxException {
        //given
        Config conf = Util.getResourceAsConfigs(KAFKA_MISSING_REQUIRED_SSLKEYSTORELOCATION_CONF).get(0);
        //when
        try {
            check.check(conf, context);
        } catch (GeneratorCheckException gce) {
            expectedMsg = "MandatoryFieldCheck : [kafkaProps.securityProps.sslKeyStoreLocation] missing";
            assertThat(gce.getMessage(), is(expectedMsg));
            throw gce;
        }
    }

    @Test(expected = GeneratorCheckException.class)
    public void kafka_config_missing_sslKeyStorePassword_should_raise_GeneratorCheckException() throws IOException, GeneratorCheckException, URISyntaxException {
        //given
        Config conf = Util.getResourceAsConfigs(KAFKA_MISSING_REQUIRED_SSLKEYSTOREPASSWORD_CONF).get(0);
        //when
        try {
            check.check(conf, context);
        } catch (GeneratorCheckException gce) {
            expectedMsg = "MandatoryFieldCheck : [kafkaProps.securityProps.sslKeyStorePassword] missing";
            assertThat(gce.getMessage(), is(expectedMsg));
            throw gce;
        }
    }

    @Test(expected = GeneratorCheckException.class)
    public void kafka_config_missing_sslSRKeyStoreLocation_should_raise_GeneratorCheckException() throws IOException, GeneratorCheckException, URISyntaxException {
        //given
        Config conf = Util.getResourceAsConfigs(KAFKA_MISSING_REQUIRED_SSLSRKEYSTORELOCATION_CONF).get(0);
        //when
        try {
            check.check(conf, context);
        } catch (GeneratorCheckException gce) {
            expectedMsg = "MandatoryFieldCheck : [kafkaProps.securityProps.sslSRKeyStoreLocation] missing";
            assertThat(gce.getMessage(), is(expectedMsg));
            throw gce;
        }
    }

    @Test(expected = GeneratorCheckException.class)
    public void kafka_config_missing_sslSRKeyStorePassword_should_raise_GeneratorCheckException() throws IOException, GeneratorCheckException, URISyntaxException {
        //given
        Config conf = Util.getResourceAsConfigs(KAFKA_MISSING_REQUIRED_SSLSRKEYSTOREPASSWORD_CONF).get(0);
        //when
        try {
            check.check(conf, context);
        } catch (GeneratorCheckException gce) {
            expectedMsg = "MandatoryFieldCheck : [kafkaProps.securityProps.sslSRKeyStorePassword] missing";
            assertThat(gce.getMessage(), is(expectedMsg));
            throw gce;
        }
    }

    @Test(expected = GeneratorCheckException.class)
    public void kafka_config_missing_sslTrustStoreLocation_should_raise_GeneratorCheckException() throws IOException, GeneratorCheckException, URISyntaxException {
        //given
        Config conf = Util.getResourceAsConfigs(KAFKA_MISSING_REQUIRED_SSLTRUSTSTORELOCATION_CONF).get(0);
        //when
        try {
            check.check(conf, context);
        } catch (GeneratorCheckException gce) {
            expectedMsg = "MandatoryFieldCheck : [kafkaProps.securityProps.sslTrustStoreLocation] missing";
            assertThat(gce.getMessage(), is(expectedMsg));
            throw gce;
        }
    }

    @Test(expected = GeneratorCheckException.class)
    public void kafka_config_missing_sslTrustStorePassword_should_raise_GeneratorCheckException() throws IOException, GeneratorCheckException, URISyntaxException {
        //given
        Config conf = Util.getResourceAsConfigs(KAFKA_MISSING_REQUIRED_SSLTRUSTSTOREPASSWORD_CONF).get(0);
        //when
        try {
            check.check(conf, context);
        } catch (GeneratorCheckException gce) {
            expectedMsg = "MandatoryFieldCheck : [kafkaProps.securityProps.sslTrustStorePassword] missing";
            assertThat(gce.getMessage(), is(expectedMsg));
            throw gce;
        }
    }

    @Test
    public void cassandra_minimal_config_should_not_throw_exception() throws IOException, GeneratorCheckException, URISyntaxException {
        //givendeeze
        Config conf = Util.getResourceAsConfigs(CASSANDRA_MINIMAL_CONF).get(0);
        //when
        check.check(conf, context);
        //then
        verify(appender, AT_LEAST_ONCE_MODE).doAppend(captor.capture());
        ILoggingEvent value = captor.getValue();
        assertThat(value.getLevel(), not(is(Level.ERROR)));
    }


    @Test(expected = GeneratorCheckException.class)
    public void cassandra_config_missing_cassandra_props_should_raise_GeneratorCheckException() throws IOException, GeneratorCheckException, URISyntaxException {
        //given
        Config conf = Util.getResourceAsConfigs(CASSANDRA_MISSING_REQUIRED_CASSANDRA_PROPS_CONF).get(0);
        //when
        try {
            check.check(conf, context);
        } catch (GeneratorCheckException gce) {
            String expectedMsg = "MandatoryFieldCheck : [cassandraProps.contactPoints ,cassandraProps.port ,cassandraProps.keyspace ,cassandraProps.userName ,cassandraProps.password ,cassandraProps.tableName ,cassandraProps.numberOfEvents] missing";
            assertThat(gce.getMessage(), is(expectedMsg));
            throw gce;
        }
    }

    @Test(expected = GeneratorCheckException.class)
    public void cassandra_config_missing_contact_points_should_raise_GeneratorCheckException() throws IOException, GeneratorCheckException, URISyntaxException {
        //given
        Config conf = Util.getResourceAsConfigs(CASSANDRA_MISSING_REQUIRED_CONTACTPOINTS_CONF).get(0);
        //when
        try {
            check.check(conf, context);
        } catch (GeneratorCheckException gce) {
            String expectedMsg = "MandatoryFieldCheck : [cassandraProps.contactPoints] missing";
            assertThat(gce.getMessage(), is(expectedMsg));
            throw gce;
        }
    }


    @Test(expected = GeneratorCheckException.class)
    public void cassandra_config_missing_jks_password_should_raise_GeneratorCheckException() throws IOException, GeneratorCheckException, URISyntaxException {
        //given
        Config conf = Util.getResourceAsConfigs(CASSANDRA_MISSING_REQUIRED_JKSPASSWORD_CONF).get(0);
        //when
        try {
            check.check(conf, context);
        } catch (GeneratorCheckException gce) {
            String expectedMsg = "MandatoryFieldCheck : [cassandraProps.securityProps.jksPassword] missing";
            assertThat(gce.getMessage(), is(expectedMsg));
            throw gce;
        }
    }

    @Test(expected = GeneratorCheckException.class)
    public void cassandra_config_missing_jks_path_should_raise_GeneratorCheckException() throws IOException, GeneratorCheckException, URISyntaxException {
        //given
        Config conf = Util.getResourceAsConfigs(CASSANDRA_MISSING_REQUIRED_JKSPATH_CONF).get(0);
        //when
        try {
            check.check(conf, context);
        } catch (GeneratorCheckException gce) {
            String expectedMsg = "MandatoryFieldCheck : [cassandraProps.securityProps.jksPath] missing";
            assertThat(gce.getMessage(), is(expectedMsg));
            throw gce;
        }
    }

    @Test(expected = GeneratorCheckException.class)
    public void cassandra_config_missing_keyspace_should_raise_GeneratorCheckException() throws IOException, GeneratorCheckException, URISyntaxException {
        //given
        Config conf = Util.getResourceAsConfigs(CASSANDRA_MISSING_REQUIRED_KEYSPACE_CONF).get(0);
        //when
        try {
            check.check(conf, context);
        } catch (GeneratorCheckException gce) {
            String expectedMsg = "MandatoryFieldCheck : [cassandraProps.keyspace] missing";
            assertThat(gce.getMessage(), is(expectedMsg));
            throw gce;
        }
    }

    @Test(expected = GeneratorCheckException.class)
    public void cassandra_config_missing_number_of_events_should_raise_GeneratorCheckException() throws IOException, GeneratorCheckException, URISyntaxException {
        //given
        Config conf = Util.getResourceAsConfigs(CASSANDRA_MISSING_REQUIRED_NUMBEROFEVENTS_CONF).get(0);
        //when
        try {
            check.check(conf, context);
        } catch (GeneratorCheckException gce) {
            String expectedMsg = "MandatoryFieldCheck : [cassandraProps.numberOfEvents] missing";
            assertThat(gce.getMessage(), is(expectedMsg));
            throw gce;
        }
    }

    @Test(expected = GeneratorCheckException.class)
    public void cassandra_config_missing_password_should_raise_GeneratorCheckException() throws IOException, GeneratorCheckException, URISyntaxException {
        //given
        Config conf = Util.getResourceAsConfigs(CASSANDRA_MISSING_REQUIRED_PASSWORD_CONF).get(0);
        //when
        try {
            check.check(conf, context);
        } catch (GeneratorCheckException gce) {
            String expectedMsg = "MandatoryFieldCheck : [cassandraProps.password] missing";
            assertThat(gce.getMessage(), is(expectedMsg));
            throw gce;
        }
    }

    @Test(expected = GeneratorCheckException.class)
    public void cassandra_config_missing_port_should_raise_GeneratorCheckException() throws IOException, GeneratorCheckException, URISyntaxException {
        //given
        Config conf = Util.getResourceAsConfigs(CASSANDRA_MISSING_REQUIRED_PORT_CONF).get(0);
        //when
        try {
            check.check(conf, context);
        } catch (GeneratorCheckException gce) {
            String expectedMsg = "MandatoryFieldCheck : [cassandraProps.port] missing";
            assertThat(gce.getMessage(), is(expectedMsg));
            throw gce;
        }
    }

    @Test(expected = GeneratorCheckException.class)
    public void cassandra_config_missing_security_props_should_raise_GeneratorCheckException() throws IOException, GeneratorCheckException, URISyntaxException {
        //given
        Config conf = Util.getResourceAsConfigs(CASSANDRA_MISSING_REQUIRED_SECURITYPROPS_CONF).get(0);
        //when
        try {
            check.check(conf, context);
        } catch (GeneratorCheckException gce) {
            expectedMsg = "MandatoryFieldCheck : [cassandraProps.securityProps.jksPath ,cassandraProps.securityProps.jksPassword] missing";
            assertThat(gce.getMessage(), is(expectedMsg));
            throw gce;
        }
    }

    @Test(expected = GeneratorCheckException.class)
    public void cassandra_config_missing_table_name_should_raise_GeneratorCheckException() throws IOException, GeneratorCheckException, URISyntaxException {
        //given
        Config conf = Util.getResourceAsConfigs(CASSANDRA_MISSING_REQUIRED_TABLENAME_CONF).get(0);
        //when
        try {
            check.check(conf, context);
        } catch (GeneratorCheckException gce) {
            expectedMsg = "MandatoryFieldCheck : [cassandraProps.tableName] missing";
            assertThat(gce.getMessage(), is(expectedMsg));
            throw gce;
        }
    }

    @Test(expected = GeneratorCheckException.class)
    public void cassandra_config_missing_username_should_raise_GeneratorCheckException() throws IOException, GeneratorCheckException, URISyntaxException {
        //given
        Config conf = Util.getResourceAsConfigs(CASSANDRA_MISSING_REQUIRED_USERNAME_CONF).get(0);
        //when
        try {
            check.check(conf, context);
        } catch (GeneratorCheckException gce) {
            expectedMsg = "MandatoryFieldCheck : [cassandraProps.userName] missing";
            assertThat(gce.getMessage(), is(expectedMsg));
            throw gce;
        }
    }

    @Test
    public void api_minimal_config_should_not_throw_exception() throws IOException, GeneratorCheckException, URISyntaxException {
        //given
        Config conf = Util.getResourceAsConfigs(API_MINIMAL_CONF).get(0);
        //when
        check.check(conf, context);
        //then
        verify(appender, AT_LEAST_ONCE_MODE).doAppend(captor.capture());
        ILoggingEvent value = captor.getValue();
        assertThat(value.getLevel(), not(is(Level.ERROR)));
    }

    @Test(expected = GeneratorCheckException.class)
    public void api_config_missing_url_should_raise_GeneratorCheckException() throws IOException, GeneratorCheckException, URISyntaxException {
        //given
        Config conf = Util.getResourceAsConfigs(API_MISSING_REQUIRED_URL_CONF).get(0);
        //when
        try {
            check.check(conf, context);
        } catch (GeneratorCheckException gce) {
            String expectedMsg = "MandatoryFieldCheck : [apiProps.url] missing";
            assertThat(gce.getMessage(), is(expectedMsg));
            throw gce;
        }
    }

    //then raise exception
    @Test(expected = GeneratorCheckException.class)
    public void api_config_missing_numberOfEvents_should_raise_GeneratorCheckException() throws IOException, GeneratorCheckException, URISyntaxException {
        //given
        Config conf = Util.getResourceAsConfigs(API_MISSING_REQUIRED_NUMBEROFEVENTS_CONF).get(0);
        //when
        try {
            check.check(conf, context);
        } catch (GeneratorCheckException gce) {
            String expectedMsg = "MandatoryFieldCheck : [apiProps.numberOfEvents] missing";
            assertThat(gce.getMessage(), is(expectedMsg));
            throw gce;
        }
    }

    @Test(expected = GeneratorCheckException.class)
    public void api_config_missing_api_props_should_raise_GeneratorCheckException() throws IOException, GeneratorCheckException, URISyntaxException {
        //given
        Config conf = Util.getResourceAsConfigs(API_MISSING_REQUIRED_API_PROPS_CONF).get(0);
        //when
        try {
            check.check(conf, context);
        } catch (GeneratorCheckException gce) {
            String expectedMsg = "MandatoryFieldCheck : [apiProps.url ,apiProps.numberOfEvents] missing";
            assertThat(gce.getMessage(), is(expectedMsg));
            throw gce;
        }
    }
}