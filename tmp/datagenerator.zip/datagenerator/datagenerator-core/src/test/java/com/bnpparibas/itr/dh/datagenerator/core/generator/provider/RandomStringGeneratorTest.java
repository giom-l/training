/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.generator.provider;

import org.apache.commons.lang3.StringUtils;
import org.junit.Test;

import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;

public class RandomStringGeneratorTest {

    private RandomStringsGenerator randomStringGenerator = new RandomStringsGenerator();

    @Test
    public void generateNaughtyString(){
        // GIVEN
        //WHEN
        String naughtyString = randomStringGenerator.nextValue(StringUtils.EMPTY, StringUtils.EMPTY);
        // THEN
        assertThat(naughtyString, notNullValue());
    }

    @Test
    public void generateNaughtyStringShoudNotReturnComment(){
        // GIVEN
        char commentChar = '#';
        //WHEN
        String naughtyString = randomStringGenerator.nextValue(StringUtils.EMPTY, StringUtils.EMPTY);
        // THEN
        assertThat(naughtyString.charAt(0), not(commentChar));
    }
}
