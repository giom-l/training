/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.utils;

import org.apache.avro.Schema;
import org.junit.Assert;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.util.Optional;

public class DDAComplianceTest {

    @Test
    public void if_rootCorrelationId_is_not_in_schema_we_should_add_it() throws IOException {
        //given rootCorrelationId is not present
        Schema.Parser parser = new Schema.Parser();
        InputStream schemaStream = getClass().getClassLoader().getResourceAsStream("schemas/schema.json");
        Schema schema = parser.parse(schemaStream);
        //when we run DDACompliance
        Schema newSchema = DDACompliance.addCorrelationIds(schema);
        //then rootCorrelationId is present
        Optional<String> rootCorrelationId = newSchema.getFields().stream().map(Schema.Field::name)
                .filter(name -> "rootCorrelationId".equals(name)).findFirst();
        Assert.assertTrue(rootCorrelationId.isPresent());
    }

    @Test
    public void if_parentCorrelationId_is_not_in_schema_we_should_add_it() throws IOException {
        //given parentCorrelationId is not present
        Schema.Parser parser = new Schema.Parser();
        InputStream schemaStream = getClass().getClassLoader().getResourceAsStream("schemas/schema.json");
        Schema schema = parser.parse(schemaStream);
        //when we run DDACompliance
        Schema newSchema = DDACompliance.addCorrelationIds(schema);
        //then rootCorrelationId is present
        Optional<String> parentCorrelationId = newSchema.getFields().stream().map(Schema.Field::name)
                .filter(name -> "parentCorrelationId".equals(name)).findFirst();
        Assert.assertTrue(parentCorrelationId.isPresent());
    }

    @Test
    public void if_rootCorrelationId_is_in_schema_we_should_not_change_it() throws IOException {
        //given
        Schema.Parser parser = new Schema.Parser();
        InputStream schemaStream = getClass().getClassLoader().getResourceAsStream("schemas/schema_with_rootId.json");
        Schema schema = parser.parse(schemaStream);
        //when
        Schema newSchema = DDACompliance.addCorrelationIds(schema);
        //then
        Optional<String> rootCorrelationId = newSchema.getFields().stream().map(Schema.Field::name)
                .filter(name -> "rootCorrelationId".equals(name)).findFirst();
        Assert.assertTrue(rootCorrelationId.isPresent());
    }

    @Test
    public void if_parentCorrelationId_is_in_schema_we_should_not_change_it() throws IOException {
        //given
        Schema.Parser parser = new Schema.Parser();
        InputStream schemaStream = getClass().getClassLoader().getResourceAsStream("schemas/schema_with_parentId.json");
        Schema schema = parser.parse(schemaStream);
        //when
        Schema newSchema = DDACompliance.addCorrelationIds(schema);
        //then
        Optional<String> parentCorrelationId = newSchema.getFields().stream().map(Schema.Field::name)
                .filter(name -> "parentCorrelationId".equals(name)).findFirst();
        Assert.assertTrue(parentCorrelationId.isPresent());
    }

    @Test
    public void if_parentAndRootCorrelationIds_are_in_schema_we_should_not_change_it() throws IOException {
        //given
        Schema.Parser parser = new Schema.Parser();
        InputStream schemaStream = getClass().getClassLoader().getResourceAsStream("schemas/schema_with_allId.json");
        Schema schema = parser.parse(schemaStream);
        //when
        Schema newSchema = DDACompliance.addCorrelationIds(schema);
        //then
        Assert.assertSame(newSchema, schema);
    }
}
