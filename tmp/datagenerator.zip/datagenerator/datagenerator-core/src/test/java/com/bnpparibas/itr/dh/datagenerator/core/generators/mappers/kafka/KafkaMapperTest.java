/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.generators.mappers.kafka;

import com.bnpparibas.itr.dh.datagenerator.core.context.ExecutionContext;
import com.bnpparibas.itr.dh.datagenerator.core.generators.complexes.SchemaGenerator;
import com.bnpparibas.itr.dh.datagenerator.core.generators.mappers.kafka.KafkaMapper;
import com.bnpparibas.itr.dh.datagenerator.core.model.Config;
import org.apache.avro.Schema;
import org.apache.avro.generic.GenericRecord;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import static org.mockito.Mockito.mock;
import static org.assertj.core.api.Assertions.assertThat;

public class KafkaMapperTest {
    private static final int EVENTS_SIZE = 10;
    String fileFrontalOutput = getClass().getClassLoader().getResource("schemas/andy_schema_FrontalOutput.json").getPath();

    Schema frontalOutputSchema;
    Config config = mock(Config.class);
    ExecutionContext context = new ExecutionContext(config);

    @Before
    public void setup() throws IOException {
        frontalOutputSchema = new Schema.Parser().parse(new File(fileFrontalOutput));
    }

    @Test
    public void readFrom_should_return_10_generic_record_corresponding_to_FrontalOutput_schema() {
        // GIVEN
        Map<String, Object> values = SchemaGenerator.generate(context, frontalOutputSchema, EVENTS_SIZE);
        // WHEN
        List<GenericRecord> actual = new KafkaMapper().readFrom(frontalOutputSchema, values);
        // THEN
        assertThat(actual).hasSize(EVENTS_SIZE);
    }

}