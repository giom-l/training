/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.generator;

import com.bnpparibas.itr.dh.datagenerator.core.context.ExecutionContext;
import com.bnpparibas.itr.dh.datagenerator.core.testUtil.Util;
import org.apache.avro.Schema;
import org.apache.avro.generic.GenericRecord;
import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.URISyntaxException;

public class EventGeneratorTest {
    private static final Logger logger = LoggerFactory.getLogger(EventGeneratorTest.class);
    public static final ExecutionContext CONTEXT = new ExecutionContext();

    private static EventGenerator eventGenerator;
    private static Schema schema;
    private static GenericRecord realGenericRecord;

    /**
     * Test the function generate of the class EventGenerator with all the possible values
     */
    @Test
    public void generateTest() throws IOException, URISyntaxException {
        //Given
        schema = Util.getResourceAsSchema("schemas/schema.json");
        eventGenerator = new EventGenerator(CONTEXT, schema);

        //When
        realGenericRecord = eventGenerator.generate();

        //Then
        for (Schema.Field field : schema.getFields()) {
            Assert.assertEquals(realGenericRecord.getSchema().getField(field.name()).schema(), field.schema());
        }
    }

    /**
     * Test the generation of random data from a real schema of IRMA
     */
    @Test
    public void generateIRMATest() throws IOException, URISyntaxException {
        //Given
        schema = Util.getResourceAsSchema("schemas/schemaIrmaPartyMain.json");
        eventGenerator = new EventGenerator(CONTEXT, schema);

        //When
        realGenericRecord = eventGenerator.generate();

        //Then
        for (Schema.Field field : schema.getFields()) {
            Assert.assertEquals(realGenericRecord.getSchema().getField(field.name()).schema(), field.schema());
        }
    }

    /**
     * Test the generation of fake data from a schema of IRMA
     */
    @Test
    public void generateIRMAWithoutNullTest() throws IOException, URISyntaxException {
        //Given
        schema = Util.getResourceAsSchema("schemas/schemaIrmaPartyMainWithoutNull.json");
        eventGenerator = new EventGenerator(CONTEXT, schema);

        //When
        realGenericRecord = eventGenerator.generate();

        //Then
        for (Schema.Field field : schema.getFields()) {
            Assert.assertEquals(realGenericRecord.getSchema().getField(field.name()).schema(), field.schema());
        }
    }


    @Test
    public void customFakerTest() throws IOException, URISyntaxException {
        //Given
        schema = Util.getResourceAsSchema("schemas/schemaCustomFaker.json");
        eventGenerator = new EventGenerator(CONTEXT, schema);

        //When
        realGenericRecord = eventGenerator.generate();

        //Then
        for (Schema.Field field : schema.getFields()) {
            Assert.assertEquals(realGenericRecord.getSchema().getField(field.name()).schema(), field.schema());
        }

    }

}