/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.processors;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.Appender;
import com.bnpparibas.itr.dh.datagenerator.core.context.ExecutionContext;
import com.bnpparibas.itr.dh.datagenerator.core.exceptions.GeneratorCheckException;
import com.bnpparibas.itr.dh.datagenerator.core.exceptions.GeneratorCheckValuesCountException;
import com.bnpparibas.itr.dh.datagenerator.core.model.Config;
import com.bnpparibas.itr.dh.datagenerator.core.testUtil.Util;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.internal.verification.AtLeast;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.URISyntaxException;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class DictionaryCheckTest {

    private static final String DICT_CHECK_PATH = "dictionariesCheck/";
    private static final String NO_DICT_DEFINED_CONFIG_JSON = DICT_CHECK_PATH + "no_dict_defined_config.json";
    private static final String STATIC_DICT_DEFINED_ONLY_CONFIG_JSON = DICT_CHECK_PATH + "static_dict_defined_only_config.json";
    private static final String BOTH_DICT_DEFINED_CONFIG_JSON = DICT_CHECK_PATH + "both_dict_defined_config.json";
    private static final String UNIQUE_NOT_ENOUGH_VALUES_CONFIG_JSON = DICT_CHECK_PATH + "unique_not_enough_values_config.json";
    private static final String UNIQUE_ENOUGH_VALUE_CONFIG_JSON = DICT_CHECK_PATH + "unique_enough_values_config.json";
    private static final String USERDICT_DEFINED_CONFIG_JSON = DICT_CHECK_PATH + "userDict_defined_config.json";
    private static DictionaryCheck check;
    private static final int AT_LEAST_ONCE = 1;
    private static final AtLeast AT_LEAST_ONCE_MODE = new AtLeast(AT_LEAST_ONCE);

    private static ExecutionContext context;

    @Mock
    private Appender<ILoggingEvent> appender;

    @Captor
    private ArgumentCaptor<ILoggingEvent> captor;

    @Before
    public void setup() {
        check = new DictionaryCheck();
        Object actualObj = this;
        MockitoAnnotations.initMocks(actualObj);

        ch.qos.logback.classic.Logger rootLogger = (ch.qos.logback.classic.Logger) LoggerFactory.getLogger("ROOT");
        rootLogger.addAppender(appender);

        when(appender.getName()).thenReturn("simple_logger_mock");
        when(appender.isStarted()).thenReturn(true);

        initExecutionContext();
    }

    private void initExecutionContext() {
        context = new ExecutionContext();
        context.setCorrelationId("correlationId");
        context.setParentCorrelationId("correlationId");
        context.setRootCorrelationId("correlationId");
    }

    /*
    This test should be reactivated after the dictionnaryCheck is made on all conf list and not one by one

    @Test(expected = GeneratorCheckException.class)
    public void a_dict_alias_with_no_corresponding_dict_should_raise_Exception() throws IOException, GeneratorCheckException, URISyntaxException {
        //given
        Config conf = Util.getResourceAsConfigs(NO_DICT_DEFINED_CONFIG_JSON);
        //when
        check.check(conf);
        //then raise exception
    }
    */

    @Test
    public void a_dict_alias_without_corresponding_userDict_and_with_corresponding_staticDict_should_run_properly() throws IOException, GeneratorCheckException, URISyntaxException {
        //given
        Config conf = Util.getResourceAsConfigs(STATIC_DICT_DEFINED_ONLY_CONFIG_JSON).get(0);
        //when
        check.check(conf, context);
        //then
        verify(appender, AT_LEAST_ONCE_MODE).doAppend(captor.capture());
        ILoggingEvent value = captor.getValue();
        assertThat(value.getLevel(), not(is(Level.ERROR)));
    }

    @Test
    public void a_dict_alias_with_corresponding_userDict_and_staticDict_should_use_userDict() throws IOException,GeneratorCheckException, URISyntaxException {
        //given
        Config conf = Util.getResourceAsConfigs(BOTH_DICT_DEFINED_CONFIG_JSON).get(0);
        //when
        check.check(conf, context);
        //then
        verify(appender, AT_LEAST_ONCE_MODE).doAppend(captor.capture());
        ILoggingEvent value = captor.getValue();
        assertThat(value.getLevel(), not(is(Level.ERROR)));
    }

    @Test
    public void a_dict_alias_with_corresponding_userDict_should_run_properly() throws IOException, GeneratorCheckException, URISyntaxException {
        //given
        Config conf = Util.getResourceAsConfigs(USERDICT_DEFINED_CONFIG_JSON).get(0);
        //when
        check.check(conf, context);
        //then
        verify(appender, AT_LEAST_ONCE_MODE).doAppend(captor.capture());
        ILoggingEvent value = captor.getValue();
        assertThat(value.getLevel(), not(is(Level.ERROR)));
    }

    @Test(expected = GeneratorCheckValuesCountException.class)
    public void a_unique_alias_with_corresponding_userDict_without_enough_values_should_raise_Exception() throws IOException, GeneratorCheckException, URISyntaxException {
        //given
        Config conf = Util.getResourceAsConfigs(UNIQUE_NOT_ENOUGH_VALUES_CONFIG_JSON).get(0);
        //when
        check.check(conf, context);
        //then raise exception
    }

    @Test
    public void a_field_declared_unique_with_userDict_with_enough_values_should_run_properly() throws IOException, GeneratorCheckException, URISyntaxException {
        //given
        Config conf = Util.getResourceAsConfigs(UNIQUE_ENOUGH_VALUE_CONFIG_JSON).get(0);
        //when
        check.check(conf, context);
        //then
        verify(appender, AT_LEAST_ONCE_MODE).doAppend(captor.capture());
        ILoggingEvent value = captor.getValue();
        assertThat(value.getLevel(), not(is(Level.ERROR)));
    }

}
