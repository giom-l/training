/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core;

import com.bnpparibas.itr.dh.datagenerator.core.generator.EventGenerator;
import com.bnpparibas.itr.dh.datagenerator.core.stream.EventIterator;
import org.apache.avro.Schema;
import org.apache.avro.SchemaBuilder;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;
import org.apache.commons.lang3.StringUtils;
import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class EventIteratorTest {
    private EventIterator eventIterator;
    private Schema schema = SchemaBuilder.record("test").fields()
            .name("nom")
            .type("string")
            .withDefault(StringUtils.EMPTY)
            .endRecord();
    private GenericRecord genericRecord = new GenericData.Record(schema);

    @Before
    public void setUp(){
        EventGenerator eventGeneratorMock = mock(EventGenerator.class);
        when(eventGeneratorMock.generate()).thenReturn(genericRecord);
        eventIterator = new EventIterator(eventGeneratorMock);
    }

    @Test
    public void hasNextTest(){
        // GIVEN
        // WHEN
        boolean actual = eventIterator.hasNext();
        // THEN
        assertThat(actual, is(true));
    }

    @Test
    public void nextTest(){
        // GIVEN
        // WHEN
        GenericRecord actual = eventIterator.next();
        // THEN
        assertThat(actual, is(genericRecord));
    }
}
