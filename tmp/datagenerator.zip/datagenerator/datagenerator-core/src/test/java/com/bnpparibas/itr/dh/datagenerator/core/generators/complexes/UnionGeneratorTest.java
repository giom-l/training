/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.generators.complexes;


import com.bnpparibas.itr.dh.datagenerator.core.context.ExecutionContext;
import com.bnpparibas.itr.dh.datagenerator.core.generators.complexes.UnionGenerator;
import com.bnpparibas.itr.dh.datagenerator.core.model.Config;
import com.bnpparibas.itr.dh.datagenerator.core.model.KafkaProps;
import org.apache.avro.Schema;
import org.apache.commons.lang3.StringUtils;
import org.junit.Before;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class UnionGeneratorTest {
    private static final Schema UNION_TYPE = Schema.createUnion(Schema.create(Schema.Type.NULL), Schema.create(Schema.Type.STRING));
    private static final String NAME_FIELD = "name";
    private static final int EVENTS_SIZE = 10;

    Config config = mock(Config.class);
    ExecutionContext context = new ExecutionContext(config);
    UnionGenerator unionGenerator = new UnionGenerator();

    @Before
    public void setup(){
        KafkaProps kafkaProps = mock(KafkaProps.class);
        when(config.getKafkaProps()).thenReturn(kafkaProps);
        when(kafkaProps.getNumberOfEvents()).thenReturn(EVENTS_SIZE);
    }

    @Test
    public void generate_should_return_fixed_list(){
        // GIVEN
        Schema.Field field = new Schema.Field(NAME_FIELD, UNION_TYPE, StringUtils.EMPTY, StringUtils.EMPTY);
        // WHEN
        Object actual = unionGenerator.generate(context, field, EVENTS_SIZE);
        // THEN
        assertThat(actual).asList().hasSize(EVENTS_SIZE);
    }

    @Test
    public void generate_should_return_list_of_string_values(){
        // GIVEN
        Schema.Field field = new Schema.Field(NAME_FIELD, UNION_TYPE, StringUtils.EMPTY, StringUtils.EMPTY);
        // WHEN
        Object actual = unionGenerator.generate(context, field, EVENTS_SIZE);
        // THEN
        assertThat(actual).asList().hasOnlyElementsOfType(String.class);
    }
}