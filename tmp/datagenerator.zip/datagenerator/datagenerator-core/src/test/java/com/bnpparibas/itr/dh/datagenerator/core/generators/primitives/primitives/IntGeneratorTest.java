package com.bnpparibas.itr.dh.datagenerator.core.generators.primitives.primitives;

import com.bnpparibas.itr.dh.datagenerator.core.context.ExecutionContext;
import com.bnpparibas.itr.dh.datagenerator.core.model.Config;
import org.apache.avro.Schema;
import org.apache.commons.lang3.StringUtils;
import org.junit.Test;

import java.util.Optional;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;

public class IntGeneratorTest {

    public static final String ACTIVE_FIELD = "active";
    Config config = mock(Config.class);
    ExecutionContext context = new ExecutionContext(config);

    @Test
    public void intGenerator_with_range_alias_should_generate_a_random_int_in_given_range() {
        // GIVEN
        Schema.Field field = new Schema.Field(ACTIVE_FIELD, Schema.create(Schema.Type.INT), StringUtils.EMPTY, null);
        field.addAlias("range:-40:-10");
        int min = -40;
        int max = -10;
        // WHEN
        Optional<Object> actual = new IntGenerator(context, field).generate();
        int generated = (int) actual.get();
        // THEN
        assertTrue(min <= generated && generated <= max);
    }

    @Test
    public void intGenerator_with_positive_domain_alias_should_generate_a_random_positive_int() {
        // GIVEN
        Schema.Field field = new Schema.Field(ACTIVE_FIELD, Schema.create(Schema.Type.INT), StringUtils.EMPTY, null);
        field.addAlias("domain:positive");
        // WHEN
        Optional<Object> actual = new IntGenerator(context, field).generate();
        int generated = (int) actual.get();
        // THEN
        assertTrue(generated > 0);
    }

    @Test
    public void intGenerator_with_negative_domain_alias_should_generate_a_random_negative_int() {
        // GIVEN
        Schema.Field field = new Schema.Field(ACTIVE_FIELD, Schema.create(Schema.Type.INT), StringUtils.EMPTY, null);
        field.addAlias("domain:negative");
        // WHEN
        Optional<Object> actual = new IntGenerator(context, field).generate();
        int generated = (int) actual.get();
        // THEN
        assertTrue(generated < 0);
    }
}
