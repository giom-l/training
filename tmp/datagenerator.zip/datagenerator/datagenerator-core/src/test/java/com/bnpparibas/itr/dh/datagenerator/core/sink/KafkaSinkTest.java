/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
///**
// * Copyright © BNP PARIBAS - All rights reserved.
// */
//package com.bnpparibas.itr.dh.datagenerator.core.sink;
//
//import ExecutionContext;
//import Config;
//import KafkaProps;
//import ConfParser;
//import com.bnpparibas.itr.dh.datagenerator.core.testUtil.Util;
//import io.confluent.kafka.schemaregistry.ClusterTestHarness;
//import org.apache.avro.Schema;
//import org.apache.avro.generic.GenericRecord;
//import org.junit.After;
//import org.junit.Assert;
//import org.junit.Before;
//import org.junit.Test;
//
//import static com.bnpparibas.itr.dh.datagenerator.core.testUtil.Util.getResource;
//import static org.mockito.Mockito.mock;
//import static org.mockito.Mockito.when;
//
//public class KafkaSinkTest extends ClusterTestHarness {
//
//    private static KafkaSink kafkaSink = new KafkaSink();
//    private static GenericRecord genericRecord;
//    private static ConfParser confParser = new ConfParser();
//    private static Config mockConfig;
//
//    public KafkaSinkTest(){
//        super(1, true);
//    }
//
//    /**
//     * Start Zookeeper and Kafka mini-clusters and initialize the configuration of Kafka
//     */
//    @Before
//    public void setUp() throws Exception {
//        // TODO
//        super.setUp();
//        genericRecord = Util.buildGenericRecord("schemas/schemaKafka.json");
//        Config config = confParser.deserialize(getResource("config/confKafka.json")).get(0);
//
//        mockConfig = mock(Config.class);
//        KafkaProps kafkaPropsMock = mock(KafkaProps.class);
//        when(mockConfig.getKafkaProps()).thenReturn(kafkaPropsMock);
//
//        when(kafkaPropsMock.getBootstrapServers()).thenReturn(this.brokerList);
//        when(kafkaPropsMock.getSchemaRegistry()).thenReturn(this.restApp.restConnect);
//        when(kafkaPropsMock.getNumberOfEvents()).thenReturn(config.getKafkaProps().getNumberOfEvents());
//        when(kafkaPropsMock.getTopicName()).thenReturn(config.getKafkaProps().getTopicName());
//
//        kafkaSink.init(new ExecutionContext(), mockConfig);
//    }
//
//    /**
//     * Test the function 'process' that writes the random generated record into Kafka
//     */
//    @Test
//    public void processTest() {
//        kafkaSink.process(genericRecord);
//        GenericRecord actual = Util.consumeEvents(mockConfig).get(0);
//
//        for(Schema.Field field : genericRecord.getSchema().getFields()){
//            Assert.assertEquals(genericRecord.get(field.name()).toString(), actual.get(field.name()).toString());
//        }
//
//    }
//
//    /**
//     * close the kafka producer
//     */
//    @After
//    public void tearDown() throws Exception {
//        kafkaSink.close();
//    }
//}
