/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.steps;

import com.bnpparibas.itr.dh.datagenerator.core.main.Orchestrator;
import com.bnpparibas.itr.dh.datagenerator.core.model.Config;
import com.bnpparibas.itr.dh.datagenerator.core.model.CsvProps;
import com.bnpparibas.itr.dh.datagenerator.core.testUtil.Util;
import com.bnpparibas.itr.dh.datagenerator.core.utils.Const;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.avro.Schema;
import org.apache.avro.SchemaBuilder;
import org.apache.commons.io.FileUtils;
import org.junit.Assert;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class CsvSteps {
    private List<Config> configs;
    private Config config;
    private Schema schema;
    private CsvProps csvProps;

    @Before
    public void init_config() {
        config = new Config();
        csvProps = new CsvProps();
        configs = new ArrayList<>();
        schema = initSchema();

        config.setCsvProps(csvProps);
        config.setOutput(Const.CSV);
        config.setSchemaAvro(schema);
    }

    private Schema initSchema() {
        schema = SchemaBuilder.builder()
                .record("Event")
                .namespace("com.bnpparibas.itr.dh.datagenerator.events")
                .fields()
                .name("lastName")
                .type(Schema.create(Schema.Type.STRING))
                .noDefault()
                .name("firstName")
                .type(Schema.create(Schema.Type.STRING))
                .noDefault()
                .endRecord();
        return schema;
    }

    @Given("a configuration that specify CSV generation of (\\d+) files and (\\d+) lines")
    public void setOutputConf(int numberoffiles, int numberoflines) {
        csvProps.setNumberOfFiles(numberoffiles);
        csvProps.setNumberOfLines(numberoflines);
    }

    @And("header is set at (true|false)")
    public void setHeader(boolean withHeader) {
        csvProps.setWithHeader(withHeader);
    }

    @And("targetDir is set at (.*)")
    public void setTargetDir(String targetDir) throws IOException {
        csvProps.setTargetDir(targetDir);
        FileUtils.deleteDirectory(new File(targetDir));
    }

    @And("filename is set at ([a-zA-Z0-9_-]+)")
    public void setFileName(String fileName) {
        csvProps.setFileName(fileName);
    }

    @And("withArchive is set at (true|false)")
    public void setWithArchive(boolean withArchive) {
        csvProps.setWithArchive(withArchive);
    }

    @And("archiveName is set at ([a-zA-Z0-9_-]+)")
    public void setArchiveName(String archiveName) {
        csvProps.setArchiveName(archiveName);
    }

    @When("I launch the datagenerator on this config")
    public void launchGeneration() {
        configs.add(config);
        Orchestrator.executeConfigs(configs);
    }

    @Then("the datagenerator should create the targetDir (.*)")
    public void isTargetDirPresent(String targetDir) {
        Path path = Paths.get(targetDir);
        Assert.assertEquals(true, Files.exists(path));
    }

    @And("it should create an archive named ([a-zA-Z0-9_-]+).tar.gz in (.*)")
    public void checkArchive(String archiveName, String targetDir) {
        String archiveNameWithExtension = archiveName + Const.ARCHIVE_EXT;
        Path path = Paths.get(targetDir + "/" + archiveNameWithExtension);
        Assert.assertEquals(true, Files.exists(path));
    }

    @And("([a-zA-Z0-9_-]+).tar.gz in (.*) should contain (\\d+) files named along ([a-zA-Z0-9_-]+)_\\[0-9\\]\\* pattern of (\\d+) lines each")
    public void checkFilesGeneratedInArchive(String archiveName, String targetDir, int expectedNumberOfFiles, String fileName, int expectedNumberOfLines) throws IOException {
        String archiveWithExtensionPath = targetDir + "/" + archiveName + Const.ARCHIVE_EXT;
        String decompressionPath = targetDir + "/" + archiveName;
        Util.decompress(archiveWithExtensionPath, new File(decompressionPath));

        checkFilesGenerated(expectedNumberOfFiles, fileName, expectedNumberOfLines, decompressionPath);
    }

    @And("it should create (\\d+) files named along ([a-zA-Z0-9_-]+)_\\[0-9\\]\\* pattern of (\\d+) lines each in (.*)")
    public void checkFilesGenerated(int expectedNumberOfFiles, String fileName, int expectedNumberOfLines, String targetDir){
        long actualNumberOfFiles = 0L;
        List<String> fileList = getFileListInPath(targetDir);
        actualNumberOfFiles = getNumberOfFilesInPath(fileList);

        Assert.assertEquals(expectedNumberOfFiles, actualNumberOfFiles);

        boolean actualCheckLinesPerFile = isNumberOfLinesPerFileOK(fileList, expectedNumberOfLines);
        Assert.assertEquals(true, actualCheckLinesPerFile);

        boolean actualCheckFilenamePattern = isFileNamePatternOK(fileList, fileName);
        Assert.assertEquals(true, actualCheckFilenamePattern);
    }

    private List<String> getFileListInPath(String targetDir) {
        List<String> fileList = new ArrayList<>();
        try (Stream<Path> files = Files.list(Paths.get(targetDir))) {
            fileList = files
                    .filter(path -> !path.startsWith("."))
                    .map(String::valueOf)
                    .collect(Collectors.toList());
        } catch (IOException ioe) {
            return fileList;
        }
        return fileList;
    }

    private long getNumberOfFilesInPath(List<String> fileList) {
        return fileList.size();
    }

    private boolean isNumberOfLinesPerFileOK(List<String> fileList, int numberOfLinesExpected) {
        boolean result = true;
        for (String file : fileList) {
            try (Stream<String> lines = Files.lines(Paths.get(file), Charset.defaultCharset())) {
                long numberOfLines = lines.count();
                result = (numberOfLines == numberOfLinesExpected);
            } catch (IOException e) {
                result = false;
            }
        }
        return result;
    }

    private boolean isFileNamePatternOK(List<String> fileList, String expectedPattern){
        Predicate<String> filenamePredicate = Pattern
                .compile(expectedPattern)
                .asPredicate();
        List<String> filteredList = fileList
                                        .stream()
                                        .map(String::toLowerCase)
                                        .filter(filenamePredicate)
                                        .collect(Collectors.toList());

        return fileList.size() == filteredList.size();
    }
}
