/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.sink;

import com.bnpparibas.itr.dh.datagenerator.core.context.ExecutionContext;
import com.bnpparibas.itr.dh.datagenerator.core.model.ApiProps;
import com.bnpparibas.itr.dh.datagenerator.core.model.Config;
import com.bnpparibas.itr.dh.datagenerator.core.parser.ConfParser;
import com.bnpparibas.itr.dh.datagenerator.core.testUtil.Util;
import okhttp3.HttpUrl;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import okhttp3.mockwebserver.RecordedRequest;
import org.apache.avro.Schema;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.URISyntaxException;

import static com.bnpparibas.itr.dh.datagenerator.core.testUtil.Util.getResource;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ApiSinkTest {
    private static final Logger logger = LoggerFactory.getLogger(ApiSinkTest.class);
    private static ApiSink apiSink;
    private static Config config;
    private static ConfParser confParser;
    private static Schema schema;
    private static GenericRecord genericRecord;
    private static MockWebServer server;

    @Before
    public void setUp() throws IOException, URISyntaxException {
        Schema schema = Util.getResourceAsSchema("schemas/schemaApiSink.json");
        genericRecord = new GenericData.Record(schema);
        ConfParser confParser = new ConfParser();
        config = confParser.deserialize(getResource("config/confApi.json")).get(0);
        apiSink = new ApiSink();
        // Create a MockWebServer
        server = new MockWebServer();

        MockResponse response = new MockResponse().setResponseCode(200);
        server.enqueue(response);
        // Start the server.
        server.start();

        // Ask the server for its URL. You'll need this to make HTTP requests.
        HttpUrl baseUrl = server.url("/api");

        // mock the configuration to contact a fake http service
        Config mockConfig = mock(Config.class);
        ApiProps apiPropsMock = mock(ApiProps.class);

        /*define where the needed information should come (local variables or real file*/
        when(mockConfig.getApiProps()).thenReturn(apiPropsMock);
        when(apiPropsMock.getUrl()).thenReturn(baseUrl.toString());

        apiSink.init(new ExecutionContext(), mockConfig);
    }

    @Test
    public void api_sink_should_be_able_to_send_record_without_modification() throws IOException, InterruptedException {
        //GIVEN a generic record
        String expectedFirstName = "Abdelli";
        String expectedName = "Sara";
        String expectedCity = "Marrakech";
        String expectedCountry = "Maroc";
        genericRecord.put("nom", expectedFirstName);
        genericRecord.put("prenom", expectedName);
        genericRecord.put("city", expectedCity);
        genericRecord.put("country", expectedCountry);

        //WHEN we call APISink
        apiSink.process(genericRecord);


        //THEN we expect the receiver to get expected record
        RecordedRequest request1 = server.takeRequest();
        assertEquals(genericRecord.toString(), request1.getBody().readUtf8());
    }

    @After
    public void shutdown() throws IOException {
        server.shutdown();
        apiSink.close();
    }
}
