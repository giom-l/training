/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.main;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.Appender;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.internal.verification.AtLeast;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.FileNotFoundException;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.not;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class OrchestratorTest {
    private static final Logger logger = LoggerFactory.getLogger(OrchestratorTest.class);
    private static final int AT_LEAST_ONCE = 1;
    private static final AtLeast AT_LEAST_ONCE_MODE = new AtLeast(AT_LEAST_ONCE);
    private static final String CONFIG_JSON_FILE_PATH = "config/conf.json";
    private static final String CONFIG_ID_JSON_FILE_PATH = "config/conf_id.json";

    @Mock
    private Appender<ILoggingEvent> appender;

    @Captor
    private ArgumentCaptor<ILoggingEvent> captor;

    @Before
    public void setup(){
        Object actualObj = this;
        MockitoAnnotations.initMocks(actualObj);

        ch.qos.logback.classic.Logger rootLogger = (ch.qos.logback.classic.Logger) LoggerFactory.getLogger("ROOT");
        rootLogger.addAppender(appender);

        when(appender.getName()).thenReturn("simple_logger_mock");
        when(appender.isStarted()).thenReturn(true);
    }

    @Test
    public void main_should_not_exit_with_error_log_when_everything_is_fine() {
        // GIVEN
        String[] args = { getClass().getClassLoader().getResource(CONFIG_JSON_FILE_PATH).getFile() };
        // WHEN
        Orchestrator.main(args);
        // THEN no exceptions
        verify(appender, AT_LEAST_ONCE_MODE).doAppend(captor.capture());
        ILoggingEvent value = captor.getValue();
        assertThat(value.getLevel(), not(is(Level.ERROR)));
    }

    @Test
    public void main_with_conf_id_should_not_exit_with_error_log_when_everything_is_fine() {
        // GIVEN
        String[] args = { getClass().getClassLoader().getResource(CONFIG_ID_JSON_FILE_PATH).getFile() };
        // WHEN
        Orchestrator.main(args);
        // THEN no exceptions
        verify(appender, AT_LEAST_ONCE_MODE).doAppend(captor.capture());
        ILoggingEvent value = captor.getValue();
        assertThat(value.getLevel(), not(is(Level.ERROR)));
    }


    @Test
    public void main_should_log_FileNotFoundException_when_file_does_not_exists() {
        // GIVEN
        String[] args = { "" };
        // WHEN
        Orchestrator.main(args);
        // THEN no exceptions
        verify(appender).doAppend(captor.capture());
        ILoggingEvent value = captor.getValue();
        assertThat(value.getThrowableProxy().getClassName(), is(FileNotFoundException.class.getName()));
    }

    @Test
    public void main_should_log_ArrayIndexOutOfBoundsException_args_no_user_args() {
        // GIVEN
        String[] args = { };
        // WHEN
        Orchestrator.main(args);
        // THEN no exceptions
        verify(appender).doAppend(captor.capture());
        ILoggingEvent value = captor.getValue();
        assertThat(value.getThrowableProxy().getClassName(), is(ArrayIndexOutOfBoundsException.class.getName()));
    }
}
