/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.sink;

import com.bnpparibas.itr.dh.datagenerator.core.context.ExecutionContext;
import com.bnpparibas.itr.dh.datagenerator.core.model.Config;
import com.bnpparibas.itr.dh.datagenerator.core.utils.DDACompliance;
import com.bnpparibas.itr.dh.datagenerator.core.utils.Const;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.opencsv.CSVWriter;
import net.logstash.logback.marker.LogstashMarker;
import org.apache.avro.Schema;
import org.apache.avro.generic.GenericRecord;
import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Map;
import java.util.stream.Collectors;

public class CsvSink implements Sink {
    private static final Logger logger = LoggerFactory.getLogger(CsvSink.class);

    private CSVWriter csvWriter;
    private ObjectMapper mapper;
    private Config config;
    private File directory;
    private File tmpDirectory;
    private boolean isCreated;
    private LogstashMarker correlationIdsMatcher;
    private String correlationId;

    /**
     * Initiate the CsvSink with a configuration file
     *
     * @param config configuration about the data
     */
    @Override
    public void init(ExecutionContext context, Config config) {
        this.directory = new File(config.getCsvProps().getTargetDir());
        this.tmpDirectory = new File(config.getCsvProps().getTargetDir() + Const.TMP_DIR);
        this.isCreated = directory.mkdirs();
        this.mapper = new ObjectMapper();
        this.config = config;
        this.correlationIdsMatcher = DDACompliance.getCorrelationIdsMarkersFromContext(context);
        this.correlationId = context.getCorrelationId();
    }

    /**
     * TMP Directory getter
     *
     * @return the directory where the file was created
     */
    public File getTmpDirectory() {
        return tmpDirectory;
    }

    /**
     * Directory getter
     *
     * @return the directory where the file was created
     */
    public File getDirectory() {
        return directory;
    }

    /**
     * This function creates the fileName
     *
     * @param fileNumber the number of the file. It will be concatenated with the fileName
     * @return the file name
     */
    public String getFilePath(int fileNumber) {
        return this.getTmpDirectory().getAbsolutePath() + File.separator + config.getCsvProps().getFileName() + "_" +correlationId + "_" + fileNumber + Const.FILE_EXT;
    }

    /**
     * This function creates the file that it will be used to create the random data
     *
     * @param fileNumber the number of the file.
     * @throws IOException
     */
    public void createFile(int fileNumber) throws IOException {
        if ((isCreated || directory.exists()) && (tmpDirectory.mkdirs() || tmpDirectory.exists())) {
            String filePath = getFilePath(fileNumber);
            Writer writer = Files.newBufferedWriter(Paths.get(filePath));
            this.csvWriter = new CSVWriter(writer,
                    config.getCsvProps().getCsvOptions().getSeparator(),
                    config.getCsvProps().getCsvOptions().getQuoteChar(),
                    config.getCsvProps().getCsvOptions().getEscapeChar(),
                    config.getCsvProps().getCsvOptions().getLineEnd());
            logger.debug(correlationIdsMatcher, "Generating file {}", filePath);
        }
    }

    /**
     * This function writes the header in the file already created
     *
     * @param record the record where to get the header
     * @throws IOException
     */
    public void writeHeader(GenericRecord record) throws IOException {
        Map<String, String> lineMap = mapper.readValue(record.toString(), new TypeReference<Map<String, String>>() {
        });
        csvWriter.writeNext(lineMap.keySet().stream().toArray(String[]::new));
    }

    /**
     * This function writes the header in the file already created
     *
     * @param record the record where to get the header
     * @throws IOException
     */
    public void writeHeader(Schema schema) throws IOException {
        String[] fieldsNames = schema.getFields().stream()
                .map(Schema.Field::name)
                .collect(Collectors.toList())
                .toArray(new String[schema.getFields().size()]);
        csvWriter.writeNext(fieldsNames);
    }

    /**
     * This function writes data in the file already created
     *
     * @param record the record where to get the data
     * @throws IOException
     */
    @Override
    public void process(GenericRecord record)throws IOException{
        Map<String, Object> lineMap = mapper.readValue(record.toString(), new TypeReference<Map<String, Object>>() {});
        csvWriter.writeNext(lineMap.values().stream().map(Object::toString).toArray(String[]::new));
    }

    public void moveFilesToTarget() throws IOException {
        logger.debug(correlationIdsMatcher,"Moving Csv Files from {} to {}", tmpDirectory.getAbsolutePath(), directory.getAbsolutePath());
        for (File file : tmpDirectory.listFiles()) {
            File newFile = new File(directory, file.getName());
            if (newFile.exists()) {
                String newFileAbsolutePath = newFile.getAbsolutePath();
                if(newFile.delete()){
                    logger.debug(correlationIdsMatcher,"Temporary file {} was deleted", file.getAbsolutePath());
                }else{
                    logger.warn(correlationIdsMatcher,"Unable to delete file {}", newFileAbsolutePath);
                }
            }
            FileUtils.moveFile(file, newFile);
        }
            FileUtils.deleteDirectory(tmpDirectory);
        }

        /**
         * Close the Csv writer
         *
         * @throws IOException
         */
        @Override
        public void close () throws IOException {
            if (csvWriter != null) {
                csvWriter.close();
            }
        }
    }