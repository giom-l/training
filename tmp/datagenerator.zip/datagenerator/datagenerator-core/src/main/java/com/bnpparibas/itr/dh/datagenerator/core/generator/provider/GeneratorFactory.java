/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.generator.provider;

import com.bnpparibas.itr.dh.datagenerator.core.context.ExecutionContext;
import com.bnpparibas.itr.dh.datagenerator.core.utils.Const;
import org.apache.avro.Schema;
import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.Map;

public class GeneratorFactory {
    private Map<String, Generator> generators = new HashMap<>();

    private RandomStringsGenerator randomStringGenerator;
    private DictionaryGenerator dictionaryGenerator;

    public GeneratorFactory(ExecutionContext context){
        initPeopleLastNameGenerator(context);
        initPeopleFirstNameGenerator(context);
        initEmailGenerator(context);
        initNaughtyGenerator(context);
        initPhoneGenerator(context);
        initCorrelationIdGenerator(context);
        initDictionaryGenerator(context);
    }

    private void initPeopleLastNameGenerator(ExecutionContext context){
        Map<String, String> props = new HashMap<>();
        Generator peopleLastNameGenerator = new PeopleNameGenerator();
        props.put(Const.TYPE, Const.LAST);
        props.put(Const.GENDER, Const.ALL);
        peopleLastNameGenerator.init(context, props);
        generators.put(Const.LAST_NAME.toLowerCase(), peopleLastNameGenerator);
    }

    private void initPeopleFirstNameGenerator(ExecutionContext context){
        Map<String, String> props = new HashMap<>();
        Generator peopleFirstNameGenerator = new PeopleNameGenerator();
        props.put(Const.TYPE, Const.FIRST);
        props.put(Const.GENDER, Const.ALL);
        peopleFirstNameGenerator.init(context, props);
        generators.put(Const.FIRST_NAME.toLowerCase(), peopleFirstNameGenerator);
    }

    private void initEmailGenerator(ExecutionContext context){
        Generator emailGenerator = new EmailGenerator();
        emailGenerator.init(context, null);
        generators.put(Const.EMAIL.toLowerCase(), emailGenerator);
    }

    private void initPhoneGenerator(ExecutionContext context){
        Generator phoneGenerator = new PhoneGenerator();
        phoneGenerator.init(context, null);
        generators.put(Const.PHONE.toLowerCase(), phoneGenerator);
    }

    private void initNaughtyGenerator(ExecutionContext context){
        randomStringGenerator = new RandomStringsGenerator();
        randomStringGenerator.init(context, null);
    }

    private void initDictionaryGenerator(ExecutionContext context){
        dictionaryGenerator = new DictionaryGenerator();
        dictionaryGenerator.init(context, null);
    }

    private void initCorrelationIdGenerator(ExecutionContext context){
        Generator correlationIdGenerator = new CorrelationIdGenerator();
        correlationIdGenerator.init(context, null);
        generators.put(Const.CORRELATIONID.toLowerCase(), correlationIdGenerator );
    }

    public String generateField(Schema.Field field) {
        String fieldDoc = field.doc();
        String fieldName = field.name();
        if (fieldDoc != null) {
            Generator generator = generators.get(fieldDoc.toLowerCase());
            if(generator != null){
                return generator.nextValue(fieldDoc, fieldName);
            }else{
                return dictionaryGenerator.nextValue(fieldDoc, fieldName);
            }
        } else return dictionaryGenerator.nextValue(StringUtils.EMPTY, fieldName);
    }
}
