/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.generators.primitives;

import java.util.Optional;

public interface PrimitiveTypeGenerator {
    StaticEmpty RANDOM_EMPTY = new StaticEmpty();
    Optional<Object> generate();
}
