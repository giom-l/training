/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.generator.provider;

import com.bnpparibas.itr.dh.datagenerator.core.context.ExecutionContext;
import com.fasterxml.uuid.Generators;
import com.fasterxml.uuid.impl.TimeBasedGenerator;

import java.util.Map;

public class CorrelationIdGenerator implements Generator {

    private static final TimeBasedGenerator TIME_BASED_GENERATOR = Generators.timeBasedGenerator();
    private static final String PARENT_CORRELATION_ID = "parentCorrelationId";
    private static final String ROOT_CORRELATION_ID = "rootCorrelationId";

    private String parentCorrelationId;
    private String rootCorrelationId;

    @Override
    public void init(ExecutionContext context, Map<String, String> props) {
        parentCorrelationId = context.getCorrelationId();
        rootCorrelationId = context.getRootCorrelationId();
    }

    @Override
    public String nextValue(String doc, String fieldName) {
        switch (fieldName){
            case PARENT_CORRELATION_ID :
                return parentCorrelationId != null ? parentCorrelationId : TIME_BASED_GENERATOR.generate().toString();
            case ROOT_CORRELATION_ID :
                return rootCorrelationId != null ? rootCorrelationId : TIME_BASED_GENERATOR.generate().toString();
            default :
                return TIME_BASED_GENERATOR.generate().toString();
        }
    }
}
