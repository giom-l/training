/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CsvProps implements SinkProps{

    @Getter
    @Setter
    private String targetDir;
    @Getter
    @Setter
    private String fileName;
    @Getter
    @Setter
    private String archiveName;
    @Getter
    @Setter
    private int numberOfLines;
    @Getter
    @Setter
    private int numberOfFiles;
    @Setter
    private CsvOptions csvOptions;
    @Getter
    @Setter
    private boolean withHeader;
    @Getter
    @Setter
    private boolean withArchive;

    public CsvOptions getCsvOptions() {
        if (csvOptions == null)
            csvOptions = new CsvOptions();
        return csvOptions;
    }

//    public boolean isWithHeader() {
//        return withHeader;
//    }
//
//    public boolean isWithArchive() {
//        return withArchive;
//    }

    @Override
    public int getNumberOfEvents() {
        return this.getNumberOfFiles() * this.getNumberOfLines();
    }
}
