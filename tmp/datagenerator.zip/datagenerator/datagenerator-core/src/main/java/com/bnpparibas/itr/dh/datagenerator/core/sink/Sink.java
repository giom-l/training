/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.sink;

import com.bnpparibas.itr.dh.datagenerator.core.context.ExecutionContext;
import com.bnpparibas.itr.dh.datagenerator.core.model.Config;
import org.apache.avro.generic.GenericRecord;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;

public interface Sink {

    void init(ExecutionContext context, Config config) throws IOException, CertificateException, NoSuchAlgorithmException, KeyStoreException, KeyManagementException;

    void process(GenericRecord record) throws IOException;

    void close() throws IOException;

}
