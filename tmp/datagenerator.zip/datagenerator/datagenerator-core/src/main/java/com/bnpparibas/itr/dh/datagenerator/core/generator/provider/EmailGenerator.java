/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.generator.provider;

import com.bnpparibas.itr.dh.datagenerator.core.context.ExecutionContext;
import com.bnpparibas.itr.dh.datagenerator.core.utils.Const;

import java.util.HashMap;
import java.util.Map;

public class EmailGenerator implements Generator {

    private PeopleNameGenerator lastNameProvider = new PeopleNameGenerator();
    private PeopleNameGenerator firstNameProvider = new PeopleNameGenerator();

    @Override
    public void init(ExecutionContext context, Map<String, String> props) {

        Map<String, String> lastNameProps = new HashMap<>();
        Map<String, String> firstNameProps = new HashMap<>();

        lastNameProps.put(Const.TYPE, Const.LAST);
        lastNameProps.put(Const.GENDER, Const.ALL);
        firstNameProps.put(Const.TYPE, Const.FIRST);
        firstNameProps.put(Const.GENDER, Const.ALL);

        lastNameProvider.init(context, lastNameProps);
        firstNameProvider.init(context, firstNameProps);
    }

    @Override
    public String nextValue(String doc, String fieldName) {
        return firstNameProvider.nextValue(doc, fieldName) + "." + lastNameProvider.nextValue(doc, fieldName) + "@" + Const.DOMAIN;

    }
}
