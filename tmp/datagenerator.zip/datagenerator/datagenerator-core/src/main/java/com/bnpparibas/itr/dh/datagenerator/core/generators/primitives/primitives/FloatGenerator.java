/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.generators.primitives.primitives;

import com.bnpparibas.itr.dh.datagenerator.core.context.ExecutionContext;
import com.bnpparibas.itr.dh.datagenerator.core.generators.primitives.PrimitiveTypeGenerator;
import com.bnpparibas.itr.dh.datagenerator.core.utils.Const;
import org.apache.avro.Schema;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Optional;

public class FloatGenerator implements PrimitiveTypeGenerator {
    private float currentValue = 0f;
    private ExecutionContext context;
    private Schema.Field field;
    private Boolean unique;

    public FloatGenerator(ExecutionContext context, Schema.Field field){
        this.context = context;
        this.field = field;
        unique = this.field.aliases().stream().map(String::toLowerCase).anyMatch(Const.UNIQUE_VALUE::equals);
    }

    @Override
    public Optional<Object> generate() {
        if(unique){
            return Optional.of(currentValue++);
        }
        try{
            float value = SecureRandom.getInstanceStrong().nextFloat();
            return Optional.of(value);
        }catch(NoSuchAlgorithmException e){
            return Optional.empty();
        }
    }
}
