/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.generator.provider;

import com.bnpparibas.itr.dh.datagenerator.core.context.ExecutionContext;
import com.bnpparibas.itr.dh.datagenerator.core.model.UserDictionary;
import com.bnpparibas.itr.dh.datagenerator.core.utils.Const;
import com.bnpparibas.itr.dh.datagenerator.core.utils.DDACompliance;
import net.logstash.logback.marker.LogstashMarker;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.security.SecureRandom;
import java.util.Map;
import java.util.List;
import java.util.HashMap;
import java.util.Random;
import java.util.ArrayList;
import java.util.Arrays;

public class DictionaryGenerator implements Generator {
    private static final Logger LOG = LoggerFactory.getLogger(DictionaryGenerator.class);
    private static final String DICO_DIR_PATH = "dictionary";
    private static final String USER_DICTIONARY_NOT_FOUND = "User dictionary not found for (field name: {}, doc: {})";
    private static final String USER_DICTIONARY_FOUND = "User dictionary found for (field name: {}, doc: {})";
    private static final String DICTIONARY_FILE_FOUND = "Dictionary file found for (field name: {}, doc: {})";
    private static final String DICTIONARY_FILE_NOT_FOUND = "Dictionary file not found for (field name: {}, doc: {})";
    private static String staticDicoPath;
    private static LogstashMarker correlationIdsMatcher;

    private Map<String, UserDictionary> userDictionariesCache = new HashMap<>();
    private Map<String, List<String>> staticDictionariesCache = new HashMap<>();
    private RandomStringsGenerator randomStringsGenerator = new RandomStringsGenerator();


    private static final String DICTIONARY_DIRECTORY_NOT_FOUND = "dictionary directory not found";

    static {
        try {
            staticDicoPath = DictionaryGenerator.class.getClassLoader().getResource(DICO_DIR_PATH).getPath();
        } catch (Throwable th) {
            LOG.warn(correlationIdsMatcher,DICTIONARY_DIRECTORY_NOT_FOUND, th);
        }
    }

    private List<UserDictionary> userDictionaries;
    private Random random;

    @Override
    public void init(ExecutionContext context, Map<String, String> props) {
        userDictionaries = (List<UserDictionary>) context.getPropertyValue(Const.USER_DICO);
        random = (Random) context.getPropertyValue(Const.RANDOM_PROPERTY);
        randomStringsGenerator.init(context, props);
        initLogging(context);
        if (userDictionaries == null) {
            userDictionaries = new ArrayList<>();
        }
        if (random == null) {
            random = new SecureRandom();
        }
    }

    private static synchronized void initLogging(ExecutionContext context){
        correlationIdsMatcher = DDACompliance.getCorrelationIdsMarkersFromContext(context);
    }

    @Override
    public String nextValue(String doc, String fieldName) {
        doc = doc.toLowerCase();
        fieldName = fieldName.toLowerCase();
        String result = getValueFromUserDictionary(doc, fieldName);
        if (result == null) {
            result = getValueFromStaticDictionary(doc, fieldName);
        }
        if(result == null){
            result = randomStringsGenerator.nextValue(doc, fieldName);
        }
        return result;
    }

    private String getValueFromStaticDictionary(String doc, String fieldName) {
        String staticDicoKey = getUserDicoKey(doc, fieldName);
        List<String> words = staticDictionariesCache.get(staticDicoKey);
        if (words == null) {
            File dicoFile = getStaticDicoFile(doc, fieldName);
            words = getWordsFromDicoFile(doc, fieldName, dicoFile);
            cacheStaticDico(doc, fieldName, words);
        }
        return getValueFromStaticWords(words);
    }

    private List<String> getWordsFromDicoFile(String doc, String fieldName, File dicoFile) {
        List<String> words = new ArrayList<>();
        if (dicoFile.exists()) {
            words = getWordsFromDicoFile(dicoFile);
            LOG.info(correlationIdsMatcher,DICTIONARY_FILE_FOUND, fieldName, doc);
        } else {
            LOG.warn(correlationIdsMatcher,DICTIONARY_FILE_NOT_FOUND, fieldName, doc);
        }
        return words;
    }

    private File getStaticDicoFile(String doc, String fieldName) {
        File dicoFile = new File(staticDicoPath, doc);
        if (!dicoFile.exists() || StringUtils.isEmpty(doc)) {
            dicoFile = new File(staticDicoPath, fieldName);
        }
        return dicoFile;
    }

    private List<String> getWordsFromDicoFile(File dicoFile) {
        List<String> result = new ArrayList<>();
        try {
            List<String> lines = FileUtils.readLines(dicoFile, Charset.defaultCharset());
            result = lines.stream().map(line -> line.split(Const.COMMA)).map(Arrays::asList).reduce((firstList, secondList) -> {
                firstList = new ArrayList<>(firstList);
                firstList.addAll(secondList);
                return firstList;
            }).orElseGet(ArrayList::new);
        } catch (IOException ex) {
            LOG.error(correlationIdsMatcher,"Error reading dictionary file ({}) : {}", dicoFile.getAbsolutePath(), ex.getMessage());
        }
        return result;
    }


    private String getValueFromUserDictionary(String doc, String fieldName) {
        UserDictionary userDico = getUserDictionary(doc, fieldName);
        return getValueFromDico(userDico);
    }

    private UserDictionary getUserDictionary(String doc, String fieldName) {
        UserDictionary userDico = getUserDictionaryFromCache(doc, fieldName);
        if (userDico == null) {
            userDico = userDictionaries.stream()
                    .filter(userDictionary -> doc.equals(userDictionary.getName()) || fieldName.equals(userDictionary.getName()))
                    .findFirst().orElseGet(UserDictionary::new);
            cacheUserDico(doc, fieldName, userDico);
            if (StringUtils.isEmpty(userDico.getName())) {
                LOG.warn(correlationIdsMatcher,USER_DICTIONARY_NOT_FOUND, fieldName, doc);
            }else{
                LOG.info(correlationIdsMatcher,USER_DICTIONARY_FOUND, fieldName, doc);
            }
        }
        return userDico;
    }

    private UserDictionary getUserDictionaryFromCache(String doc, String fieldName) {
        String userDicoKey = getUserDicoKey(doc, fieldName);
        return userDictionariesCache.get(userDicoKey);
    }

    private String getValueFromDico(UserDictionary userDico) {
        List<Object> values = userDico.getValues();
        int valuesSize = values.size();
        if (valuesSize > 0) {
            int valueIndex = random.nextInt(valuesSize);
            return values.get(valueIndex).toString();
        }
        return null;
    }

    private String getValueFromStaticWords(List<String> words) {
        int wordsLength = words.size();
        if (wordsLength > 0) {
            int valueIndex = random.nextInt(wordsLength);
            return words.get(valueIndex);
        }
        return null;
    }

    private void cacheStaticDico(String doc, String fieldName, List<String> words) {
        String staticDicoKey = getUserDicoKey(doc, fieldName);
        staticDictionariesCache.put(staticDicoKey, words);
    }

    private void cacheUserDico(String doc, String fieldName, UserDictionary userDico) {
        String userDicoKey = getUserDicoKey(doc, fieldName);
        userDictionariesCache.put(userDicoKey, userDico);
    }

    private String getUserDicoKey(String doc, String fieldName) {
        return doc + "_" + fieldName;
    }
}
