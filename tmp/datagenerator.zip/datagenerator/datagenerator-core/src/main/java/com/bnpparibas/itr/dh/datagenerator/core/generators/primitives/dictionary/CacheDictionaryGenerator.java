/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.generators.primitives.dictionary;

import com.bnpparibas.itr.dh.datagenerator.core.context.ExecutionContext;
import com.bnpparibas.itr.dh.datagenerator.core.utils.Const;
import com.bnpparibas.itr.dh.datagenerator.core.utils.DDACompliance;
import net.logstash.logback.marker.LogstashMarker;
import org.apache.avro.Schema;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Collections;
import java.util.Random;


public class CacheDictionaryGenerator {
    private static final Logger LOG = LoggerFactory.getLogger(CacheDictionaryGenerator.class);
    private static LogstashMarker correlationIdsMatcher;
    private ExecutionContext context;
    private Schema.Field field;
    private Boolean unique;
    private List<Object> columnCache;
    private List<Object> uniqueColumnCache;

    public CacheDictionaryGenerator(ExecutionContext context, Schema.Field field){
        this.context = context;
        this.field = field;
        this.unique = field.aliases().stream().map(String::toLowerCase).anyMatch(Const.UNIQUE_VALUE::equals);
        initColumnCache();
        initLogging(context);
    }

    private static synchronized void initLogging(ExecutionContext context){
        correlationIdsMatcher = DDACompliance.getCorrelationIdsMarkersFromContext(context);
    }

    private void initColumnCache() {
        columnCache = getFieldColumnCache();
        Map<Schema.Field, List<Object>> columnsCache = context.getColumnsCache();
        columnsCache.put(field, columnCache);
        uniqueColumnCache = new ArrayList<>(columnCache);
    }

    public Optional<Object> generate() {
        Optional<Object> result = generateIfCacheSealed();
        return result;
    }

    private Optional<Object> generateIfCacheSealed() {
        Optional<Object> result = Optional.empty();
        if(!(columnCache instanceof ArrayList)){
            if(unique){
                result = uniqueValue();
            }else{
                result = randomValue();
            }
        }
        return result;
    }

    private Optional<Object> randomValue() {
        Optional<Object> result;
        try{
            int valueIndex = SecureRandom.getInstanceStrong().nextInt(columnCache.size());
            result = Optional.of(columnCache.get(valueIndex));
        }catch(NoSuchAlgorithmException e){
            LOG.warn(correlationIdsMatcher,e.getMessage(), e);
            result = Optional.empty();
        }
        return result;
    }

    private Optional<Object> uniqueValue() {
        Optional<Object> result;
        try{
            int valueIndex = SecureRandom.getInstanceStrong().nextInt(uniqueColumnCache.size());
            result = Optional.of(uniqueColumnCache.remove(valueIndex));
        }catch(NoSuchAlgorithmException e){
            LOG.warn(correlationIdsMatcher,e.getMessage(), e);
            result = Optional.empty();
        }
        return result;
    }

    public void cacheValue(Object value){
        if(columnCache instanceof ArrayList){
            columnCache.add(value);
        }
    }

    public void sealCache(){
        if(columnCache instanceof ArrayList) {
            Map<Schema.Field, List<Object>> columnsCache = context.getColumnsCache();
            columnsCache.put(field, Collections.unmodifiableList(columnCache));
        }
    }

    private List<Object> getFieldColumnCache() {
        Map<Schema.Field, List<Object>> columnsCache = context.getColumnsCache();
        return columnsCache.entrySet().stream()
                .filter(entry -> field.aliases().contains(entry.getKey().name()))
                .filter(entry -> entry.getKey().schema().getType().equals(field.schema().getType()))
                .map(Map.Entry::getValue).findFirst().orElse(new ArrayList<>());
    }

    private Optional<Object> getValueFromCache() {
        Optional<Object> result = Optional.empty();
        if (CollectionUtils.isNotEmpty(columnCache)) {
            try {
                Random random = SecureRandom.getInstanceStrong();
                int size = columnCache.size();
                int indexValue = random.nextInt(size);
                result = Optional.of(columnCache.get(indexValue));
            } catch (NoSuchAlgorithmException e) {
                LOG.warn(correlationIdsMatcher,e.getMessage(), e);
            }
        }
        return result;
    }
}
