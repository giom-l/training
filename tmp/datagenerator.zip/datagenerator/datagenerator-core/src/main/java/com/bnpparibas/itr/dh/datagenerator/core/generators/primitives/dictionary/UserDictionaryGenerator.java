/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.generators.primitives.dictionary;

import com.bnpparibas.itr.dh.datagenerator.core.context.ExecutionContext;
import com.bnpparibas.itr.dh.datagenerator.core.model.UserDictionary;
import com.bnpparibas.itr.dh.datagenerator.core.utils.Const;
import com.bnpparibas.itr.dh.datagenerator.core.utils.DDACompliance;
import net.logstash.logback.marker.LogstashMarker;
import org.apache.avro.Schema;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.charset.Charset;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class UserDictionaryGenerator {
    private static final Logger LOG = LoggerFactory.getLogger(UserDictionaryGenerator.class);
    private static LogstashMarker correlationIdsMatcher;
    private static final int FIRST_ELEMENT = 0;
    private static final String DICTIONARY_DIR = "dictionary";

    private List<Object> dictionaryValues;
    private ExecutionContext context;
    private Schema.Field field;
    private Boolean uniqueField;

    public UserDictionaryGenerator(ExecutionContext context, Schema.Field field) {
        this.context = context;
        this.field = field;
        initLogging(context);
        initUserDictionary();
    }

    private static synchronized void initLogging(ExecutionContext context){
        correlationIdsMatcher = DDACompliance.getCorrelationIdsMarkersFromContext(context);
    }

    public Optional<Object> generate() {
        Optional<Object> result = Optional.empty();
        if (CollectionUtils.isNotEmpty(dictionaryValues)) {
            int size = dictionaryValues.size();
            try {
                Random random = SecureRandom.getInstanceStrong();
                int valueIndex = random.nextInt(size);
                result = Optional.of(getSingleValue(valueIndex));
            } catch (NoSuchAlgorithmException e) {
                LOG.warn(correlationIdsMatcher,e.getMessage(), e);
                result = Optional.of(getSingleValue(FIRST_ELEMENT));
            }
        }
        return result;
    }

    private void initUserDictionary() {
        List<UserDictionary> userDictionaries = this.context.getConfig().getUserDictionaries();
        if(userDictionaries != null){
            dictionaryValues = userDictionaries.stream()
                    .filter(this::isFieldUserDictionary)
                    .map(userDictionary -> new ArrayList<>(userDictionary.getValues()))
                    .findFirst().orElse(new ArrayList<>());
        }
        if (CollectionUtils.isEmpty(dictionaryValues)) {
            if (LOG.isDebugEnabled()) {
                LOG.debug(correlationIdsMatcher, "Empty user dictionary for field {}", field.name());
            }
            dictionaryValues = getStaticDictionary();
        }
        if (CollectionUtils.isEmpty(dictionaryValues)) {
            if (LOG.isDebugEnabled()) {
                LOG.debug(correlationIdsMatcher, "Empty static dictionary for field {}", field.name());
            }
        }
        uniqueField = this.field.aliases().stream().map(String::toLowerCase).anyMatch(Const.UNIQUE_VALUE::equals);
    }

    private List<Object> getStaticDictionary() {
        for (String alias : field.aliases()) {
            try{
                URL dicResource = getClass().getClassLoader().getResource(DICTIONARY_DIR);
                if(dicResource != null){
                    String dictionaryDir = dicResource.getPath();
                    File[] files = new File(dictionaryDir).listFiles();
                    if (files != null) {
                        return Arrays.stream(files)
                                .filter(file -> file.getName().equals(alias))
                                .findFirst().map(this::fileToValues)
                                .orElse(new ArrayList<>());
                    }
                }
            }catch(Throwable throwable){
                LOG.warn(correlationIdsMatcher,throwable.getMessage(), throwable);
            }
        }
        return new ArrayList<>();
    }

    private List<Object> fileToValues(File file) {
        List<Object> result = new ArrayList<>();
        try {
            result = FileUtils.readLines(file, Charset.defaultCharset())
                    .stream()
                    .map(line -> Arrays.asList(line.split(Const.COMMA)))
                    .flatMap(Collection::stream)
                    .collect(Collectors.toList());
        } catch (IOException e) {
            LOG.error(correlationIdsMatcher,e.getMessage(), e);
        }
        return result;
    }

    private Boolean isFieldUserDictionary(UserDictionary userDictionary) {
        Set<String> fieldAliases = field.aliases();
        return fieldAliases.stream()
                .filter(((Predicate<String>) Const.UNIQUE_VALUE::equals).negate())
                .anyMatch(userDictionary.getName()::equals);
    }

    private Object getSingleValue(int index) {
        if (uniqueField) {
            return dictionaryValues.remove(index);
        } else {
            return dictionaryValues.get(index);
        }
    }
}
