/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.generator.provider;

import com.bnpparibas.itr.dh.datagenerator.core.context.ExecutionContext;
import com.bnpparibas.itr.dh.datagenerator.core.utils.Const;

import java.security.SecureRandom;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class PhoneGenerator implements Generator {
    private static final List<Integer> PREFIX = Arrays.asList(6, 7);
    private SecureRandom secureRandom = new SecureRandom();

    @Override
    public void init(ExecutionContext context, Map<String, String> props) {

    }

    @Override
    public String nextValue(String doc, String fieldName) {
        return String.format(Const.PHONE_FORMAT, PREFIX.get(secureRandom.nextInt(PREFIX.size())),
                (int) Math.floor(Const.PHONE_CONST * secureRandom.nextDouble()));
    }
}
