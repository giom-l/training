/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.processors;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import org.apache.avro.Schema;

import java.io.IOException;

public class ConfigJsonSerializer extends JsonSerializer<Schema> {

    protected ConfigJsonSerializer() {
    }

    @Override
    public void serialize(Schema schema, JsonGenerator jsonGenerator, SerializerProvider serializerProvider) throws IOException {
        try {
            // remove schema from JSON as it has already been validated during conf parsing at launch
            jsonGenerator.writeObject(null);
        } catch (Throwable ex) {
            throw new IOException(ex);
        }
    }
}
