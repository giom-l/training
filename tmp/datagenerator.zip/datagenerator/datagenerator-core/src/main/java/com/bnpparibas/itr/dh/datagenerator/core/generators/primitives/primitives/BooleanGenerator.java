/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.generators.primitives.primitives;

import com.bnpparibas.itr.dh.datagenerator.core.context.ExecutionContext;
import com.bnpparibas.itr.dh.datagenerator.core.generators.primitives.PrimitiveTypeGenerator;
import com.bnpparibas.itr.dh.datagenerator.core.utils.DDACompliance;
import net.logstash.logback.marker.LogstashMarker;
import org.apache.avro.Schema;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Optional;
import java.util.Random;

public class BooleanGenerator implements PrimitiveTypeGenerator {
    private static final Logger LOG = LoggerFactory.getLogger(BooleanGenerator.class);
    private static LogstashMarker correlationIdsMatcher;
    private ExecutionContext context;
    private Schema.Field field;

    public BooleanGenerator(ExecutionContext context, Schema.Field field){
        this.context = context;
        this.field = field;
        initLogging(context);
    }

    private static synchronized void initLogging(ExecutionContext context){
        correlationIdsMatcher = DDACompliance.getCorrelationIdsMarkersFromContext(context);
    }

    @Override
    public Optional<Object> generate() {
        Optional<Object> result = Optional.empty();
        try {
            Random random = SecureRandom.getInstanceStrong();
            result = Optional.of(random.nextBoolean());
        } catch (NoSuchAlgorithmException e) {
            LOG.warn(correlationIdsMatcher,e.getMessage(), e);
        }
        return result;
    }
}
