/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
public class KafkaSecurityProps {

    @Getter
    @Setter
    private String sslTrustStoreLocation;
    @Getter
    @Setter
    private String sslKeyStoreLocation;
    @Getter
    @Setter
    private String sslTrustStorePassword;
    @Getter
    @Setter
    private String sslKeyStorePassword;
    @Getter
    @Setter
    private String sslKeyPassword;
    @Getter
    @Setter
    private String sslSRKeyStoreLocation;
    @Getter
    @Setter
    private String sslSRKeyStorePassword;
}
