/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.generators.complexes;

import com.bnpparibas.itr.dh.datagenerator.core.context.ExecutionContext;
import org.apache.avro.Schema;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class RecordGenerator {
    public Map<String, Object> generate(ExecutionContext context, Schema.Field field, int size) {
        List<Schema.Field> fields = field.schema().getFields();
        return fields.stream()
                .collect(Collectors.toMap(
                        Schema.Field::name,
                        mappedField -> SchemaGenerator.generateField(context, mappedField, size)
                ));
    }
}
