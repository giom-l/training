/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.sink;

import com.bnpparibas.itr.dh.datagenerator.core.context.ExecutionContext;
import com.bnpparibas.itr.dh.datagenerator.core.model.Config;
import com.bnpparibas.itr.dh.datagenerator.core.utils.Const;
import com.bnpparibas.itr.dh.datagenerator.core.utils.DDACompliance;
import com.datastax.driver.core.Metadata;
import com.datastax.driver.core.RemoteEndpointAwareJdkSSLOptions;
import com.datastax.driver.core.Session;
import com.datastax.driver.dse.DseCluster;
import com.fasterxml.jackson.databind.ObjectMapper;
import net.logstash.logback.marker.LogstashMarker;
import org.apache.avro.generic.GenericRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import tech.allegro.schema.json2avro.converter.JsonAvroConverter;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;

public class CassandraSink implements Sink {

    private static final Logger LOG = LoggerFactory.getLogger(CassandraSink.class);
    private LogstashMarker correlationIdsMatcher;

    private DseCluster dseCluster;
    private Session session;
    private Config config;

    private JsonAvroConverter converter;

    private String insertStatement = "insert into %s JSON ' %s ' ;";


    @Override
    public void init(ExecutionContext context, Config config) throws IOException, CertificateException, NoSuchAlgorithmException, KeyStoreException, KeyManagementException {

        this.correlationIdsMatcher = DDACompliance.getCorrelationIdsMarkersFromContext(context);
        this.config = config;
        this.converter = new JsonAvroConverter();

        LOG.info(correlationIdsMatcher,"Initializing the Cassandra configuration ...");

        /*Connect to Cassandra Cluster specified by provided connect point address, port number, username, password
         * and ssl options*/
        DseCluster.Builder builder;

        if (config.getCassandraProps().isWithSSL()){
            LOG.info(correlationIdsMatcher,"Connecting to SSL secure cluster");
            LOG.debug(correlationIdsMatcher,"Connecting to SSL secure cluster @ contactPoints {} on port {} with user {} ", config.getCassandraProps().getContactPoints(), config.getCassandraProps().getPort(), config.getCassandraProps().getUserName());
            builder = DseCluster
                    .builder()
                    .addContactPoint(config.getCassandraProps().getContactPoints())
                    .withPort(config.getCassandraProps().getPort())
                    .withCredentials(config.getCassandraProps().getUserName(), config.getCassandraProps().getPassword())
                    .withSSL(getSslOptions())
            ;
        } else{
            LOG.info(correlationIdsMatcher,"Connecting to cluster");
            LOG.debug(correlationIdsMatcher,"Connecting to cluster @ contactPoints {} on port {} with user {} ", config.getCassandraProps().getContactPoints(), config.getCassandraProps().getPort(), config.getCassandraProps().getUserName());
            builder = DseCluster
                    .builder()
                    .addContactPoint(config.getCassandraProps().getContactPoints())
                    .withPort(config.getCassandraProps().getPort())
                    .withCredentials(config.getCassandraProps().getUserName(), config.getCassandraProps().getPassword())
            ;
        }

        dseCluster = builder.build();

        LOG.info(correlationIdsMatcher,"Connecting to keyspace");
        LOG.debug(correlationIdsMatcher,"Connecting to keyspace {} ", config.getCassandraProps().getKeyspace());
        session = dseCluster.connect(config.getCassandraProps().getKeyspace());

        Metadata metadata = dseCluster.getMetadata();
        LOG.info(correlationIdsMatcher,"Connection to Cassandra cluster succeeded");
        LOG.debug(correlationIdsMatcher,"Connection succeeded to the cluster {}", metadata.getClusterName());

    }

    @Override
    public void process(GenericRecord record) {
        String tableName = config.getCassandraProps().getTableName();
        try {
            String jsonString = new String(converter.convertToJson(record), Const.DEFAULT_CHARSET);
            String cqlStatement = String.format(insertStatement, tableName, jsonString);
            LOG.info(correlationIdsMatcher, "Inserting data into cassandra table");
            LOG.debug(correlationIdsMatcher, "Inserting into cassandra table {} values {}", tableName, cqlStatement);
            session.execute(cqlStatement);
        }catch (IOException ioe){
            LOG.error(correlationIdsMatcher, "Error during conversion from generic record {} to json", record.toString());
        }
    }


    @Override
    public void close(){
        session.close();
        dseCluster.close();
        LOG.info(correlationIdsMatcher,"The session and the dsecluster are correctly closed!");

    }

    private RemoteEndpointAwareJdkSSLOptions getSslOptions() throws NoSuchAlgorithmException, KeyManagementException, KeyStoreException, IOException, CertificateException {

        LOG.info(correlationIdsMatcher,"Creating SSL Context...");
        SSLContext context = SSLContext.getInstance("TLS");
        TrustManagerFactory tmf = getTrustManagerFactory();
        char[] storepass = config.getCassandraProps().getSecurityProps().getJksPassword().toCharArray();
        KeyStore ks = KeyStore.getInstance("JKS");

        String jksPath = config.getCassandraProps().getSecurityProps().getJksPath();
        LOG.info(correlationIdsMatcher,"Retrieving Certificate Store from conf");
        LOG.debug(correlationIdsMatcher,"Retrieving Certificate Store from conf @ {}",jksPath);
        InputStream fin = new FileInputStream(jksPath);
        ks.load(fin, storepass);
        tmf.init(ks);
        context.init(null, tmf.getTrustManagers(), null);

        LOG.info(correlationIdsMatcher,"SSL Options retrieved");
        return (RemoteEndpointAwareJdkSSLOptions) RemoteEndpointAwareJdkSSLOptions.builder()
                .withSSLContext(context)
                .build();
    }

    private TrustManagerFactory getTrustManagerFactory() throws NoSuchAlgorithmException {
        TrustManagerFactory tmf;
        try {
            tmf = TrustManagerFactory.getInstance("SunX509");
        } catch (NoSuchAlgorithmException e) {
            LOG.info(correlationIdsMatcher,"SunX509 not found, fallback to IbmX509", e);
            tmf = TrustManagerFactory.getInstance("IbmX509");
        }
        return tmf;
    }
}

