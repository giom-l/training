/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.generators.mappers.kafka;

import com.bnpparibas.itr.dh.datagenerator.core.context.ExecutionContext;
import com.bnpparibas.itr.dh.datagenerator.core.utils.DDACompliance;
import net.logstash.logback.marker.LogstashMarker;
import org.apache.avro.Schema;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

public class KafkaMapper {
    private static final int FIRST_ELEMENT_INDEX = 0;

    public List<GenericRecord> readFrom(Schema schema, Map<String, Object> values) {
        ArrayList<GenericRecord> results = new ArrayList<>();
        while (MapUtils.isNotEmpty(values)) {
            GenericRecord record = getSchemaValue(schema, values);
            results.add(record);
        }
        return results;
    }

    private GenericRecord getSchemaValue(Schema schema, Map<String, Object> values) {
        GenericRecord record = new GenericData.Record(schema);
        for (Schema.Field field : schema.getFields()) {
            getFieldValue(field, values).ifPresent(fieldValue -> record.put(field.name(), fieldValue));
        }
        return record;
    }

    private Optional<Object> getFieldValue(Schema.Field field, Map<String, Object> values) {
        Optional<Object> result = Optional.empty();
        Schema fieldSchema = resolveUnionSchema(field.schema());
        Schema.Type fieldType = fieldSchema.getType();
        String fieldName = field.name();
        if (values.containsKey(fieldName)) {
            if (Schema.Type.RECORD.equals(fieldType)) {
                result = getObjectFromMap(values, fieldSchema, fieldName);
            } else {
                result = getObjectFromList(values, fieldName);
            }
        }
        return result;
    }

    private Schema resolveUnionSchema(Schema schema) {
        Schema.Type fieldType = schema.getType();
        if (Schema.Type.UNION.equals(fieldType)) {
            schema = schema.getTypes().stream()
                    .filter(s -> !Schema.Type.NULL.equals(s.getType()))
                    .findFirst().orElse(schema);
        }
        return schema;
    }

    private Optional<Object> getObjectFromMap(Map<String, Object> values, Schema fieldSchema, String fieldName) {
        Optional<Object> result;
        Map<String, Object> valuesMap = getFieldMapValue(fieldName, values);
        result = Optional.of(getSchemaValue(fieldSchema, valuesMap));
        if (MapUtils.isEmpty(valuesMap)) {
            values.remove(fieldName);
        }
        return result;
    }

    private Optional<Object> getObjectFromList(Map<String, Object> values, String fieldName) {
        Optional<Object> result = Optional.empty();
        try {
            try {
                List<?> valuesList = (List) values.get(fieldName);
                Object firstElement = valuesList.remove(FIRST_ELEMENT_INDEX);
                if (CollectionUtils.isEmpty(valuesList)) {
                    values.remove(fieldName);
                }
                result = Optional.of(firstElement);
            } catch (Throwable throwable) {
                throw new RuntimeException("Error during Kafka mapping", throwable);
            }
        } catch (Throwable th) {
            throw new RuntimeException("Error during Kafka mapping", th);
        }
        return result;
    }

    private Map<String, Object> getFieldMapValue(String fieldName, Map<String, Object> values) {
        Map fieldValues = Map.class.cast(values.get(fieldName));
        Set<?> fieldValuesEntrySet = fieldValues.entrySet();

        return fieldValuesEntrySet.stream()
                .map(entry -> (Map.Entry<?, ?>) entry)
                .collect(Collectors.toMap(
                        entry -> (String) entry.getKey(),
                        entry -> (Object) entry.getValue()
                ));
    }
}
