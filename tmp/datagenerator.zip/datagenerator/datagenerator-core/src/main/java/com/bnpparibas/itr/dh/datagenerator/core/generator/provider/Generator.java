/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.generator.provider;

import com.bnpparibas.itr.dh.datagenerator.core.context.ExecutionContext;

import java.util.Map;

public interface Generator {

    void init(ExecutionContext context, Map<String, String> props);

    String nextValue(String doc, String fieldName);

}
