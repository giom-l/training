/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.generators.primitives.primitives;

import com.bnpparibas.itr.dh.datagenerator.core.context.ExecutionContext;
import com.bnpparibas.itr.dh.datagenerator.core.generators.primitives.PrimitiveTypeGenerator;
import com.bnpparibas.itr.dh.datagenerator.core.utils.Const;
import com.bnpparibas.itr.dh.datagenerator.core.utils.DDACompliance;
import net.logstash.logback.marker.LogstashMarker;
import org.apache.avro.Schema;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class StringGenerator implements PrimitiveTypeGenerator {
    private static final Logger LOG = LoggerFactory.getLogger(StringGenerator.class);
    private static LogstashMarker correlationIdsMatcher;
    private static final char INITIAL_CHAR = 'a';
    private static final char LAST_CHAR = 'z';
    private static final List<Character> LOWER_CASE = IntStream.rangeClosed(INITIAL_CHAR, LAST_CHAR).mapToObj(index -> (char) index).collect(Collectors.toList());
    private static final List<Character> UPPER_CASE = IntStream.rangeClosed('A', 'Z').mapToObj(index -> (char) index).collect(Collectors.toList());
    private static final List<Character> CHARACTERS = Stream.concat(LOWER_CASE.stream(), UPPER_CASE.stream()).collect(Collectors.toList());
    private static final int MAX_STRING_LENGTH = 15;
    private static final int MIN_STRING_LENGTH = 5;
    private List<Character> initialCharList;
    private long currentValue = 0;
    private ExecutionContext context;
    private Schema.Field field;
    private Boolean unique;


    public StringGenerator(ExecutionContext context, Schema.Field field) {
        this.context = context;
        this.field = field;
        this.unique = this.field.aliases().stream().map(String::toLowerCase).anyMatch(Const.UNIQUE_VALUE::equals);
        initLogging(context);
        int randomArraySize;
        try{
            SecureRandom random = SecureRandom.getInstanceStrong();
            randomArraySize = random.nextInt(MAX_STRING_LENGTH) + MIN_STRING_LENGTH;
        }catch(NoSuchAlgorithmException e){
            LOG.warn(correlationIdsMatcher,e.getMessage(), e);
            randomArraySize = new SecureRandom().nextInt(MAX_STRING_LENGTH) + MIN_STRING_LENGTH;
        }
        initialCharList = new ArrayList<>(Collections.nCopies(randomArraySize, INITIAL_CHAR));
    }

    private static synchronized void initLogging(ExecutionContext context){
        correlationIdsMatcher = DDACompliance.getCorrelationIdsMarkersFromContext(context);
    }

    @Override
    public Optional<Object> generate() {
        if(unique){
            return generateUnique();
        }
        return generateRandom();
    }

    private Optional<Object> generateRandom() {
        StringBuilder builder = new StringBuilder();
        try {
            Random random = SecureRandom.getInstanceStrong();
            int stringLength = random.nextInt(MAX_STRING_LENGTH);
            for (int i = 0; i < stringLength; i++) {
                int index = random.nextInt(CHARACTERS.size());
                builder.append(CHARACTERS.get(index));
            }
        } catch (NoSuchAlgorithmException e) {
            LOG.warn(correlationIdsMatcher,e.getMessage(), e);
        }
        return Optional.of(builder.toString());
    }

    private Optional<Object> generateUnique() {
        StringBuilder builder = new StringBuilder();
        long generationValue = currentValue++;
        for (Character anInitialCharList : initialCharList) {
            char character = anInitialCharList;
            long charValue = generationValue % (LAST_CHAR - INITIAL_CHAR);
            generationValue /= (LAST_CHAR - INITIAL_CHAR);
            char newChar = ((char) (character + charValue));
            builder.append(newChar);
        }
        return Optional.of(builder.reverse().toString());
    }
}
