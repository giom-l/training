/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.sink;

import com.bnpparibas.itr.dh.datagenerator.core.context.ExecutionContext;
import com.bnpparibas.itr.dh.datagenerator.core.model.Config;
import com.bnpparibas.itr.dh.datagenerator.core.utils.DDACompliance;
import net.logstash.logback.marker.LogstashMarker;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.RequestBody;
import okhttp3.Request;
import okhttp3.Response;
import org.apache.avro.generic.GenericRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.ConnectException;

public class ApiSink implements Sink {
    private static final MediaType JSON
            = MediaType.parse("application/json; charset=utf-8");

    private LogstashMarker correlationIds;
    private static final Logger LOG = LoggerFactory.getLogger(ApiSink.class);
    private OkHttpClient client = new OkHttpClient();
    private Config config;

    @Override
    public void init(ExecutionContext context, Config config){
        this.correlationIds = DDACompliance.getCorrelationIdsMarkersFromContext(context);
        this.config = config;
        LOG.info(correlationIds, "Initializing the API connection ...");
        LOG.debug(correlationIds, "Initializing the API connection to {}", config.getApiProps().getUrl());
    }

    @Override
    public void process(GenericRecord record){
        RequestBody body = RequestBody.create(JSON, record.toString());
        Request request = new Request.Builder()
                .url(config.getApiProps().getUrl())
                .post(body)
                .build();
        try {
            Response response = client.newCall(request).execute();
            int responseCode = response.code();
            try {
                String responseBody = response.body().string();
                LOG.info(correlationIds, "Record sent. Return code = {}", responseCode);
                LOG.debug(correlationIds, "Record sent {}. Return code = {}", responseBody, responseCode);
            }catch (NullPointerException npe){
                LOG.error(correlationIds, "Error during request");
                LOG.debug(correlationIds, "Error during attempt to send record {}", record.toString());
            }
        }catch (IOException ioe){
            LOG.error(correlationIds, "Connection failed. Impossible to reach host = {}", config.getApiProps().getUrl());
        }
    }

    @Override
    public void close() {
        LOG.info(correlationIds, "Connection already closed");
    }
}
