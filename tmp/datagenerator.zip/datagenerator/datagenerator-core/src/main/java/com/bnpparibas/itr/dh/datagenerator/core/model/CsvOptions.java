/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.apache.commons.lang3.StringUtils;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CsvOptions {

    private static final String DEFAULT_SEPARATOR = ";";
    private static final String DEFAULT_QUOTECHAR = "\u0000";
    private static final String DEFAULT_ESCAPECHAR = "\"";
    private static final String DEFAULT_LINEEND = "\n";

    private String separator;
    private String quoteChar;
    private String escapeChar;
    private String lineEnd;

    public CsvOptions(){
        this.separator = DEFAULT_SEPARATOR;
        this.quoteChar = DEFAULT_QUOTECHAR;
        this.escapeChar = DEFAULT_ESCAPECHAR;
        this.lineEnd = DEFAULT_LINEEND;
    }

    public char getSeparator() {
        return StringUtils.isEmpty(separator)? DEFAULT_SEPARATOR.charAt(0) : separator.charAt(0);
    }

    public char getQuoteChar() {
        return StringUtils.isEmpty(quoteChar)? DEFAULT_QUOTECHAR.charAt(0) : quoteChar.charAt(0);
    }

    public char getEscapeChar() {
        return StringUtils.isEmpty(escapeChar) ? DEFAULT_ESCAPECHAR.charAt(0) : escapeChar.charAt(0);
    }

    public String getLineEnd() {
        return StringUtils.isEmpty(lineEnd) ? DEFAULT_LINEEND : lineEnd;
    }
}
