/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.processors;

import com.bnpparibas.itr.dh.datagenerator.core.context.ExecutionContext;
import com.bnpparibas.itr.dh.datagenerator.core.exceptions.GeneratorCheckException;
import com.bnpparibas.itr.dh.datagenerator.core.exceptions.GeneratorCheckValuesCountException;
import com.bnpparibas.itr.dh.datagenerator.core.model.Config;
import com.bnpparibas.itr.dh.datagenerator.core.model.UserDictionary;
import com.bnpparibas.itr.dh.datagenerator.core.utils.Const;
import com.bnpparibas.itr.dh.datagenerator.core.utils.DDACompliance;
import net.logstash.logback.marker.LogstashMarker;
import org.apache.avro.Schema;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.charset.Charset;
import java.text.MessageFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static com.bnpparibas.itr.dh.datagenerator.core.utils.Const.*;
import static net.logstash.logback.marker.Markers.append;

public class DictionaryCheck implements GeneratorCheck {
    private static final Logger LOG = LoggerFactory.getLogger(DictionaryCheck.class);
    private static final String NO_CHECK_NEEDED = "No field is defined with a dictionary alias. Nothing to check.";
    private static final String NO_DICTIONARY_DEFINED = "No user dictionary defined";
    private static final String MISSING_DICT_DEFINITION = "Dictionary {0} has not been defined for {1}";
    private static final String DICT_FOUND = "Dictionary Check : Dict {0} found";
    private static final String DICT_NOT_FOUND = "Dictionary Check : Dict {0} not found";
    private static final String UNIQUE_VALUE = "unique";
    private static final String DICT_NOT_PROVIDED_ERROR = "Dictionary Check : you requested {0} events but provided only {1} values for unique field {2}";
    private static final String DICT_COUNT_OK = "Dictionary Check : Unique value count OK for field {0} / alias {1}";

    public DictionaryCheck() {
        super();
    }

    @Override
    public void check(Config config, ExecutionContext context) throws GeneratorCheckException {
        LogstashMarker markers = DDACompliance.getCorrelationIdsMarkersFromContext(context);
        Map<String, String> fieldsUnique = getAliasesOfFieldUnique(config);
        Map<String, String> fieldsAliases = getFieldsAliases(config);
        Map<String, List<Object>> userDictionaries = getUserDictionaries(config);
        Map<String, List<Object>> staticDictionaries = getStaticDictionaries();
        Map<String, List<Object>> unionDict = new HashMap<>();
        unionDict.putAll(userDictionaries);
        unionDict.putAll(staticDictionaries);

        checkDictionaryPresence(unionDict, fieldsAliases, markers);
        checkDictUniqueValues(config, unionDict, fieldsUnique, markers);
    }

    @Override
    public void check(List<Config> configs, ExecutionContext context) throws GeneratorCheckException {
        LogstashMarker markers = DDACompliance.getCorrelationIdsMarkersFromContext(context);
        Map<String, String> fieldsUnique = getAliasesOfFieldUnique(configs);
        Map<String, String> fieldsAliases = getFieldsAliases(configs);
        Map<String, List<Object>> userDictionaries = getUserDictionaries(configs);
        Map<String, List<Object>> staticDictionaries = getStaticDictionaries();
        Map<String, List<Object>> unionDict = new HashMap<>();
        unionDict.putAll(userDictionaries);
        unionDict.putAll(staticDictionaries);

        checkDictionaryPresence(unionDict, fieldsAliases, markers);
        for (Config config: configs) {
            checkDictUniqueValues(config, unionDict, fieldsUnique, markers);
        }
    }

    private void checkDictUniqueValues(Config config, Map<String, List<Object>> dictionaries, Map<String, String> fieldsUnique, LogstashMarker markers) throws GeneratorCheckException {
        if (dictionaries.isEmpty()) {
            throw new GeneratorCheckException(NO_DICTIONARY_DEFINED);
        } else {
            for (Map.Entry<String, String> f : fieldsUnique.entrySet()) {
                int totalNumberEvents = config.getNumberOfEvents();
                if (dictionaries.containsKey(f.getValue())) {
                    int dictValuesNumber = dictionaries.get(f.getValue()).size();
                    if (dictValuesNumber < totalNumberEvents) {
                        String error = MessageFormat.format(DICT_NOT_PROVIDED_ERROR, totalNumberEvents, dictValuesNumber, f.getKey());
                        throw new GeneratorCheckValuesCountException(error);
                    } else {
                        if (LOG.isInfoEnabled()) {
                            LOG.info(markers, MessageFormat.format(DICT_COUNT_OK, f.getKey(), f.getValue()));
                        }
                    }
                } else {
                    String error = MessageFormat.format(DICT_NOT_FOUND, f.getValue());
                    //throw new GeneratorCheckException(error);
                }
            }
        }
    }

    private void checkDictionaryPresence(Map<String, List<Object>> dict, Map<String, String> toBeTested, LogstashMarker markers) throws GeneratorCheckException {
        if (toBeTested.isEmpty()) {
            LOG.info(markers, NO_CHECK_NEEDED);
        } else {
            if (dict.isEmpty()) {
                //throw new GeneratorCheckException(NO_DICTIONARY_DEFINED);
                //for now, as we do not check all confs at once, just log a warning
                LOG.warn(markers, NO_DICTIONARY_DEFINED);
            } else {
                for (Map.Entry<String, String> e : toBeTested.entrySet()) {
                    if (dict.containsKey(e.getValue())) {
                        if (LOG.isInfoEnabled()) {
                            LOG.info(markers, MessageFormat.format(DICT_FOUND, e.getValue()));
                        }
                    } else {
                        // throw new GeneratorCheckException(MessageFormat.format(MISSING_DICT_DEFINITION, e.getValue(), e.getKey()));
                        //for now, as we do not check all confs at once, just log a warning
                        LOG.warn(markers, MessageFormat.format(MISSING_DICT_DEFINITION, e.getValue(), e.getKey()));
                    }
                }
            }
        }
    }

    private Map<String, String> getAliasesOfFieldUnique(Config config) {
        List<Schema.Field> fields = config.getSchemaAvro().getFields();
        //return each field name with only the first alias that is not "unique"
        return fields.stream()
                .filter(f -> !f.aliases().isEmpty())
                .filter(f -> f.aliases().size() >= 2 && f.aliases().contains(UNIQUE_VALUE))
                .collect(Collectors.toMap(
                        Schema.Field::name,
                        e -> e.aliases().stream()
                                .filter(((Predicate<String>) UNIQUE_VALUE::equals).negate())
                                .findFirst()
                                .orElse(StringUtils.EMPTY)
                        )
                );
    }

    private Map<String, String> getAliasesOfFieldUnique(List<Config> configs) {
        Map<String, String> aliases = new HashMap<>();
        for (Config config : configs) {
            List<Schema.Field> fields = config.getSchemaAvro().getFields();
            //return each field name with only the first alias that is not "unique"
            aliases.putAll(fields.stream()
                    .filter(f -> !f.aliases().isEmpty())
                    .filter(f -> f.aliases().size() >= 2 && f.aliases().contains(UNIQUE_VALUE))
                    .collect(Collectors.toMap(
                            Schema.Field::name,
                            e -> e.aliases().stream()
                                    .filter(((Predicate<String>) UNIQUE_VALUE::equals).negate())
                                    .findFirst()
                                    .orElse(StringUtils.EMPTY)
                            )
                    )
            );
        }
        return aliases;
    }

    private Map<String, String> getFieldsAliases(Config config) {
        List<Schema.Field> fields = config.getSchemaAvro().getFields();
        //return each field name with only the first alias that is not "unique"
        return fields.stream()
                .filter(f -> !f.aliases().isEmpty())
                .filter(f -> !(f.aliases().size() == 1 && f.aliases().contains(UNIQUE_VALUE)))
                .collect(Collectors.toMap(
                        Schema.Field::name,
                        e -> e.aliases().stream()
                                .filter(((Predicate<String>) UNIQUE_VALUE::equals).negate())
                                .findFirst()
                                .orElse(StringUtils.EMPTY)
                        )
                );
    }


    private Map<String, String> getFieldsAliases(List<Config> configs) {
        Map<String, String> aliases = new HashMap<>();
        for (Config config : configs) {
            List<Schema.Field> fields = config.getSchemaAvro().getFields();
            //return each field name with only the first alias that is not "unique" nor "range*"
            aliases.putAll(fields.stream()
                    .filter(f -> !f.aliases().isEmpty())
                    .filter(f -> !(f.aliases().size() == 1 && f.aliases().contains(UNIQUE_VALUE)))
                    .collect(Collectors.toMap(
                            Schema.Field::name,
                            e -> e.aliases().stream()
                                    .filter(((Predicate<String>) UNIQUE_VALUE::equals).negate())
                                    .findFirst()
                                    .orElse(StringUtils.EMPTY)
                            )
                    )
            );
        }
        return aliases;
    }
    private Map<String, List<Object>> getUserDictionaries(Config config) {
        List<UserDictionary> userDictionaries = config.getUserDictionaries();
        Map<String, List<Object>> dictMap = new HashMap<>();
        if (userDictionaries != null) {
            dictMap =
                    userDictionaries.stream().collect(Collectors.toMap(UserDictionary::getName, UserDictionary::getValues));
        }
        return dictMap;
    }

    private Map<String, List<Object>> getUserDictionaries(List<Config> configs) {
        Map<String, List<Object>> userDicts = new HashMap<>();
        for (Config config : configs){
            List<UserDictionary> userDictionaries = config.getUserDictionaries();
            Map<String, List<Object>> dictMap = new HashMap<>();
            if (userDictionaries != null) {
                dictMap =
                        userDictionaries.stream().collect(Collectors.toMap(UserDictionary::getName, UserDictionary::getValues));
            }
            userDicts.putAll(dictMap);
        }
        return userDicts;
    }


    private Map<String, List<Object>> getStaticDictionaries() {
        Map<String, List<Object>> staticDicts = new HashMap<>();
        try {
            URL dicResource = getClass().getClassLoader().getResource(DICTIONARY_DIR);
            if (dicResource != null) {
                String dictionaryDir = dicResource.getPath();
                File[] files = new File(dictionaryDir).listFiles();
                if (files != null) {

                    staticDicts =
                            Arrays.stream(files)
                                    .collect(Collectors.toMap(File::getName, this::fileToValues));
                }
            }
        } catch (Throwable throwable) {
            LOG.warn(throwable.getMessage(), throwable);
        }
        return staticDicts;
    }

    private List<Object> fileToValues(File file) {
        List<Object> result = new ArrayList<>();
        try {
            result = FileUtils.readLines(file, Charset.defaultCharset())
                    .stream()
                    .map(line -> Arrays.asList(line.split(Const.COMMA)))
                    .flatMap(Collection::stream)
                    .collect(Collectors.toList());
        } catch (IOException e) {
            LOG.error(e.getMessage(), e);
        }
        return result;
    }
}
