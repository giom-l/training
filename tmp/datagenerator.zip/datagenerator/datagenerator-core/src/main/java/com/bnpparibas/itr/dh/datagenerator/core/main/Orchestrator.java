/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.main;

import com.bnpparibas.itr.dh.datagenerator.core.context.ExecutionContext;
import com.bnpparibas.itr.dh.datagenerator.core.exceptions.GeneratorCheckException;
import com.bnpparibas.itr.dh.datagenerator.core.generator.provider.CorrelationIdGenerator;
import com.bnpparibas.itr.dh.datagenerator.core.model.Config;
import com.bnpparibas.itr.dh.datagenerator.core.parser.ConfParser;
import com.bnpparibas.itr.dh.datagenerator.core.processors.DictionaryCheck;
import com.bnpparibas.itr.dh.datagenerator.core.processors.MandatoryFieldsCheck;
import com.bnpparibas.itr.dh.datagenerator.core.utils.Const;
import com.bnpparibas.itr.dh.datagenerator.core.utils.DDACompliance;
import net.logstash.logback.marker.LogstashMarker;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.security.SecureRandom;
import java.util.List;

public class Orchestrator {
    private static final CorrelationIdGenerator CORRELATION_ID_GENERATOR = new CorrelationIdGenerator();
    private static final Logger logger = LoggerFactory.getLogger(Orchestrator.class);
    private static MandatoryFieldsCheck fieldsCheck = new MandatoryFieldsCheck();
    private static DictionaryCheck dictCheck = new DictionaryCheck();

    public static void main(String[] args) {
        try {
            ConfParser confParser = new ConfParser();
            List<Config> configList = confParser.deserialize(new File(args[0]));
            executeConfigs(configList);
        } catch (Throwable exception) {
            logger.error(exception.getMessage(), exception);
        }
    }

    public static void executeConfigs(List<Config> configList) {
        //get the first execution context in order to recover the correlation id for logging
        ExecutionContext firstExecutionContext = null;
        firstExecutionContext = getExecutionContext(configList.get(0), null);
        LogstashMarker correlationIds = DDACompliance.getCorrelationIdsMarkersFromContext(firstExecutionContext);

        //Temporarily remove checks until checks havent be reviewed to consider multi config checks

//        configList = configList.stream()
//                .filter(config -> {
//                    try{
//                        fieldsCheck.check(config);
//                        dictCheck.check(config);
//                        return true;
//                    }catch (GeneratorCheckException ex){
//                        logger.error(ex.getMessage(), ex);
//                        return false;
//                    }
//                }).collect(Collectors.toList());
        try {
            logger.info(correlationIds, "Starting to check mandatory fields...");
            fieldsCheck.check(configList, firstExecutionContext);
            logger.info(correlationIds, "Mandatory fields check completed");
            ExecutionContext lastExecutionContext = null;
            for (Config conf : configList) {
                if (conf == configList.get(0)) {
                    //get firstexecutioncontext if it is the first config run in order to avoid correlation id multiplication
                    lastExecutionContext = firstExecutionContext;
                } else {
                    lastExecutionContext = getExecutionContext(conf, lastExecutionContext);
                }
                Core.process(lastExecutionContext, conf);
            }
        } catch (GeneratorCheckException gce) {
            logger.error("Invalid configuration", gce);
        }
    }

    private static ExecutionContext getExecutionContext(Config conf, ExecutionContext lastExecutionContext) {
        String rootCorrelationId = conf.getRootCorrelationId();
        String parentCorrelationId = conf.getParentCorrelationId();
        String correlationId = CORRELATION_ID_GENERATOR.nextValue(StringUtils.EMPTY, StringUtils.EMPTY);

        if (StringUtils.isEmpty(rootCorrelationId)) {
            rootCorrelationId = correlationId;
        }
        if (StringUtils.isEmpty(parentCorrelationId)) {
            parentCorrelationId = correlationId;
        }


        ExecutionContext context;
        if (lastExecutionContext != null) {
            context = new ExecutionContext(conf, lastExecutionContext.getColumnsCache());
        } else {
            context = new ExecutionContext(conf);
        }
        context.setCorrelationId(correlationId);
        context.setParentCorrelationId(parentCorrelationId);
        context.setRootCorrelationId(rootCorrelationId);

        SecureRandom random = new SecureRandom();
        int naughtyStringsPerc = conf.getNaughtyStringsPerc();

        context.addProperty(Const.RANDOM_PROPERTY, random);
        context.addProperty(Const.NAUGHTY_STRINGS_PERC_PROPERTY, naughtyStringsPerc);

        context.addProperty(Const.USER_DICO, conf.getUserDictionaries());

        return context;
    }
}
