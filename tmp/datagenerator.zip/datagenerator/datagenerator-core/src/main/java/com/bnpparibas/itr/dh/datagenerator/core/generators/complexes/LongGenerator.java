/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.generators.complexes;

public class LongGenerator {

}
