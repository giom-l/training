/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.context;

import com.bnpparibas.itr.dh.datagenerator.core.model.Config;
import org.apache.avro.Schema;
import org.apache.commons.collections.MapUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ExecutionContext {
    private String correlationId;
    private String parentCorrelationId;
    private String rootCorrelationId;
    private Config config;

    private Map<Schema.Field, List<Object>> columnsCache = new HashMap<>();

    public ExecutionContext(Config config){
        this.config = config;
    }
    public ExecutionContext(Config config, Map<Schema.Field, List<Object>> columnsCache){
        this.config = config;
        if(MapUtils.isNotEmpty(columnsCache)){
            this.columnsCache = columnsCache;
        }
    }

    public ExecutionContext(){

    }

    public Map<Schema.Field, List<Object>> getColumnsCache() {
        return columnsCache;
    }

    public Config getConfig() {
        return config;
    }

    private Map<String, Object> properties = new HashMap<>();

    public void addProperty(String key, Object value){
        properties.put(key, value);
    }

    public Object getPropertyValue(String key){
        return properties.get(key);
    }

    public String getCorrelationId() {
        return correlationId;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    public String getParentCorrelationId() {
        return parentCorrelationId;
    }

    public void setParentCorrelationId(String parentCorrelationId) {
        this.parentCorrelationId = parentCorrelationId;
    }

    public String getRootCorrelationId() {
        return rootCorrelationId;
    }

    public void setRootCorrelationId(String rootCorrelationId) {
        this.rootCorrelationId = rootCorrelationId;
    }
}
