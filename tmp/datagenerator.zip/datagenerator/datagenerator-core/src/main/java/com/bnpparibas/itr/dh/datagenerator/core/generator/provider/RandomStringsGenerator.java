/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.generator.provider;

import com.bnpparibas.itr.dh.datagenerator.core.context.ExecutionContext;
import com.bnpparibas.itr.dh.datagenerator.core.utils.Const;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.security.SecureRandom;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


public class RandomStringsGenerator implements Generator {
    private static final int MAX_NAUGHTY_PERC = 100;
    private static String[] NAUGHTIES;


    private SecureRandom random = new SecureRandom();
    private int naughtyStringPerc;

    public RandomStringsGenerator(){
        this.naughtyStringPerc = Const.DEFAULT_NAUGHTY_STRINGS_PERC;
    }

    private synchronized static void initNaughties() {
        if (NAUGHTIES == null) {
            try (InputStream naughtiesStream = RandomStringsGenerator.class.getClassLoader()
                    .getResourceAsStream(Const.DICTIONARY_NAUGHTIES)) {
                List<String> naughties = IOUtils.readLines(naughtiesStream, Charset.defaultCharset());
                List<String> filtredNaughties = naughties.stream()
                        .filter((naughty) -> !naughty.isEmpty())
                        .filter((naughty) -> naughty.charAt(0) != '#')
                        .collect(Collectors.toList());
                NAUGHTIES = filtredNaughties.toArray(new String[filtredNaughties.size()]);
            } catch (IOException e) {
                throw new RuntimeException("Failed to load naughties", e);
            }
        }
    }

    private String getRandomNaughtyString(){
        initNaughties();
        int randomInt = random.nextInt(NAUGHTIES.length);
        return NAUGHTIES[randomInt];
    }

    @Override
    public void init(ExecutionContext context, Map<String, String> props) {
        Object naughtyValue = context.getPropertyValue(Const.NAUGHTY_STRINGS_PERC_PROPERTY);
        if(naughtyValue != null){
            this.naughtyStringPerc = (Integer) naughtyValue;
        }
    }

    @Override
    public String nextValue(String doc, String fieldName) {
        if(StringUtils.isEmpty(doc)){
            int naughtyPerc = random.nextInt(MAX_NAUGHTY_PERC);
            if(naughtyPerc < naughtyStringPerc){
                return getRandomNaughtyString();
            }
        }
        return RandomStringUtils.randomAlphanumeric(Const.COUNT);
    }
}
