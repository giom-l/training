/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.generators.complexes;

import com.bnpparibas.itr.dh.datagenerator.core.context.ExecutionContext;
import com.bnpparibas.itr.dh.datagenerator.core.generators.primitives.PrimitiveFieldGenerator;
import org.apache.avro.Schema;

import java.util.Map;
import java.util.stream.Collectors;

public class SchemaGenerator {

    public static Map<String, Object> generate(ExecutionContext context, Schema schema, int size) {
        return schema.getFields()
                .stream()
                .collect(Collectors.toMap(Schema.Field::name, field -> generateField(context, field, size)));
    }

    public static Object generateField(ExecutionContext context, Schema.Field field, int size) {
        Schema.Type type = field.schema().getType();
        switch (type) {
            case UNION:
                return new UnionGenerator().generate(context, field, size);
            case RECORD:
                return new RecordGenerator().generate(context, field, size);
            case ARRAY:
                return new ArrayGenerator().generate(context, field, size);
            default:
                return new PrimitiveFieldGenerator(context, field).generateField(size);
        }
    }
}
