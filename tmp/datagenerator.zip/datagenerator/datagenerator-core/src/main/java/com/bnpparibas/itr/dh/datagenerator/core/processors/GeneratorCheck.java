/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.processors;

import com.bnpparibas.itr.dh.datagenerator.core.context.ExecutionContext;
import com.bnpparibas.itr.dh.datagenerator.core.exceptions.GeneratorCheckException;
import com.bnpparibas.itr.dh.datagenerator.core.exceptions.GeneratorCheckValuesCountException;
import com.bnpparibas.itr.dh.datagenerator.core.model.Config;

import java.io.IOException;
import java.util.List;


public interface GeneratorCheck {
    void check(Config conf, ExecutionContext executionContext) throws GeneratorCheckException, GeneratorCheckValuesCountException, IOException;
    void check(List<Config> confs, ExecutionContext executionContext) throws GeneratorCheckException, GeneratorCheckValuesCountException, IOException;
}
