/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.generators.primitives.primitives;

import com.bnpparibas.itr.dh.datagenerator.core.context.ExecutionContext;
import com.bnpparibas.itr.dh.datagenerator.core.generators.primitives.PrimitiveTypeGenerator;
import com.bnpparibas.itr.dh.datagenerator.core.utils.Const;
import com.bnpparibas.itr.dh.datagenerator.core.utils.DDACompliance;
import net.logstash.logback.marker.LogstashMarker;
import org.apache.avro.Schema;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class IntGenerator implements PrimitiveTypeGenerator {
    private static final Logger logger = LoggerFactory.getLogger(IntGenerator.class);
    private LogstashMarker correlationIdsMatcher;
    private int currentValue;
    private ExecutionContext context;
    private Schema.Field field;
    private Boolean unique;
    private Boolean hasRange;
    private int min;
    private int max;
    private Pattern rangePattern;
    private Matcher rangeMatches;
    private String domain;
    private Pattern domainPattern;
    private Matcher domainMatches;

    public IntGenerator(ExecutionContext context, Schema.Field field) {
        this.context = context;
        this.field = field;
        correlationIdsMatcher = DDACompliance.getCorrelationIdsMarkersFromContext(context);
        currentValue = 1;
        //min is set to 1 to exclude 0 from domains
        min = 1;
        max = 0;
        hasRange = false;
        unique = this.field.aliases().stream().map(String::toLowerCase).anyMatch(Const.UNIQUE_VALUE::equals);
        rangePattern = Pattern.compile(Const.RANGE_INT_PATTERN);
        rangeMatches = rangePattern.matcher(field.aliases().toString());

        if (rangeMatches.find()) {
            min = Integer.parseInt(rangeMatches.group(1));
            max = Integer.parseInt(rangeMatches.group(2));
            currentValue = min;
            hasRange = true;
        }

        domainPattern = Pattern.compile(Const.DOMAIN_PATTERN);
        domainMatches = domainPattern.matcher(field.aliases().toString());

        if (domainMatches.find()) {
            domain = domainMatches.group(1).toLowerCase();
            if (domain.equals(Const.NEGATIVE)) {
                currentValue = Integer.MIN_VALUE;
            }
        }
    }

    @Override
    public Optional<Object> generate() {
        Optional<Object> retour = Optional.of(0);
        if (unique) {
            //whatever the range or domain set, current value has been correctly initialized
            retour = Optional.of(currentValue++);
        } else {
            if (hasRange) {
                try {
                    int value = SecureRandom.getInstanceStrong().nextInt((max - min + 1)) + min;
                    retour = Optional.of(value);
                } catch (NoSuchAlgorithmException e) {
                    retour = Optional.empty();
                }
            } else {
                switch (domain != null ? domain : StringUtils.EMPTY) {
                    case Const.NEGATIVE:
                        try {
                            int value = SecureRandom.getInstanceStrong().nextInt(Integer.MAX_VALUE - 1) * (-1);
                            retour = Optional.of(value);
                        } catch (NoSuchAlgorithmException e) {
                            retour = Optional.empty();
                        }

                        break;
                    case Const.POSITIVE:
                        try {
                            int value = SecureRandom.getInstanceStrong().nextInt(Integer.MAX_VALUE - 1);
                            retour = Optional.of(value);
                        } catch (NoSuchAlgorithmException e) {
                            retour = Optional.empty();
                        }
                        break;
                    default:
                        try {
                            int value = SecureRandom.getInstanceStrong().nextInt();
                            retour = Optional.of(value);
                        } catch (NoSuchAlgorithmException e) {
                            retour = Optional.empty();
                        }
                        break;
                }
            }
        }
        return retour;
    }
}
