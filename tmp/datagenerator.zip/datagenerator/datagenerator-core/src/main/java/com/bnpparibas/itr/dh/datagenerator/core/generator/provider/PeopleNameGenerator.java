/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.generator.provider;

import com.bnpparibas.itr.dh.datagenerator.core.context.ExecutionContext;
import com.bnpparibas.itr.dh.datagenerator.core.utils.Const;
import org.apache.commons.io.IOUtils;

import java.io.IOException;
import java.io.InputStream;
import java.security.SecureRandom;
import java.util.Map;

public class PeopleNameGenerator implements Generator {
    private static String FAILED_TO_LOAD_NAMES_MESSAGE = "Failed to load names";

    private static String[] MALE_FIRST_NAMES;
    private static String[] FEMALE_FIRST_NAMES;
    private static String[] LAST_NAMES;

    private SecureRandom random;

    private boolean generateFirstName = true;
    private boolean generateLastName = true;
    private boolean generateMale = true;
    private boolean generateFemale = true;

    private synchronized static void initMaleNames(){
        if (MALE_FIRST_NAMES == null) {
            try (InputStream nameStream = PeopleNameGenerator.class.getClassLoader()
                    .getResourceAsStream(Const.DICTIONARY_MALE_FIRST_NAME)) {
                String namesStr = IOUtils.toString(nameStream, Const.DEFAULT_CHARSET);
                MALE_FIRST_NAMES = namesStr.split(Const.COMMA);
            } catch (IOException e) {
                throw new RuntimeException(FAILED_TO_LOAD_NAMES_MESSAGE, e);
            }
        }
    }

    private synchronized static void initFemaleNames(){
        if (FEMALE_FIRST_NAMES == null) {
            try (InputStream nameStream = PeopleNameGenerator.class.getClassLoader()
                    .getResourceAsStream(Const.DICTIONARY_FEMALE_FIRST_NAME)) {
                String namesStr = IOUtils.toString(nameStream, Const.DEFAULT_CHARSET);
                FEMALE_FIRST_NAMES = namesStr.split(Const.COMMA);
            } catch (IOException e) {
                throw new RuntimeException(FAILED_TO_LOAD_NAMES_MESSAGE, e);
            }
        }
    }

    private synchronized static void initLastNames(){
        if (LAST_NAMES == null) {
            try (InputStream nameStream = PeopleNameGenerator.class.getClassLoader()
                    .getResourceAsStream(Const.DICTIONARY_LAST_NAME)) {
                String namesStr = IOUtils.toString(nameStream, Const.DEFAULT_CHARSET);
                LAST_NAMES = namesStr.split(Const.COMMA);
            } catch (IOException e) {
                throw new RuntimeException(FAILED_TO_LOAD_NAMES_MESSAGE, e);
            }
        }
    }

    private String getRandomMaleName() {
        initMaleNames();
        int randomIndex = random.nextInt(MALE_FIRST_NAMES.length);
        return MALE_FIRST_NAMES[randomIndex];
    }

    private static int getMaleNamesLength(){
        initMaleNames();
        return MALE_FIRST_NAMES.length;
    }

    private String getRandomFemaleName() {
        initFemaleNames();
        int randomIndex = random.nextInt(FEMALE_FIRST_NAMES.length);
        return FEMALE_FIRST_NAMES[randomIndex];
    }

    private static int getFemaleNamesLength(){
        initFemaleNames();
        return FEMALE_FIRST_NAMES.length;
    }

    private String getRandomLastName() {
        initLastNames();
        int randomIndex = random.nextInt(LAST_NAMES.length);
        return LAST_NAMES[randomIndex];
    }

    @Override
    public void init(ExecutionContext context, Map<String, String> props) {
        random = (SecureRandom) context.getPropertyValue(Const.RANDOM_PROPERTY);
        if(random == null){
            random = new SecureRandom();
        }

        String gender = props.get(Const.GENDER);
        if (gender == null) {
            gender = Const.ALL;
        }
        switch (gender) {
            case Const.ALL:
                generateMale = true;
                generateFemale = true;
                break;
            case Const.MALE:
                generateMale = true;
                generateFemale = false;
                break;
            case Const.FEMALE:
                generateMale = false;
                generateFemale = true;
                break;
            default:
                throw new IllegalArgumentException("Unknown gender: " + gender);
        }
        String type = props.get(Const.TYPE);
        if (type == null) {
            type = Const.ALL;
        }
        switch (type) {
            case Const.ALL:
                generateFirstName = true;
                generateLastName = true;
                break;
            case Const.FIRST:
                generateFirstName = true;
                generateLastName = false;
                break;
            case Const.LAST:
                generateFirstName = false;
                generateLastName = true;
                break;
            default:
                throw new IllegalArgumentException("Unknown name type: " + gender);
        }
    }

    @Override
    public String nextValue(String doc, String fieldName) {
        String result = "";
        if (generateFirstName) {
            String firstName;
            if (generateMale && generateFemale) {
                int index = random.nextInt(getMaleNamesLength() + getFemaleNamesLength());
                if (index < getMaleNamesLength()) {
                    firstName = getRandomMaleName();
                } else {
                    firstName = getRandomFemaleName();
                }
            } else {
                if (generateMale) {
                    firstName = getRandomMaleName();
                } else {
                    firstName = getRandomFemaleName();
                }
            }
            result += firstName;
        }
        if (generateLastName) {
            String lastName = getRandomLastName();
            if (!result.isEmpty()) {
                result += " ";
            }
            result += lastName;
        }
        return result;
    }
}
