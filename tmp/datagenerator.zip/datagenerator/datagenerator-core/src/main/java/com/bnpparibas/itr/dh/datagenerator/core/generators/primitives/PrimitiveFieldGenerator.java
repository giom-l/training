/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.generators.primitives;

import com.bnpparibas.itr.dh.datagenerator.core.context.ExecutionContext;
import com.bnpparibas.itr.dh.datagenerator.core.generators.primitives.dictionary.CacheDictionaryGenerator;
import com.bnpparibas.itr.dh.datagenerator.core.generators.primitives.dictionary.UserDictionaryGenerator;

import com.bnpparibas.itr.dh.datagenerator.core.generators.primitives.primitives.DoubleGenerator;
import com.bnpparibas.itr.dh.datagenerator.core.generators.primitives.primitives.FloatGenerator;
import com.bnpparibas.itr.dh.datagenerator.core.generators.primitives.primitives.IntGenerator;
import com.bnpparibas.itr.dh.datagenerator.core.generators.primitives.primitives.LongGenerator;
import com.bnpparibas.itr.dh.datagenerator.core.generators.primitives.primitives.BooleanGenerator;
import com.bnpparibas.itr.dh.datagenerator.core.generators.primitives.primitives.StringGenerator;
import org.apache.avro.Schema;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class PrimitiveFieldGenerator {
    private static final int START_INCLUSIVE = 0;

    private Schema.Field field;
    private ExecutionContext context;
    private PrimitiveTypeGenerator randomGenerator;
    private UserDictionaryGenerator userDictionaryGenerator;
    private CacheDictionaryGenerator cacheDictionaryGenerator;

    public PrimitiveFieldGenerator(ExecutionContext context, Schema.Field field) {
        this.field = field;
        this.context = context;
        this.cacheDictionaryGenerator = new CacheDictionaryGenerator(context, field);
        initUserDictionary();
        initRandomGenerator();
    }

    synchronized public List<Object> generateField(int size) {
        List<Object> results = generateColumnValues(size);
        Collections.shuffle(results);
        cacheDictionaryGenerator.sealCache();
        return results;
    }

    private void initRandomGenerator() {
        Schema.Type fieldType = field.schema().getType();
        randomGenerator = generatorOf(fieldType);
    }

    private PrimitiveTypeGenerator generatorOf(Schema.Type fieldType) {
        switch (fieldType) {
            case LONG:
                return new LongGenerator(context, field);
            case INT:
                return new IntGenerator(context, field);
            case DOUBLE:
                return new DoubleGenerator(context, field);
            case FLOAT:
                return new FloatGenerator(context, field);
            case BOOLEAN:
                return new BooleanGenerator(context, field);
            case STRING:
                return new StringGenerator(context, field);
            default:
                return PrimitiveTypeGenerator.RANDOM_EMPTY;
        }
    }

    private void initUserDictionary() {
        userDictionaryGenerator = new UserDictionaryGenerator(context, field);
    }

    private List<Object> generateColumnValues(int size) {
        return IntStream.range(START_INCLUSIVE, size)
                .mapToObj(index -> this.generateColumnValue())
                .filter(Optional::isPresent)
                .map(Optional::get)
                .collect(Collectors.toList());
    }

    private Optional<Object> generateColumnValue() {
        Optional<Object> result = userDictionaryGenerator.generate();
        if (!result.isPresent()) {
            result = cacheDictionaryGenerator.generate();
        }
        if (!result.isPresent()) {
            result = getRandomValue();
        }
        result.ifPresent(cacheDictionaryGenerator::cacheValue);
        return result;
    }

    private Optional<Object> getRandomValue() {
        if (randomGenerator == null) {
            return Optional.empty();
        }
        return randomGenerator.generate();
    }
}
