/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.generators.primitives;

import java.util.Optional;

public class StaticEmpty implements PrimitiveTypeGenerator {
    @Override
    public Optional<Object> generate() {
        return Optional.empty();
    }
}
