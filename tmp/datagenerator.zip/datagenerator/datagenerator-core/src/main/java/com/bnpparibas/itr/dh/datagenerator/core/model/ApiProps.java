/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.model;

import lombok.Getter;
import lombok.Setter;

public class ApiProps implements SinkProps {
    @Getter
    @Setter
    private String url;
    @Setter
    private int numberOfEvents;

    @Override
    public int getNumberOfEvents() {
        return numberOfEvents;
    }

}