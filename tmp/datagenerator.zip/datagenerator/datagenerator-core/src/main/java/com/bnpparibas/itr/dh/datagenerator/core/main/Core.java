/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.main;

import com.bnpparibas.itr.dh.datagenerator.core.context.ExecutionContext;
import com.bnpparibas.itr.dh.datagenerator.core.generators.complexes.SchemaGenerator;
import com.bnpparibas.itr.dh.datagenerator.core.generators.mappers.kafka.KafkaMapper;
import com.bnpparibas.itr.dh.datagenerator.core.model.Config;
import com.bnpparibas.itr.dh.datagenerator.core.sink.ArchiveSink;
import com.bnpparibas.itr.dh.datagenerator.core.sink.CassandraSink;
import com.bnpparibas.itr.dh.datagenerator.core.sink.CsvSink;
import com.bnpparibas.itr.dh.datagenerator.core.sink.KafkaSink;
import com.bnpparibas.itr.dh.datagenerator.core.sink.ApiSink;
import com.bnpparibas.itr.dh.datagenerator.core.utils.Const;
import com.bnpparibas.itr.dh.datagenerator.core.utils.DDACompliance;
import net.logstash.logback.marker.LogstashMarker;
import org.apache.avro.Schema;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.util.Map;

import static com.bnpparibas.itr.dh.datagenerator.core.utils.LambdaUtil.throwingConsumerWrapper;

public class Core {

    private static final Logger logger = LoggerFactory.getLogger(Core.class);

    public static void process(ExecutionContext context, Config conf) {
        LogstashMarker correlationIds = DDACompliance.getCorrelationIdsMarkersFromContext(context);

        //if output is neither empty nor null
        if (!StringUtils.isEmpty(conf.getOutput())) {
            logger.info(correlationIds, "Output : {}", conf.getOutput());
            switch (conf.getOutput().toLowerCase()) {
                case Const.CSV:
                    processCSVConfig(context, correlationIds);
                    break;
                case Const.KAFKA:
                    processKafkaConfig(context, correlationIds);
                    break;
                case Const.CASSANDRA:
                    processCassandraConfig(context, correlationIds);
                    break;
                case Const.API:
                    processApiConfig(context, correlationIds);
                    break;
                default:
                    logger.error(correlationIds, "Output format {} is not handled", conf.getOutput());
                    break;
            }
        } else {
            logger.error(correlationIds, "Output format has not been provided");
        }
    }

    private static void processCSVConfig(ExecutionContext context, LogstashMarker correlationIds) {
        Config conf = context.getConfig();
        KafkaMapper kafkaMapper = new KafkaMapper();
        Schema schemaAvro = conf.getSchemaAvro();
        CsvSink csvSink = new CsvSink();
        csvSink.init(context, conf);
        int numberOfLines = conf.getCsvProps().getNumberOfLines();


        logger.info(correlationIds, "Start Generating lines in csv files");
        logger.info(correlationIds, "Number of files : {}", conf.getCsvProps().getNumberOfFiles());
        logger.info(correlationIds, "Number of lines per file : {}", numberOfLines);
        logger.info(correlationIds, "Number of events per CSV : {}", conf.getCsvProps().getNumberOfEvents());
        logger.info(correlationIds, "Number of events : {}", conf.getCsvProps().getNumberOfEvents());


        for (int i = 0; i < conf.getCsvProps().getNumberOfFiles(); i++) {
            Map<String, Object> eventsMap = SchemaGenerator.generate(context, schemaAvro, numberOfLines);
            try {
                csvSink.createFile(i);
                if (conf.getCsvProps().isWithHeader()) {
                    csvSink.writeHeader(schemaAvro);
                }
                try {
                    kafkaMapper.readFrom(schemaAvro, eventsMap).forEach(throwingConsumerWrapper(csvSink::process));
                } catch (RuntimeException rex) {
                    logger.error(correlationIds, "Error during csv processing", rex);
                    csvSink.close();
                }
            } catch (IOException ioe) {
                logger.error(correlationIds, "Error during file manipulation", ioe);
            } finally {
                try {
                    csvSink.close();
                } catch (IOException ioe) {
                    logger.error(correlationIds, "Error during close of file #{}", i);
                }
            }
        }
        logger.info(correlationIds, "End Generating lines in csv files");
        if (conf.getCsvProps().isWithArchive()) {
            ArchiveSink archiveSink = new ArchiveSink(context);
            archiveSink.compressFiles(csvSink.getDirectory(), csvSink.getTmpDirectory(), conf.getCsvProps().getArchiveName());
        } else {
            try {
                csvSink.moveFilesToTarget();
            } catch (IOException ioe) {
                logger.error(correlationIds, "Error during moving files to target directory {}", csvSink.getDirectory());
            }
        }
    }

    private static void processKafkaConfig(ExecutionContext context, LogstashMarker correlationIds) {
        Config conf = context.getConfig();
        KafkaMapper kafkaMapper = new KafkaMapper();
        Schema kafkaSchema = conf.getSchemaAvro();
        int numberOfEvents = conf.getKafkaProps().getNumberOfEvents();
        KafkaSink kafkaSink = new KafkaSink();
        kafkaSink.init(context, conf);

        logger.info(correlationIds, "Start Generating events in Kafka");
        logger.info(correlationIds, "Number of events per Kafka: {}", numberOfEvents);
        logger.info(correlationIds, "Number of events : {}", numberOfEvents);

        Map<String, Object> eventsMap = SchemaGenerator.generate(context, kafkaSchema, numberOfEvents);
        try {
            kafkaMapper.readFrom(kafkaSchema, eventsMap).forEach(kafkaSink::process);

        } catch (RuntimeException rex) {
            logger.error(correlationIds, "Error during kafka processing", rex);
        } finally {
            kafkaSink.close();
            logger.info(correlationIds, "End Generating events in Kafka");
        }
    }


    private static void processCassandraConfig(ExecutionContext context, LogstashMarker correlationIds) {
        Config conf = context.getConfig();
        KafkaMapper kafkaMapper = new KafkaMapper();
        Schema schemaAvro = conf.getSchemaAvro();
        int numberOfLines = conf.getCassandraProps().getNumberOfLines();
        CassandraSink cassandraSink = new CassandraSink();
        try {
            cassandraSink.init(context, conf);
            logger.info(correlationIds, "Start generating lines in cassandra");
            logger.info(correlationIds, "Number of lines : {}", numberOfLines);
            logger.info(correlationIds, "Number of events : {}", conf.getCassandraProps().getNumberOfEvents());
            logger.info(correlationIds, "Number of events per Cassandra : {}", conf.getCassandraProps().getNumberOfEvents());
            Map<String, Object> eventsMap = SchemaGenerator.generate(context, schemaAvro, numberOfLines);
            kafkaMapper.readFrom(schemaAvro, eventsMap).forEach(throwingConsumerWrapper(cassandraSink::process));
        } catch (CertificateException | NoSuchAlgorithmException | KeyStoreException | KeyManagementException | IOException except) {
            logger.error(correlationIds, "Error during cassandra processing", except);
        } finally {
            cassandraSink.close();
            logger.info(correlationIds, "End Generating lines in cassandra");
        }
    }

    private static void processApiConfig(ExecutionContext context, LogstashMarker correlationIds) {
        Config conf = context.getConfig();
        KafkaMapper kafkaMapper = new KafkaMapper();
        Schema schemaAvro = conf.getSchemaAvro();
        int numberOfEvents = conf.getApiProps().getNumberOfEvents();
        ApiSink apiSink = new ApiSink();
        apiSink.init(context, conf);

        logger.info(correlationIds, "Start Generating events in Api");
        logger.info(correlationIds, "Number of events : {}", numberOfEvents);
        logger.info(correlationIds, "Number of events per Api : {}", numberOfEvents);
        Map<String, Object> eventsMap = SchemaGenerator.generate(context, schemaAvro, numberOfEvents);
        kafkaMapper.readFrom(schemaAvro, eventsMap).forEach(throwingConsumerWrapper(apiSink::process));
        apiSink.close();
        logger.info(correlationIds, "End Generating events in Api");
    }

}
