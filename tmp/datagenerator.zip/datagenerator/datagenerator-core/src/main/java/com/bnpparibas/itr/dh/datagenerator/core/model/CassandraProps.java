/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */

package com.bnpparibas.itr.dh.datagenerator.core.model;


import lombok.Getter;
import lombok.Setter;

public class CassandraProps implements SinkProps{

    private static final Boolean DEFAULT_WITHSSL = false;

    @Getter
    @Setter
    private String contactPoints;
    @Getter
    @Setter
    private int port;
    @Getter
    @Setter
    private String keyspace;
    @Getter
    @Setter
    private String userName;
    @Getter
    @Setter
    private String password;
    @Getter
    @Setter
    private String tableName;
    @Getter
    @Setter
    private int numberOfLines;
    @Getter
    @Setter
    private CassandraSecurityProps securityProps;
    @Getter
    @Setter
    private Boolean withSSL;


    public Boolean isWithSSL() {
        return (withSSL == null) ? DEFAULT_WITHSSL : withSSL;
    }

    @Override
    public int getNumberOfEvents() {
        return this.numberOfLines;
    }
}

