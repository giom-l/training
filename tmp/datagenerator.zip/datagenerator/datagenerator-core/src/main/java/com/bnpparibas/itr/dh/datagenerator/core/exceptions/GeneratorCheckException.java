/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.exceptions;

public class GeneratorCheckException extends Exception {

    private static final long serialVersionUID=1L;

    public GeneratorCheckException(String message){
        super(message);
    }
}
