/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.generators.complexes;

import com.bnpparibas.itr.dh.datagenerator.core.context.ExecutionContext;
import com.bnpparibas.itr.dh.datagenerator.core.utils.DDACompliance;
import net.logstash.logback.marker.LogstashMarker;
import org.apache.avro.Schema;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.concurrent.ExecutionContextExecutor;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Optional;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class ArrayGenerator {
    private static final Logger LOG = LoggerFactory.getLogger(ArrayGenerator.class);
    private static LogstashMarker correlationIdsMatcher;
    private static final int MAX_ARRAY_SIZE = 100;

    public Object generate(ExecutionContext context, Schema.Field field, int size) {
        initLogging(context);
        Optional<Schema.Field> newField = createElementsField(field);
        return IntStream.range(0, size)
                .mapToObj(index -> {
                    Optional<Integer> optionalRandom = Optional.empty();
                    try {
                        Random random = SecureRandom.getInstanceStrong();
                        optionalRandom = Optional.of(random.nextInt(MAX_ARRAY_SIZE));
                    } catch (NoSuchAlgorithmException e) {
                        LOG.warn(correlationIdsMatcher,e.getMessage(), e);
                    }
                    return optionalRandom;
                })
                .filter(Optional::isPresent)
                .filter(arraySize -> newField.isPresent())
                .map(arraySize -> SchemaGenerator.generateField(context, newField.get(), arraySize.get()))
                .collect(Collectors.toList());
    }

    private static synchronized void initLogging(ExecutionContext context){
        correlationIdsMatcher = DDACompliance.getCorrelationIdsMarkersFromContext(context);
    }

    private static Optional<Schema.Field> createElementsField(Schema.Field field) {
        Schema elementSchema = field.schema().getElementType();
        return Optional.of(new Schema.Field(field.name(), elementSchema, field.doc(), field.defaultVal()));
    }
}
