/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.model;

import com.bnpparibas.itr.dh.datagenerator.core.utils.Const;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;
import org.apache.avro.Schema;

import java.util.ArrayList;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Config {

    @Getter
    @Setter
    private String output;

    @Getter
    @Setter
    private int naughtyStringsPerc;

    @Getter
    @Setter
    private int rangeMin;

    @Getter
    @Setter
    private int rangeMax;

    @Getter
    @Setter
    private KafkaProps kafkaProps;

    @Getter
    @Setter
    private CsvProps csvProps;

    @Getter
    @Setter
    private CassandraProps cassandraProps;

    @Getter
    @Setter
    private Schema schemaAvro;

    @Getter
    @Setter
    private String rootCorrelationId;

    @Getter
    @Setter
    private String parentCorrelationId;

    @Getter
    @Setter
    private ApiProps apiProps;

    private List<UserDictionary> userDictionaries;

    public List<UserDictionary> getUserDictionaries() {
        if (userDictionaries == null)
            userDictionaries = new ArrayList<>();
        return userDictionaries;
    }


    public int getNumberOfEvents(){
        int events = 0;
        switch(this.output){
            case Const.CSV:
                events = this.csvProps.getNumberOfEvents();
                break;
            case Const.KAFKA:
                events = this.kafkaProps.getNumberOfEvents();
                break;
            case Const.CASSANDRA:
                events = this.cassandraProps.getNumberOfEvents();
                break;
            case Const.API:
                events = this.apiProps.getNumberOfEvents();
                break;
            default:
                break;
        }
        return events;
    }
}
