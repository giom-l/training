/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
public class KafkaProps implements SinkProps{

    private static final Boolean DEFAULT_WITHSSL = false;

    @Getter
    @Setter
    private String bootstrapServers;
    @Getter
    @Setter
    private String schemaRegistry;
    @Getter
    @Setter
    private String topicName;
    @Getter
    @Setter
    private int numberOfEvents;
    @Setter
    private Boolean withSSL;
    @Getter
    @Setter
    private KafkaSecurityProps securityProps;

    @Override
    public int getNumberOfEvents() {
        return numberOfEvents;
    }

    public Boolean isWithSSL() {
        return (withSSL == null) ? DEFAULT_WITHSSL : withSSL;
    }

}
