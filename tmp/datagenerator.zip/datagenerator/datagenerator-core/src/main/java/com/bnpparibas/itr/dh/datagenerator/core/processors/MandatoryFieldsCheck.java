/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.processors;

import com.bnpparibas.itr.dh.datagenerator.core.context.ExecutionContext;
import com.bnpparibas.itr.dh.datagenerator.core.exceptions.GeneratorCheckException;
import com.bnpparibas.itr.dh.datagenerator.core.model.Config;
import com.bnpparibas.itr.dh.datagenerator.core.model.UserDictionary;
import com.bnpparibas.itr.dh.datagenerator.core.utils.DDACompliance;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.github.wnameless.json.flattener.JsonFlattener;
import net.logstash.logback.marker.LogstashMarker;
import org.apache.avro.Schema;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static com.bnpparibas.itr.dh.datagenerator.core.utils.Const.*;


public class MandatoryFieldsCheck implements GeneratorCheck {
    private static final Logger LOG = LoggerFactory.getLogger(MandatoryFieldsCheck.class);

    private static final String OUTPUT = "MandatoryFieldsCheck : output is set to {}";
    private static final String STOP = "stop";
    private static final String VALIDATING_INPUT_CONF = "Validating input conf...";
    private static final String INPUT_CONF_VALIDATED = "Input conf validated";
    private static final String GENERATION_STARTING = "Generation can now start...";

    private static final String EXCEPTION = "MandatoryFieldCheck : [%s] missing";

    private LogstashMarker markers;


    public MandatoryFieldsCheck() {
        super();
    }

    @Override
    public void check(Config config, ExecutionContext executionContext) throws GeneratorCheckException {
        this.markers = DDACompliance.getCorrelationIdsMarkersFromContext(executionContext);
        String output = config.getOutput() != null ? config.getOutput().toLowerCase() : STOP;


        switch (output) {
            case CSV:
                LOG.debug(markers, OUTPUT, CSV);
                LOG.info(markers, VALIDATING_INPUT_CONF);
                checkCSVRequiredFields(config);
                LOG.info(markers, INPUT_CONF_VALIDATED);
                LOG.info(markers, GENERATION_STARTING);
                break;

            case KAFKA:
                LOG.debug(markers, OUTPUT, KAFKA);
                LOG.info(markers, VALIDATING_INPUT_CONF);
                checkKafkaRequiredFields(config);
                LOG.info(markers, INPUT_CONF_VALIDATED);
                LOG.info(markers, GENERATION_STARTING);
                break;

            case CASSANDRA:
                LOG.debug(markers, OUTPUT, CASSANDRA);
                LOG.info(markers, VALIDATING_INPUT_CONF);
                checkCassandraRequiredFields(config);
                break;

            case API:
                LOG.debug(markers, OUTPUT, API);
                LOG.info(markers, VALIDATING_INPUT_CONF);
                checkApiRequiredFields(config);
                break;


            case STOP:
            default:
                String emptyOutputMsg = "MandatoryFieldsCheck:- output seems to be empty or invalid (valid values are csv, kafka, cassandra and api)";
                LOG.error(markers, emptyOutputMsg);
                throw new GeneratorCheckException(emptyOutputMsg);

        }
    }

    @Override
    public void check(List<Config> confs, ExecutionContext context) throws GeneratorCheckException {
        for (Config config : confs) {
            check(config, context);
        }
    }

    private List<String> checkUserDictionariesRequiredFields(Config config) {
        List<String> missingFields = new ArrayList<>();
        List<UserDictionary> userDict = Optional.of(config.getUserDictionaries()).orElse(new ArrayList<>());

        if (!userDict.isEmpty()) {
            for (UserDictionary dict : userDict) {
                if (StringUtils.isEmpty(dict.getName()))
                    missingFields.add("userDictionaries/name");
                if (dict.getValues().isEmpty())
                    missingFields.add("userDictionaries/values");
            }
        }
        return missingFields;
    }


    private void checkCSVRequiredFields(Config config) throws GeneratorCheckException {
        List<String> missingFields = new ArrayList<>(checkUserDictionariesRequiredFields(config));
        //Declaration of the requiredFields
        List<String> requiredFields = new ArrayList<>();
        requiredFields.add("csvProps.targetDir");
        requiredFields.add("csvProps.fileName");
        requiredFields.add("csvProps.numberOfLines");
        requiredFields.add("csvProps.numberOfFiles");

        List<String> requiredArchiveFields = new ArrayList<>();
        requiredArchiveFields.add("csvProps.withArchive");
        requiredArchiveFields.add("csvProps.archiveName");

        LOG.debug(markers, "required fields to be checked {}", requiredFields);
        LOG.debug(markers, "required archive fields to be checked if withArchive is true {}", requiredArchiveFields);

        try {
            Map<String, Object> flattenedJsonMap = getFlattenedMapFromConfig(config);
            //verify if the required fields list corresponds to the flattened JsonMap
            missingFields.addAll(checkRequiredFields(requiredFields, flattenedJsonMap));
            if (flattenedJsonMap.containsKey("csvProps.withArchive") && flattenedJsonMap.get("csvProps.withArchive") != null
                    && flattenedJsonMap.get("csvProps.withArchive").equals(true)) {
                missingFields.addAll(checkRequiredFields(requiredArchiveFields, flattenedJsonMap));
            }

            if (!missingFields.isEmpty()) {
                throw new GeneratorCheckException(String.format(EXCEPTION, String.join(" ,", missingFields)));
            }
        } catch (GeneratorCheckException gce) {
            LOG.error(markers, String.format(EXCEPTION, String.join(" ,", missingFields)));
            throw gce;
        }

    }

    private void checkKafkaRequiredFields(Config config) throws GeneratorCheckException {
        List<String> missingFields = new ArrayList<>(checkUserDictionariesRequiredFields(config));
        //Declaration of the requiredFields/ requiredSecurityFields : List<String>
        List<String> requiredFields = new ArrayList<>();
        requiredFields.add("kafkaProps.bootstrapServers");
        requiredFields.add("kafkaProps.schemaRegistry");
        requiredFields.add("kafkaProps.topicName");
        requiredFields.add("kafkaProps.numberOfEvents");

        List<String> requiredSecurityFields = new ArrayList<>();
        requiredSecurityFields.add("kafkaProps.withSSL");
        requiredSecurityFields.add("kafkaProps.securityProps.sslTrustStoreLocation");
        requiredSecurityFields.add("kafkaProps.securityProps.sslKeyStoreLocation");
        requiredSecurityFields.add("kafkaProps.securityProps.sslTrustStorePassword");
        requiredSecurityFields.add("kafkaProps.securityProps.sslKeyStorePassword");
        requiredSecurityFields.add("kafkaProps.securityProps.sslKeyPassword");
        requiredSecurityFields.add("kafkaProps.securityProps.sslSRKeyStoreLocation");
        requiredSecurityFields.add("kafkaProps.securityProps.sslSRKeyStorePassword");

        LOG.debug(markers, "required fields to be checked {}", requiredFields);
        LOG.debug(markers, "required security fields to be checked if withSSL is true {}", requiredSecurityFields);

        try {
            Map<String, Object> flattenedJsonMap = getFlattenedMapFromConfig(config);
            //verify if the required fields list corresponds to the flattened JsonMap
            missingFields.addAll(checkRequiredFields(requiredFields, flattenedJsonMap));
            //verify if withSSl is true if all security fields are set
            if (flattenedJsonMap.containsKey("kafkaProps.withSSL") && flattenedJsonMap.get("kafkaProps.withSSL") != null
                    && flattenedJsonMap.get("kafkaProps.withSSL").equals(true)) {
                missingFields.addAll(checkRequiredFields(requiredSecurityFields, flattenedJsonMap));
            }
            if (!missingFields.isEmpty()) {
                throw new GeneratorCheckException(String.format(EXCEPTION, String.join(" ,", missingFields)));
            }
        } catch (GeneratorCheckException gce) {
            LOG.error(markers, String.format(EXCEPTION, String.join(" ,", missingFields)));
            throw gce;
        }
    }

    private void checkCassandraRequiredFields(Config config) throws GeneratorCheckException {
        List<String> missingFields = new ArrayList<>(checkUserDictionariesRequiredFields(config));

        //Declaration of the requiredFields/ requiredSecurityFields : List<String>
        List<String> requiredFields = new ArrayList<>();
        requiredFields.add("cassandraProps.contactPoints");
        requiredFields.add("cassandraProps.port");
        requiredFields.add("cassandraProps.keyspace");
        requiredFields.add("cassandraProps.userName");
        requiredFields.add("cassandraProps.password");
        requiredFields.add("cassandraProps.tableName");
        requiredFields.add("cassandraProps.numberOfEvents");


        List<String> requiredSecurityFields = new ArrayList<>();
        requiredSecurityFields.add("cassandraProps.withSSL");
        requiredSecurityFields.add("cassandraProps.securityProps.jksPath");
        requiredSecurityFields.add("cassandraProps.securityProps.jksPassword");

        LOG.debug(markers, "required fields to be checked {}", requiredFields);
        LOG.debug(markers, "required security fields to be checked if withSSL is true {}", requiredSecurityFields);

        try {
            Map<String, Object> flattenedJsonMap = getFlattenedMapFromConfig(config);
            //verify if the required fields list corresponds to the flattened JsonMap
            missingFields.addAll(checkRequiredFields(requiredFields, flattenedJsonMap));
            //verify if withSSl is true if all security fields are set
            if (flattenedJsonMap.containsKey("cassandraProps.withSSL") && flattenedJsonMap.get("cassandraProps.withSSL") != null
                    && flattenedJsonMap.get("cassandraProps.withSSL").equals(true)) {
                missingFields.addAll(checkRequiredFields(requiredSecurityFields, flattenedJsonMap));
            }
            if (!missingFields.isEmpty()) {
                throw new GeneratorCheckException(String.format(EXCEPTION, String.join(" ,", missingFields)));

            }
        } catch (GeneratorCheckException gce) {
            LOG.error(markers, String.format(EXCEPTION, String.join(" ,", missingFields)));
            throw gce;
        }
    }

    private void checkApiRequiredFields(Config config) throws GeneratorCheckException {
        List<String> missingFields = new ArrayList<>(checkUserDictionariesRequiredFields(config));

        //Declaration of the requiredFields : List<String>
        List<String> requiredFields = new ArrayList<>();
        requiredFields.add("apiProps.url");
        requiredFields.add("apiProps.numberOfEvents");

        LOG.debug(markers, "required fields to be checked {}", requiredFields);

        try {
            Map<String, Object> flattenedJsonMap = getFlattenedMapFromConfig(config);
            //verify if the required fields list corresponds to the flattened JsonMap
            missingFields.addAll(checkRequiredFields(requiredFields, flattenedJsonMap));
            if (!missingFields.isEmpty()) {
                throw new GeneratorCheckException(String.format(EXCEPTION, String.join(" ,", missingFields)));
            }
        } catch (GeneratorCheckException gce) {
            LOG.error(markers, String.format(EXCEPTION, String.join(" ,", missingFields)));
            throw gce;
        }
    }

    private Map<String, Object> getFlattenedMapFromConfig(Config config) throws GeneratorCheckException {
        String json = null;
        try {
            json = getJsonFromConfig(config);
            return JsonFlattener.flattenAsMap(json);
        } catch (Exception e) {
            throw new GeneratorCheckException("Error during config deserialization");
        }
    }

    private List<String> checkRequiredFields(List<String> requiredField, Map<String, Object> flattenedJsonMap) {
        List<String> missingFields = new ArrayList<>();

        for (String key : requiredField) {
            //check if key exists in config
            if (flattenedJsonMap.containsKey(key) && flattenedJsonMap.get(key) != null) {
                //check value is empty
                if (StringUtils.isEmpty(flattenedJsonMap.get(key).toString()) || "0".equals(flattenedJsonMap.get(key).toString())) {
                    missingFields.add(key);
                }
            } else {
                //key is not present in config
                missingFields.add(key);
            }
        }
        return missingFields;
    }

    private String getJsonFromConfig(Config config) throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        ConfigJsonSerializer serializer = new ConfigJsonSerializer();
        SimpleModule module = new SimpleModule();
        module.addSerializer(Schema.class, serializer);
        objectMapper.registerModule(module);
        return objectMapper.writeValueAsString(config);
    }


}
