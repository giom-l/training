/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.generators.complexes;

import com.bnpparibas.itr.dh.datagenerator.core.context.ExecutionContext;
import org.apache.avro.Schema;

import java.util.function.Predicate;

public class UnionGenerator {
    private static final Schema NULL_SCHEMA = Schema.create(Schema.Type.NULL);

    public Object generate(ExecutionContext context, Schema.Field field, int size) {
        Schema firstUnionSchema = field.schema().getTypes().stream()
                .filter(((Predicate<Schema>) NULL_SCHEMA::equals).negate())
                .findFirst()
                .orElse(NULL_SCHEMA);
        Schema.Field newField = new Schema.Field(field.name(), firstUnionSchema, field.doc(), field.defaultVal());
        field.aliases().forEach(newField::addAlias);
        return SchemaGenerator.generateField(context, newField, size);
    }
}
