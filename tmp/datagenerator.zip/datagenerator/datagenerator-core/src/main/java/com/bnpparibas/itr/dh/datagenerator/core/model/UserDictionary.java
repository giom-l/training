/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.model;

import java.util.ArrayList;
import java.util.List;

public class UserDictionary {
    private String name;
    private List<Object> values = new ArrayList<>();

    public List<Object> getValues() {
        return new ArrayList<>(values);
    }

    public String getName() {
        return name;
    }
}
