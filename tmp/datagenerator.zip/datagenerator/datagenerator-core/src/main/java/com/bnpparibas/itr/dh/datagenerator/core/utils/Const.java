/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.core.utils;

public class Const {

    public static final String DEFAULT_CHARSET = "UTF-8";

    public static final String CSV = "csv";
    public static final String KAFKA = "kafka";
    public static final String CASSANDRA = "cassandra";
    public static final String API = "api";

    public static final String RANDOM_PROPERTY = "random";
    public static final String USER_DICO = "USER_DICO";
    public static final String NAUGHTY_STRINGS_PERC_PROPERTY = "naughty_strings_perc";

    public static final String UNIQUE_VALUE = "unique";
    public static final String DOMAIN_PATTERN = "domain:(negative|positive)";
    public static final String POSITIVE = "positive";
    public static final String NEGATIVE = "negative";
    public static final String RANGE_INT_PATTERN = "range:(-?[0-9]+):(-?[0-9]+)";

    public static final String TYPE = "type";
    public static final String GENDER = "gender";
    public static final String LAST_NAME = "lastName";
    public static final String FIRST_NAME = "firstName";
    public static final String FEMALE = "female";
    public static final String MALE = "male";
    public static final String FIRST = "first";
    public static final String LAST = "last";
    public static final String ALL = "all";
    public static final int COUNT = 5;
    public static final String CORRELATIONID = "correlationId";
    public static final String PARENT_CORRELATION_ID = "rootCorrelationId";
    public static final String ROOT_CORRELATION_ID = "parentCorrelationId";

    public static final int DEFAULT_NAUGHTY_STRINGS_PERC = 20;

    public static final String DATE_FORMAT = "yyyy-MM-dd";
    public static final String PRECISION = "precision";
    public static final String SCALE = "scale";

    public static final String ARCHIVE_EXT = ".tar.gz";

    public static final String FILE_EXT = ".csv";
    public static final String TMP_DIR = "/.tmpDir";

    public static final String DICTIONARY_DIR = "dictionary/";
    public static final String DICTIONARY_MALE_FIRST_NAME = DICTIONARY_DIR + "male-first-name";
    public static final String DICTIONARY_FEMALE_FIRST_NAME = DICTIONARY_DIR + "female-first-name";
    public static final String DICTIONARY_LAST_NAME = DICTIONARY_DIR + "last-name";
    public static final String DICTIONARY_NAUGHTIES = DICTIONARY_DIR + "naughties";
    public static final String COMMA = ",";

    public static final String DOMAIN = "email.com";
    public static final String EMAIL = "email";
    public static final int PHONE_CONST = 99999999;
    public static final String PHONE = "phone";
    public static final String PHONE_FORMAT = "0%01d%08d";
    public static final String PHONE_REGEX = "^((06)|(07))[0-9]{8}$";

    public static final String JAVAX_NET_SSL_TRUST_STORE = "javax.net.ssl.trustStore";
    public static final String JAVAX_NET_SSL_TRUST_STORE_PASS = "javax.net.ssl.trustStorePassword";
    public static final String JAVAX_NET_SSL_KEY_STORE = "javax.net.ssl.keyStore";
    public static final String JAVAX_NET_SSL_KEY_STORE_PASS = "javax.net.ssl.keyStorePassword";
    public static final String SSL = "SSL";
    public static final String KAFKA_ALL = "all";
}
