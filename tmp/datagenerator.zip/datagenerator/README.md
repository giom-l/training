# DATA GENERATOR

Tool to generate random data, for csv and kafka, based on a configuration file.
Example of the configuration file can be found in: **src/main/resources/all_outputs_conf.json**