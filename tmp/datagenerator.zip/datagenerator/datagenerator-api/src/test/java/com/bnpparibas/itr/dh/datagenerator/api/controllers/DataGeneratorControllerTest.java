/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.api.controllers;

import com.bnpparibas.itr.dh.datagenerator.core.parser.SchemaDeserializer;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.module.SimpleModule;
import org.apache.avro.Schema;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.charset.Charset;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@WebMvcTest(DataGeneratorController.class)
public class DataGeneratorControllerTest {
    private static final String GENERATE_URL = "/generator/generate";
    private static final String CHECK_URL = "/generator/check/schema";
    private static String jsonMisformedConfig;
    private static String jsonSchema;
    private static String jsonInvalidSchema;
    private static String jsonConfig;


    @Autowired
    private MockMvc mockMvc;

    @Test
    public void post_request_with_valid_config_should_return_ok() throws Exception {
        // GIVEN
        MockHttpServletRequestBuilder postRequest = post(GENERATE_URL)
                .contentType(MediaType.APPLICATION_JSON)
                .content(jsonConfig);
        // WHEN
        mockMvc.perform(postRequest)
        // THEN
                .andExpect(status().isOk());
    }

    @Test
    public void post_request_with_misformed_config_should_return_client_error() throws Exception {
        // GIVEN
        MockHttpServletRequestBuilder postRequest = post(GENERATE_URL)
                .contentType(MediaType.APPLICATION_JSON)
                .content(jsonMisformedConfig);
        // WHEN
        mockMvc.perform(postRequest)
        // THEN
                .andExpect(status().is4xxClientError());
    }

    @Test
    public void post_request_with_empty_should_return_client_error() throws Exception {
        // GIVEN
        MockHttpServletRequestBuilder postRequest = post(GENERATE_URL)
                .contentType(MediaType.APPLICATION_JSON)
                .content(StringUtils.EMPTY);
        // WHEN
        mockMvc.perform(postRequest)
        // THEN
                .andExpect(status().is4xxClientError());
    }

    @Test
    public void check_request_with_valid_schema_should_return_ok() throws Exception {
        // GIVEN
        MockHttpServletRequestBuilder postRequest = post(CHECK_URL)
                .contentType(MediaType.APPLICATION_JSON)
                .content(jsonSchema);
        // WHEN
        mockMvc.perform(postRequest)
        // THEN
                .andExpect(status().isOk());
    }

    @Test
    public void check_request_with_empty_schema_should_return_client_error() throws Exception {
        // GIVEN
        MockHttpServletRequestBuilder postRequest = post(CHECK_URL)
                .content(StringUtils.EMPTY);
        // WHEN
        mockMvc.perform(postRequest)
        // THEN
                .andExpect(status().is4xxClientError());
    }

    @Test
    public void check_request_with_invalid_schema_should_return_server_error() throws Exception {
        // GIVEN
        MockHttpServletRequestBuilder postRequest = post(CHECK_URL)
                .content(jsonInvalidSchema);
        // WHEN
        mockMvc.perform(postRequest)
        // THEN
                .andExpect(status().is5xxServerError());
    }

    @TestConfiguration
    static class Configuration {
        @Bean
        public Schema.Parser schemaParser(){
            return new Schema.Parser();
        }

        @Bean
        public ObjectMapper mapper(){
            ObjectMapper mapper = new ObjectMapper();
            SimpleModule module = new SimpleModule();
            module.addSerializer(Schema.class, new JsonSerializer<Schema>() {
                @Override
                public void serialize(Schema schema, JsonGenerator jsonGenerator, SerializerProvider serializerProvider) throws IOException {
                    String jsonSchema = schema.toString();
                    jsonGenerator.writeRaw(":" + jsonSchema);
                }
            });
            module.addDeserializer(Schema.class, new SchemaDeserializer());
            mapper.registerModule(module);
            return mapper;
        }
    }

    @BeforeClass
    public static void setup() throws IOException {
        jsonConfig = jsonFile("config.json") ;
        jsonMisformedConfig = jsonFile("misformed_config.json") ;
        jsonSchema = jsonFile("schema");
        jsonInvalidSchema = jsonFile("invalid_schema");
    }

    private static String jsonFile(String filename) throws IOException {
        URL configResource = DataGeneratorControllerTest.class.getClassLoader().getResource(filename);
        return FileUtils.readFileToString(new File(configResource.getPath()), Charset.defaultCharset());
    }

}
