/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.api.configurations;

import com.bnpparibas.itr.dh.datagenerator.api.serializers.ConfigDeserializer;
import org.apache.avro.Schema;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DataGeneratorConfiguration {

    @Bean
    public Schema.Parser schemaParser() {
        return new Schema.Parser();
    }

    @Bean(initMethod = "init")
    public ConfigDeserializer configDeserializer() {
        return new ConfigDeserializer();
    }
}
