/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.datagenerator.api.actuator;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.boot.actuate.endpoint.web.WebEndpointResponse;
import org.springframework.boot.actuate.info.InfoEndpoint;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
@Endpoint(id="version")
public class VersionEndpoint {

    private InfoEndpoint delegate;

    public VersionEndpoint(InfoEndpoint infoEndpoint) {
        this.delegate = infoEndpoint;
    }

    @ReadOperation
    public WebEndpointResponse<String> info() {
        ObjectMapper oMapper = new ObjectMapper();
        String version = oMapper.convertValue(this.delegate.info().get("app"), Map.class).get("version").toString();

        return new WebEndpointResponse<>(version, WebEndpointResponse.STATUS_OK);
    }

}
